# Changelog — 360° MDL Navigator

## v0.1.2 — 2026-11-13
- New deliverable **D4b Evidence Landscape Report** (companion to D4 Core Corpus), produced with the toolkit workbook on every build
  and by the new command `mdl.py landscape STATE OUTDIR [--anonymous]`: leading authors (productivity and citations) and their
  presence in the core; F2 papers and their role; most-cited core items (figure) and eligible records with gate status; rising
  records; F5 emerging voices by slice and decision (figure); reading notes; references built from record fields only.
- Citation formatting: Scopus-style initials ("Lindsay J.R.") are now parsed correctly; venue italics no longer lose their closing mark.
- Indices of the worked example unchanged (SBI 0.92 · CovI 1.00 · MDI 0.86 · RI 0.90 · LOSO 0.80).

## v0.1.1 — 2026-11-07 (first public release, beta)
- Claude Skill that runs the 360° MDL method (Version 2026) from a topic to a Core Knowledge and a Knowledge Distillate under the Two-Key Rule (four keys).
- Scenario A (researcher's exports: Scopus/WoS CSV, RIS, BibTeX, EndNote, Zotero, OpenAlex/Crossref JSON) and Scenario B (open APIs: OpenAlex, Crossref, PubMed, arXiv; strings handed over for Google Scholar, Scopus, Web of Science).
- Gate 1 rules, proposed 6R scores with justification, batch confirmation of clear excludes with a 10 % sample, CCD-curated core proposal.
- Outputs of every build: official 360MDL_Toolkit_v2026 (T1–T17) with recalculated formulas, calculator.json for the Index Calculator, gaps report (6 fixed sections), methods draft, structured AI-use statement, MDL-RC 2026 checklist (30 items), Navigator run checklist (20 criteria), Knowledge Distillate (Markdown + Word; IDs / APA / Harvard; 4 figures; evidence appendix; closing section on the method and the researcher), audit log, versioned state.
- Fallback simplified workbook with a warning when the official toolkit writer cannot run in the environment.
- Worked example: replay of the published review "Energy transition for smart cities in the Arab world" reproducing its indices exactly.
- Known limits: search scripts tested only for graceful failure where the network is blocked; single-coder workflow (κ pending); English interface.

## Planned — v0.2 (December 2026)
- Live-tested API scripts and Semantic Scholar; Scopus API with institutional key; PDF reading for missing abstracts; Greek conversation; calculator beta 2 reading calculator.json and drawing the knowledge map; pilot feedback from doctoral students.

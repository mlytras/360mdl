# Hand-over instructions for the closed databases (Scenario B)

The Navigator cannot query Google Scholar, Scopus or Web of Science (no API, or an institutional licence is needed).
Give the researcher the exact string, the filters and these export steps; log the entry with `status: handed_over` so it
appears in the gaps report until the export is imported.

## Scopus (stream SCO; slices IMP, REC, FRO)
1. scopus.com → Advanced search → paste: `TITLE-ABS-KEY(("smart cit*" OR urban) AND ("energy transition" OR renewable*)) AND PUBYEAR > 2014 AND LANGUAGE(english) AND DOCTYPE(ar OR re)`
2. IMP slice: sort by *Cited by (highest)*, select the first 25. REC slice: limit to the last 2 years, sort by citations, first 10.
   FRO slice: limit to the last 5 years, filter *Source type: special issue* where available (or search the journal's special-issue pages), 25.
3. Export → CSV → tick *Citation information, Bibliographical information, Abstract & keywords* → download.
4. Send the CSV to the Navigator: `mdl.py import STATE scopus.csv --stream SCO --slice IMP --source "Scopus" --date YYYY-MM-DD`.

## Web of Science (stream WOS; same slices)
1. webofscience.com → Advanced search → `TS=(("smart cit*" OR urban) AND ("energy transition" OR renewable*))`, timespan 2015–2026, Document types Article, Review.
2. Sort by *Citations: highest first* (IMP), or filter years (REC/FRO).
3. Export → *Tab delimited file* or *Excel* → record content *Full Record* → download.
4. `mdl.py import STATE savedrecs.txt --stream WOS --slice IMP --source "Web of Science"`.

## Google Scholar (stream GSC; slice TOP)
No export. Use *Publish or Perish* (free, harzing.com/resources/publish-or-perish): source Google Scholar, paste the string, max 100
results, sort by citations, *Save results as CSV*. Or copy the first 10 results' titles and links into a text file; the Navigator
will look each up on OpenAlex/Crossref to obtain the identifiers before adding them.
`mdl.py import STATE pop.csv --stream GSC --slice TOP --source "Google Scholar via Publish or Perish"`.

## Influencer profiles (F2)
Clarivate Highly Cited Researchers list (clarivate.com/highly-cited-researchers), Stanford–Elsevier Top 2 % (Elsevier Data
Repository), Google Scholar profiles by label, Research.com and AD Scientific Index are read by the researcher; give the
Navigator the names, and it finds each scholar's most-cited and most-recent on-topic paper through OpenAlex (stream HCR/T2P/GSP/
RCO/ADS, slices MC/MR). If a ranking page cannot be verified, use the institutional-profile signal (INS) and say so in T1.

## Zotero / EndNote / Mendeley libraries
Export the collection as RIS (Zotero: right-click collection → Export → RIS) or BibTeX; `mdl.py import STATE file.ris --stream … --slice …`.

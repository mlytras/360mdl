# 360° MDL — Multidimensional Literature Review Model (Lytras) — Version 2026
## Canonical Methodology Specification (single source of truth for all deliverables)

Author / originator: **Miltiadis D. Lytras** (Deree, The American University of Greece, Greece; Effat University, Saudi Arabia). © 2026 Miltiadis D. Lytras.
License of documents: **CC BY 4.0**. "360° MDL" name and logo: trademark of the author (application planned) — not licensed by CC.
Suggested citation: Lytras, M. D. (2026). *360° MDL: The Multidimensional Literature Review Model — Version 2026 (Methodology Overview, Handbook and Toolkit)*. Zenodo. https://doi.org/10.5281/zenodo.23724393

Tagline: **"From volume to value."** A multi-stream, multidimensional and resilient literature review methodology.
Note: "MDL" = MultiDimensional Literature review model; it also echoes the originator's initials (M.D.L.).

---

## 1. Positioning (fair and precise)
- PRISMA 2020 (Page et al., 2021, BMJ 372:n71) is a **reporting guideline** (27-item checklist + flow diagram) designed mainly for systematic reviews of interventions. It secures *transparency of reporting* of search and selection. It does not, and was not designed to, prescribe: (a) how to select for *value* rather than exhaustiveness, (b) how to integrate practice/industry and policy evidence, (c) how to analyse papers along several analytical dimensions, (d) how to test whether conclusions are robust to the choice of sources, (e) how to move from findings to an original framework / value creation.
- 360° MDL is a **review methodology** (how to do the review) **with its own reporting checklist** and a **PRISMA-compatible flow diagram**. It is complementary, not hostile, to PRISMA. Authors may report both.
- Critical gaps addressed ("quality gaps" of mechanistic reviews): volume over value; single-stream bias (one database); exclusion of practice/policy voices; descriptive-only synthesis ("paper-by-paper summaries"); no explicit contribution taxonomy; no robustness test of conclusions; weak interpretation and no actionable framework; under-representation of emerging and Global South voices; unregulated AI use.

## 2. Seven Pillars (principles)
1. **360° Multi-Stream Triangulation** – evidence comes from several independent stream families.
2. **Value over Volume** – purposive, quality-weighted selection of a bounded core corpus (≤ 50 items).
3. **CCD Curation** – Complementarity, Coverage, Diversity govern the composition of the corpus.
4. **Multidimensional Analysis** – every item is coded along standard analysis matrices.
5. **Interpretation & Value Creation** – synthesis must end in interpretation, exploitation modes and a Value-Based Framework.
6. **Resilience** – key conclusions are tested for robustness against removal of any stream family.
7. **Transparency & Responsible Practice** – auditable trail, open matrices, responsible metrics, disclosed and verified AI use.

## 3. The 3×3 Rule (minimum standard)
A review qualifies as a 360° MDL review only if it uses **at least 3 source streams × at least 3 analysis matrices** (from the originator's draft: "At least 3 streams X At least 3 Analysis types").

## 4. Configurations (tiers)
| Tier | Intended for | Streams | Matrices | Core corpus | Extras |
|---|---|---|---|---|---|
| **360° Lite** | Young researchers, MSc/PhD chapters, short reviews | ≥ 3 (≥1 non-database recommended) | M1, M4 + one of M2/M3/M6 (≥3) | 20–30 | Simplified 6R gate; supervisor checkpoints |
| **360° Standard** | Journal review articles | ≥ 4 incl. ≥ 1 grey (industry or policy) | M1–M6 | 40–50 | Full 6R gate; CCD portfolio rules; Triangulation Strength; indices |
| **360° Advanced** | Senior researchers, flagship state-of-the-art reviews, policy & foresight reports | A + B + C (≥ 6 streams) | M1–M8 | 50 core + Extended Evidence Pool (≤ 30) | Registered protocol; inter-coder reliability; Leave-One-Stream-Out resilience test; open matrices; living updates |

## 5. Source Strategies (Approaches)
### Approach A — Holistic (database and document streams)
- **A1 Web of Science** – Impact slice: 25 most-cited papers of all time; Recency slice: 10 papers of the last 2 years; Frontier slice: 25 papers published in special issues of the last 5 years.
- **A2 Scopus** – same three slices (25 / 10 / 25).
- **A3 Google Scholar** – Top 10 papers by citations over time.
- **A4 Industry & Consulting** – 10 white papers by industry leaders / consulting firms (if applicable).
- **A5 Government & Global Organisations** – 10 position/policy papers by government offices or global organisations (e.g., OECD, UN agencies, World Bank, EU) on the same topic.
- *(optional)* **A6 Domain database** – e.g., PubMed, IEEE Xplore, ACM DL, ERIC, according to the discipline.
Harvest pool for A ≈ up to 150 records → curated to the core corpus.

### Approach B — Influencers (scholar-centric streams)
- **B1 Clarivate Highly Cited Researchers** – identify top profiles in the field; select 2 papers each.
- **B2 Stanford–Elsevier "Top 2%" scientists** (Ioannidis et al. standardized citation indicators, composite indicator) – select 1 paper each.
- **B3 Google Scholar top profiles** (label/keyword profiles) – 1 paper each.
- **B4 Research.com top scientists** – 1 paper each.
- **B5 AD Scientific Index top scientists** – 1 paper each.
Rule: choose ~50 top profiles; 1–2 papers per scientist. **Simplified selection**: (i) the scientist's most-cited paper on the topic, (ii) the scientist's most recent paper on the topic.
Responsible-metrics safeguards (Leiden Manifesto, DORA): rankings are discovery tools, not quality verdicts; use field-normalised indicators; exclude self-citation-inflated profiles; the 6R gate still applies to every paper.

### Approach C — Emerging & Diverse Voices (NEW in v2026; counterbalancing stream)
Purpose: neutralise the Matthew effect (Merton, 1968), citation-lag bias and echo chambers introduced by A1-impact slices and Approach B.
- **C1 Rising papers** – high citation velocity (citations/year) in last 3 years.
- **C2 Under-represented regions** – Global South / non-dominant regions.
- **C3 Regional & non-English scholarship** – where relevant and translatable.
- **C4 Frontier preprints & top conference papers**.
- **C5 Critical, dissenting or null-result studies**.
Quota: **≥ 10% of the core corpus** (Standard), **≥ 15%** (Advanced).

### Review Modes
- **Mode H (Holistic)** = A + C-minimum
- **Mode I (Influencer)** = B + C-minimum
- **Mode 360 (Full)** = A + B + C (required for 360° Advanced)

### Stream Families (used for triangulation)
F1 Academic databases (A1, A2, A3, A6) · F2 Influencer scholarship (B) · F3 Industry practice (A4) · F4 Policy & global organisations (A5) · F5 Emerging & diverse voices (C).

## 6. The 360° MDL Cycle — 7 Phases
**P1 FRAME – Review Canvas & Protocol.** Define purpose, review questions (RQ1–RQn), scope (time window, languages, disciplines), tier and mode, streams and slices, keyword universe (preliminary clusters), eligibility criteria, analysis matrices to be used, team & roles. Register the protocol (OSF Registries or Zenodo) for Standard (recommended) and Advanced (mandatory). Output: *360° Review Canvas* + *Protocol*.

**P2 SOURCE – Multi-Stream Harvesting.** Run stream-specific searches; log every query (stream, date, string, filters, hits) in the *Stream Log*. Export records with metadata. Record slice membership. Output: *Harvest Pool*.

**P3 SELECT – Three Gates.**
- *Gate 1 Eligibility*: inclusion/exclusion criteria; deduplication across streams. Items found in ≥ 2 streams get a **Convergence Flag** (signal of centrality).
- *Gate 2 6R Quality Gate*: score each item 0–2 on six criteria:
  - **R1 Relevance** – fit with the review questions.
  - **R2 Rigour** – methodological soundness (for grey literature use AACODS: Authority, Accuracy, Coverage, Objectivity, Date, Significance — Tyndall, 2010).
  - **R3 Reach** – field-normalised impact; citations per year since publication (not raw counts).
  - **R4 Recency** – timeliness relative to the review window.
  - **R5 Richness** – depth/originality of the contribution.
  - **R6 Representativeness** – adds diversity (method, region, stream, perspective).
  - Total 0–12. Decision rule: **R1 ≥ 1 AND R2 ≥ 1 AND total ≥ 7 → "Pass"**; total 5–6 → "Reserve" (Extended Evidence Pool); otherwise "Exclude".
  - Calibration: two reviewers score a 20% sample; target Cohen's κ ≥ 0.70 (Advanced: mandatory).
- *Gate 3 CCD Curation* (portfolio optimisation of the core corpus):
  - **Complementarity** – every item must add something unique (a cluster, method, contribution type, RQ or perspective). Redundant items → Extended Pool.
  - **Coverage** – every keyword cluster covered by ≥ 3 core items (Lite: ≥ 2).
  - **Diversity** – portfolio rules: no single stream family > 40% of core; grey literature (F3+F4) 10–30%; F5 ≥ 10%; no single author/group > 3 items; ≥ 3 method families represented.
- Target: **Core Corpus ≤ 50 items** (Lite 20–30).
- Output: *360° MDL Flow Diagram* (PRISMA-compatible).

**P4 CODIFY – Codification & Master Table.**
- Each item gets an ID: `[STREAM]-[SLICE]-[NN]`. Codes: WOS, SCO, GSC, DOM (A6), IND, GOV, HCR, T2P (Stanford top 2%), GSP (GS profiles), RCO (Research.com), ADS (AD Scientific Index), EMV (C stream). Slices: IMP (impact), REC (recency), FRO (frontier/special issue), TOP, WP (white paper), PP (policy paper), MC (most-cited of influencer), MR (most-recent of influencer), RIS (rising), GLS (Global South), REG (regional), PRE (preprint/conference), CRI (critical). Examples: WOS-IMP-01, SCO-FRO-07, GSC-TOP-03, IND-WP-02, GOV-PP-05, HCR-MC-04, T2P-MR-02, EMV-GLS-01.
- **Master Table fields** (extends the originator's Excel/Word template): ID · Full citation · Stream family · Topics covered · Focus/context · Methodology · Key findings · Analysis (themes) · Type of contribution · Contribution · Significance · Future research · Limitations · Research contribution · Key interpretation · Exploitation mode · Value-Based Framework element · 6R scores.

**P5 ANALYSE – Six Core Analysis Matrices.**
- **M1 General Matrix** – compact overview per item: Topics covered (codified themes) · Approach (summary of the scientific approach) · Methodology · Key findings · Contribution (reference to Theory / Practice / Industry) · Significance (codified).
- **M2 Methodology Matrix** – method family (Quantitative · Qualitative · Mixed · Design science/Artefact · Conceptual/Theoretical · Review/Bibliometric · Simulation/Modelling · Case study · Delphi/Expert), data source, sample, analysis technique. Goal: coverage of diverse methods.
- **M3 Contribution & Impact Matrix** – strict 8-type **Contribution Taxonomy**: CT1 Theoretical · CT2 Conceptual framework/model · CT3 Methodological · CT4 Empirical evidence · CT5 Artefact/Technological · CT6 Policy · CT7 Practice/Managerial · CT8 Societal/Educational. Plus impact locus: Theory / Practice / Industry / Policy / Society.
- **M4 Topics/Keywords Coverage Matrix** – unify synonymous keywords into **≤ 10 keyword clusters (K1–K10)**; each item mapped to **≤ 8 clusters**; papers × clusters with "x" marks → coverage heatmap.
- **M5 Research Questions Matrix** – detailed mapping of explicit/implicit RQs; group into RQ families (What/descriptive · Why/explanatory · How/design · What-if/predictive · Should/normative); select complementary questions.
- **M6 Open Research Issues Matrix** – detailed mapping of future research and limitations; cluster into a research agenda; select complementary perspectives.

**P6 SYNTHESISE & INTERPRET.**
- *Cross-matrix synthesis*: cluster × method gap map (white spots), cluster × contribution map, academic–practice–policy comparison (convergent / complementary / divergent).
- *Triangulation & Resilience Test*: list Key Findings (KF1..KFn); for each, record which stream families support it.
- **M7 Interpretation & Exploitation Matrix** – key interpretation (what it means) and exploitation mode (e.g., theory building, policy instrument, benchmark, design guideline, curriculum, managerial toolkit, standard).
- **M8 Value-Based Framework Matrix** – map interpretations into the author's original framework, using the **Value-Based Framework canvas** with 6 layers: **Enablers → Capabilities → Processes → Outcomes → Value (for stakeholders) → Measures**, plus a stakeholder lens. (From the originator's notes: e.g., "Smart Cities can be seen as an Input–Process–Output system with well-defined outcomes".)
- Analytical layers: **Descriptive** (M1, M2, M4) → **Evaluative** (M3 + 6R) → **Prospective** (M5, M6) → **Interpretive** (M7) → **Generative** (M8). "From description to value creation."

**P7 REPORT & RENEW.** Report with the 360° MDL Reporting Checklist (MDL-RC 2026); include flow diagram, index dashboard, matrices as supplementary open data (CC BY), AI-use statement; plan living updates (re-run Recency & Frontier slices every 12–24 months; version the review).

## 7. 360° MDL Indices (quantitative quality indicators)
Let N = core corpus size.
1. **Stream Balance Index (SBI)** = H_stream / ln(k), where H = −Σ p_i ln p_i over the k stream families used. Range 0–1. Target ≥ 0.70 (Standard).
2. **Coverage Index (CovI)** = (# keyword clusters with ≥ 3 core items) / (# clusters). Target ≥ 0.80.
3. **Method Diversity Index (MDI)** = normalised Shannon entropy over method families present (divide by ln of the number of method families in the taxonomy = 9). Target ≥ 0.60.
4. **Triangulation Strength (TS)** of a key finding = number of distinct stream families (1–5) that support it. Classes: **Robust** (TS ≥ 3), **Supported** (TS = 2), **Tentative** (TS = 1).
5. **Resilience Index (RI)** = (#Robust + 0.5 × #Supported) / #Key findings. Target ≥ 0.60.
6. **Leave-One-Stream-Out (LOSO) Stability** = share of key findings that remain at TS ≥ 2 after removing any single stream family (worst case over families). Target ≥ 0.70 (Advanced).
7. **Convergence Rate** = share of core items found in ≥ 2 streams (descriptive; reported, no target).
Recommended "quality badge": a review meeting all targets for its tier may state "Conducted and reported according to 360° MDL v2026 (Tier X)".

## 8. 360° MDL Reporting Checklist (MDL-RC 2026) — 30 items
**Title & Abstract**: 1 Identify the review as a 360° MDL review and state the tier and mode. 2 Structured abstract including streams, corpus size, matrices and resilience index.
**Introduction**: 3 Rationale and the knowledge problem. 4 Review questions.
**Protocol (P1)**: 5 Review Canvas: scope, time window, languages, disciplines. 6 Protocol registration (registry & ID) or justification. 7 Team, roles, and calibration procedure.
**Sourcing (P2)**: 8 Streams and slices used, with rationale (≥ 3). 9 Full search strings/filters and dates per stream (Stream Log). 10 Influencer identification sources and profile-selection rules (if Approach B). 11 Emerging & Diverse Voices strategy (if Approach C).
**Selection (P3)**: 12 Eligibility criteria & deduplication; convergence flags. 13 6R scoring scheme, thresholds and calibration (κ). 14 CCD curation decisions and portfolio rules. 15 Flow diagram with numbers per stream and per gate.
**Codification (P4)**: 16 ID scheme and Master Table fields. 17 Keyword-unification procedure and the final cluster list.
**Analysis (P5)**: 18 Matrices used (≥ 3) and coding rules. 19 Contribution taxonomy applied. 20 Coverage heatmap and Coverage Index. 21 Method diversity (M2) and MDI.
**Synthesis & Interpretation (P6)**: 22 Key findings with Triangulation Strength. 23 Resilience Index and (Advanced) LOSO test. 24 Academic–practice–policy convergence/divergence. 25 Interpretation & exploitation (M7). 26 Value-Based Framework (M8) and its derivation from the evidence. 27 Research agenda from M5/M6.
**Transparency (P7)**: 28 Open data: matrices and Stream Log as supplementary files. 29 AI-use statement (tools, tasks, verification). 30 Limitations of the review (stream coverage, language, metrics bias) and update plan.

## 9. Responsible AI in 360° MDL (v2026)
Permitted with disclosure: search-string ideation, deduplication, first-pass extraction into matrices, keyword clustering suggestions, translation of regional scholarship, drafting summaries.
Rules: **Two-Key Rule** — every AI-produced cell is verified by a human against the source text; never cite an item not retrieved and read by a human; log tools/versions/prompts; AI cannot assign 6R scores without human confirmation; confidentiality of unpublished material respected.

## 10. Roles & Workflow guidance
Lite: researcher + supervisor checkpoints at end of P1, P3, P6. Standard: lead + second coder (20% double-coding). Advanced: team of ≥ 3, independent double coding of 6R and M3/M4, adjudication, registered protocol.
Indicative effort (person-days): Lite 15–25; Standard 30–50; Advanced 60–100.

## 11. Templates (toolkit)
T1 360° Review Canvas · T2 Protocol template · T3 Stream Log · T4 Screening & 6R Quality Gate · T5 CCD Portfolio check · T6 Master Table · T7 M1 General Matrix · T8 M2 Methodology Matrix · T9 M3 Contribution & Impact Matrix · T10 M4 Keyword Coverage Matrix (heatmap) · T11 M5 RQ Matrix · T12 M6 Open Issues Matrix · T13 M7 Interpretation & Exploitation · T14 M8 Value-Based Framework canvas · T15 Triangulation & Resilience Matrix · T16 Indices Dashboard · T17 Reporting Checklist MDL-RC 2026 · T18 Flow diagram template.

## 12. Figures (set)
F1 The 360° MDL Model (wheel) · F2 The 7-phase 360° MDL Cycle · F3 Approach A Holistic source architecture · F4 Approach B Influencers source architecture · F5 Approach C Emerging & Diverse Voices · F6 Three Gates selection funnel (Eligibility → 6R → CCD) · F7 Analytical layers & matrices (M1–M8; descriptive→generative) · F8 360° MDL Flow Diagram template (PRISMA-compatible) · F9 Keyword Coverage Matrix heatmap (example) · F10 Triangulation & Resilience matrix (example) · F11 Tiers: Lite / Standard / Advanced · F12 Positioning: 360° MDL vs PRISMA 2020 and other review types · F13 Value-Based Framework canvas.

## 13. Key references (real; use these only)
- Page, M. J., et al. (2021). The PRISMA 2020 statement: an updated guideline for reporting systematic reviews. *BMJ*, 372, n71.
- Tricco, A. C., et al. (2018). PRISMA Extension for Scoping Reviews (PRISMA-ScR). *Annals of Internal Medicine*, 169(7), 467–473.
- Grant, M. J., & Booth, A. (2009). A typology of reviews. *Health Information & Libraries Journal*, 26(2), 91–108.
- Tranfield, D., Denyer, D., & Smart, P. (2003). Towards a methodology for developing evidence-informed management knowledge by means of systematic review. *British Journal of Management*, 14(3), 207–222.
- Webster, J., & Watson, R. T. (2002). Analyzing the past to prepare for the future: Writing a literature review. *MIS Quarterly*, 26(2), xiii–xxiii.
- Torraco, R. J. (2005). Writing integrative literature reviews. *Human Resource Development Review*, 4(3), 356–367.
- Snyder, H. (2019). Literature review as a research methodology. *Journal of Business Research*, 104, 333–339.
- Paré, G., Trudel, M.-C., Jaana, M., & Kitsiou, S. (2015). Synthesizing information systems knowledge: A typology of literature reviews. *Information & Management*, 52(2), 183–199.
- Garousi, V., Felderer, M., & Mäntylä, M. V. (2019). Guidelines for including grey literature and conducting multivocal literature reviews in software engineering. *Information and Software Technology*, 106, 101–121.
- Donthu, N., Kumar, S., Mukherjee, D., Pandey, N., & Lim, W. M. (2021). How to conduct a bibliometric analysis. *Journal of Business Research*, 133, 285–296.
- Gusenbauer, M., & Haddaway, N. R. (2020). Which academic search systems are suitable for systematic reviews or meta-analyses? *Research Synthesis Methods*, 11(2), 181–217.
- Ioannidis, J. P. A., Baas, J., Klavans, R., & Boyack, K. W. (2019). A standardized citation metrics author database annotated for scientific field. *PLoS Biology*, 17(8), e3000384.
- Merton, R. K. (1968). The Matthew effect in science. *Science*, 159(3810), 56–63.
- Hicks, D., Wouters, P., Waltman, L., de Rijcke, S., & Rafols, I. (2015). Bibliometrics: The Leiden Manifesto for research metrics. *Nature*, 520, 429–431.
- Tyndall, J. (2010). *AACODS Checklist*. Flinders University.
- Elliott, J. H., et al. (2014). Living systematic reviews: an emerging opportunity to narrow the evidence-practice gap. *PLoS Medicine*, 11(2), e1001603.
- Kitchenham, B., & Charters, S. (2007). *Guidelines for performing systematic literature reviews in software engineering* (EBSE Technical Report EBSE-2007-01).
- Shannon, C. E. (1948). A mathematical theory of communication. *Bell System Technical Journal*, 27(3), 379–423.
- Cohen, J. (1960). A coefficient of agreement for nominal scales. *Educational and Psychological Measurement*, 20(1), 37–46.
- Denzin, N. K. (1978). *The research act: A theoretical introduction to sociological methods* (2nd ed.). McGraw-Hill.
- (Example paper, real items from originator's file) Mutambik, I., Lee, J., Almuqrin, A., & Zhang, J. Z. (2023). Transitioning to smart cities in Gulf Cooperation Council countries: The role of leadership and organisational culture. *Sustainability*, 15(13), 10490. · Alamoudi, A. K., Abidoye, R. B., & Lam, T. Y. M. (2023). Implementing smart sustainable cities in Saudi Arabia: A framework for citizens' participation towards Saudi Vision 2030. *Sustainability*, 15(8), 6648.

## 14. Visual identity (for figures/templates)
- Primary: Deep navy `#14213D`; Accent teal `#0F7C8C`; Accent amber `#E09F3E`; Accent coral `#C8553D`; Soft slate `#5B6B7F`; Light background `#F4F6F8`; Line grey `#D5DBE1`.
- Stream family colours: F1 Academic `#1F4E79` · F2 Influencer `#7B3F99` · F3 Industry `#E09F3E` · F4 Policy `#2A9D8F` · F5 Emerging `#C8553D`.
- Typeface: a clean sans (e.g., Inter / Source Sans 3 / Calibri for Office files).
- Footer on every figure: "360° MDL v2026 · © 2026 M. D. Lytras · CC BY 4.0".

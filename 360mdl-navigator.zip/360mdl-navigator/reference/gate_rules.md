# Gates, scoring and targets (360° MDL v2026, spec §5B–§5C, §7)

## Gate 1 — eligibility (mechanical; `mdl.py gate1 STATE rules.json`)
```json
{"years": [2015, 2026], "languages": ["English"], "exclude_types": ["erratum", "editorial", "retracted"],
 "require_any": ["smart cit", "urban"], "require_all": [], "exclude_any": []}
```
Text rules match title + abstract, case-insensitive. Records without identifier are always blocked. De-duplication runs
first (`mdl.py dedupe`): the same work found in two streams is one unique item, kept in the first stream in protocol order
(WOS, SCO, GSC, DOM, IND, GOV, HCR, T2P, GSP, RCO, ADS, INS, AUT, EMV) with a Convergence Flag (`found_in`).

## Gate 2 — the 6R scorecard (0–2 each; you propose, the researcher confirms)
Write one line of justification per criterion. Be specific: cite what in the abstract or page justifies the score.

| Criterion | 0 | 1 | 2 |
|---|---|---|---|
| **R1 Relevance** to the review questions | tangential; topic only in passing | addresses one RQ partly | addresses one or more RQs directly |
| **R2 Rigour** (grey literature: AACODS — Authority, Accuracy, Coverage, Objectivity, Date, Significance) | method unclear or weak; unknown issuing body | sound but limited (small sample, no comparison, single case) | strong design, transparent data; authoritative body with method stated |
| **R3 Reach** — field-normalised impact: citations per year since publication, not raw counts | below field norm or too recent to tell AND no other reach signal | around the norm, or policy/industry document with regional uptake | well above norm, or a reference document (standard, national strategy, flagship report) |
| **R4 Recency** relative to the review window | outside or at the edge of the window | middle of the window | last 2–3 years, or a foundational item that still frames the field |
| **R5 Richness** — depth and originality | descriptive, thin | solid evidence or framework | rich data, original framework, numbers the review can use |
| **R6 Representativeness** — adds diversity (method, region, stream, perspective) | duplicates what the corpus already has | adds one new dimension | adds a region, method, stream or perspective otherwise missing |

Decision rule (computed, never overridden): **Pass** if R1 ≥ 1 and R2 ≥ 1 and total ≥ 7; **Reserve** if total 5–6
(Extended Evidence Pool); otherwise **Exclude**.

Key 2 procedure (author's decision, 7 Nov 2026): PASS and RESERVE rows confirmed **item by item**; clear EXCLUDE rows
confirmed **in batch** after the researcher checks a random 10 % sample (`mdl.py batch-exclude`). If the sample shows an
error, show the whole batch.

## Gate 3 — CCD curation of the core corpus (`mdl.py core --auto` proposes; researcher confirms)
Complementarity: every core item adds something (cluster, method, contribution type, RQ, perspective).
Coverage: every keyword cluster covered by ≥ 3 core items (Lite ≥ 2).
Diversity: no family > 40 % of core; grey literature (F3 + F4) 10–30 % (Lite optional); F5 ≥ 10 % (Advanced ≥ 15 %);
≤ 3 items per lead author or group; ≥ 3 method families.
Core size: Lite 20–30 · Standard 40–50 · Advanced 30–50 (+ Extended Evidence Pool ≤ 30).

## Indices and targets
| Index | Formula | Lite | Standard | Advanced |
|---|---|---|---|---|
| SBI Stream Balance | H / ln k over families in the core | report | ≥ 0.70 | ≥ 0.70 |
| CovI Coverage | clusters with ≥ 3 core items (Lite ≥ 2) / clusters | report | ≥ 0.80 | ≥ 0.80 |
| MDI Method Diversity | H / ln 9 over method families | report | ≥ 0.60 | ≥ 0.60 |
| TS per finding | number of supporting families; Robust ≥ 3, Supported 2, Tentative 1 | — | — | — |
| RI Resilience | (Robust + 0.5 Supported) / findings | report | ≥ 0.60 | ≥ 0.60 |
| LOSO | worst-case share of findings with TS ≥ 2 after removing one family | — | report | ≥ 0.70 |
| Convergence Rate | core items found in ≥ 2 streams / N | report | report | report |

Stream families: F1 Academic databases (WOS, SCO, GSC, DOM) · F2 Influencer scholarship (HCR, T2P, GSP, RCO, ADS, INS, AUT)
· F3 Industry practice (IND) · F4 Policy & global organisations (GOV) · F5 Emerging & diverse voices (EMV).
Method families (9): Quantitative · Qualitative · Mixed · Design science/Artefact · Conceptual/Theoretical ·
Review/Bibliometric · Simulation/Modelling · Case study · Delphi/Expert (policy and industry documents are usually
Delphi/Expert or Conceptual; techno-economic studies are Simulation/Modelling).
Contribution types: CT1 Theoretical · CT2 Conceptual framework/model · CT3 Methodological · CT4 Empirical evidence ·
CT5 Artefact/Technological · CT6 Policy · CT7 Practice/Managerial · CT8 Societal/Educational.

# The Knowledge Distillate — how to draft it (P6, Key 4)

The Distillate is the organised discussion of the literature: what the field is about, how it is structured, what is
settled, what is contested, what is open, where research should go, and what this review could not see. A researcher should
be able to place it, lightly edited, as the discussion chapter of a thesis or the synthesis of a review article.

Draft it **only from confirmed rows** of the toolkit (core items with confirmed scores and coding; confirmed key findings).
Every claim cites item IDs in square brackets: `… [SCO-IMP-01; GOV-PP-02]`. `mdl.py distillate` refuses a claim without IDs
and a dimension without items. No sentence summarises a paper you have not read (abstract or full text).

## distillate.json
```json
{
 "phenomenon": "Four to eight paragraphs in one page: what the phenomenon is, how the streams define it, where definitions differ, the boundaries of this review. [IDs after every factual sentence]",
 "dimensions": [
   {"name": "Renewable generation in cities", "definition": "…one or two sentences… [IDs]", "clusters": [1, 7],
    "ids": ["WOS-IMP-01", "SCO-FRO-02", "GOV-PP-01"],
    "claims": ["Rooftop PV potential exceeds 20 % of peak load in the studied capitals [WOS-IMP-01; SCO-FRO-02]",
               "Policy documents set capacity targets without city-level allocation [GOV-PP-01; GOV-PP-03]"]}
 ],
 "established": [{"text": "…", "kf": "KF1", "ids": ["…"]}],
 "contested": [{"text": "…", "ids": ["…"], "note": "industry (F3) reports faster adoption than the academic studies (F1)"}],
 "open_issues": [{"text": "…", "dimension": "Renewable generation in cities", "ids": ["…"]}],
 "future_axes": [{"title": "…", "gap": "…", "dimension": "…", "methods_underused": ["Delphi/Expert", "Qualitative"],
                  "streams_needed": ["F3"], "ids": ["…"]}],
 "limitations": "From gaps_report.md, written for a reader: streams not searched, databases pending, indices below target, language and period limits.",
 "framework": {"name": "…", "stakeholders": ["Citizens", "Utilities", "Municipalities", "Investors"],
               "layers": [{"layer": "Enablers", "cells": ["…", "…", "…", "…"], "ids": ["…"], "kf": ["KF2"]}, {"layer": "Capabilities", "cells": [], "ids": [], "kf": []},
                          {"layer": "Processes", "cells": [], "ids": [], "kf": []}, {"layer": "Outcomes", "cells": [], "ids": [], "kf": []},
                          {"layer": "Value", "cells": [], "ids": [], "kf": []}, {"layer": "Measures", "cells": [], "ids": [], "kf": []}]}
}
```
`framework` is optional (Advanced tier, or when the researcher wants the Value-Based Framework canvas M8).

## How to build each part
1. **Phenomenon.** Start from the Review Canvas and the Master Table "focus" and "topics" columns. Say how F1, F3 and F4 frame
   the phenomenon differently when they do.
2. **Dimensions (4–7).** Start from the keyword clusters; merge clusters that the findings treat together; name each dimension
   as a noun phrase a reader would use as a section title. For each: definition, the clusters it covers, all core items coded to
   those clusters, and 2–5 claims. The Triangulation class of a dimension is computed from the families of its items.
3. **Established knowledge.** The Robust key findings (TS ≥ 3), rewritten as claims, each linked to its KF.
4. **Contested and emerging.** Supported and Tentative findings; places where streams disagree (name the families); what the
   emerging voices (F5) and practice (F3) say that the academic stream does not.
5. **Open research issues.** From the "limitations / open issue" coding of the core items, grouped by dimension; each issue cites
   the items that raise it.
6. **Future research axes (3–6).** Each: the gap it closes, the dimension, the methods under-used in the corpus (families with 0
   or 1 items in M2), the streams that would need to be consulted, and the items that motivate it.
7. **Limitations.** Copy the gaps report into prose. Do not soften it.

## Key 4 — the review conversation
Walk through the dimensions one by one: name, definition, items, claims. Ask: keep, rename, merge, split, reject? Then the
claims of established and contested knowledge: accept, rewrite, reject (log the reason). Then open issues and axes. Apply the
edits to distillate.json, re-run `mdl.py distillate`, and only then `mdl.py key STATE 4`.

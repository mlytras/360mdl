# Data contract — what each command expects

All commands: `python3 scripts/mdl.py COMMAND review_state.json …`. JSON files are small and written by you (the Navigator)
with your judgement; the command validates and applies them. IDs follow `[STREAM]-[SLICE]-[NN]` and are assigned by the
state (never by you): e.g. `SCO-IMP-07`, `GOV-PP-02`, `EMV-GLS-01`.

Streams: WOS SCO GSC DOM (F1) · IND (F3) · GOV (F4) · HCR T2P GSP RCO ADS INS AUT (F2) · EMV (F5).
Slices: IMP REC FRO TOP (databases) · WP (industry) · PP (policy) · MC MR (influencers) · RIS GLS REG PRE CRI (emerging) · SC (author's own).

## canvas.json
```json
{"title": "…", "purpose": "…", "rationale": "…",
 "rqs": [{"text": "What …?", "family": "What (descriptive)", "maps_to": "M1, M4 – K1, K3"}, {"text": "Why …?", "family": "Why (explanatory)"}],
 "window": "2015–2026", "languages": "English", "disciplines": "…", "doctypes": "peer-reviewed articles; policy reports; …",
 "registry": "Not registered — justification …", "calibration": "…", "update": "re-run Recency slice every 12 months",
 "inclusion": ["…"], "exclusion": ["…"], "tier": "Standard",
 "team": [["Name", "Lead reviewer", "Tasks", "Phases", "ORCID", "Notes"]],
 "matrices": {"M1": ["Y", "note"], "M2": ["Y", ""], "M3": ["Y", ""], "M4": ["Y", ""], "M5": ["N", ""], "M6": ["Y", ""], "M7": ["N", ""], "M8": ["N", ""]}}
```
## streams.json
```json
{"SCO": {"use": "Y", "slices": ["IMP", "REC"], "note": "Scopus export 2026-11-07"}, "GOV": {"use": "Y", "slices": ["PP"], "note": "…"}, "GSC": {"use": "N"}}
```
## log.json (one entry per query actually run or handed over)
```json
[{"code": "SCO", "slice": "IMP", "source": "Scopus", "date": "2026-11-07", "query": "TITLE-ABS-KEY(…)", "filters": "2015–2026; English; ar, re",
  "hits": 412, "exported": 100, "notes": "sorted by citations", "status": "run"},
 {"code": "GSC", "slice": "TOP", "source": "Google Scholar", "date": "2026-11-07", "query": "…", "filters": "…", "hits": null, "exported": null,
  "notes": "string handed over to the researcher", "status": "handed_over"}]
```
## records.json (for `add`; `import` builds the same from CSV/RIS/BibTeX/JSON)
```json
[{"stream": "GOV", "slice": "PP", "title": "…", "organisation": "World Bank", "authors": null, "year": 2023, "venue": "World Bank report",
  "doi": null, "url": "https://documents.worldbank.org/…", "abstract": "…", "open_access": "free",
  "provenance": {"source": "web search + opened page", "retrieved": "2026-11-07", "query_log": 5}}]
```
A record needs `title`, `provenance.source`, `provenance.retrieved` and at least one of `doi`, `pmid`, `openalex`, `url`.

## rules.json (Gate 1) — see gate_rules.md

## scores.json
```json
{"SCO-IMP-01": {"R1": [2, "addresses RQ1 and RQ3 directly (rooftop PV potential in Riyadh)"], "R2": [2, "GIS model on official land-lot data, method fully described"],
                "R3": [2, "≈ 9 citations/year, above the field norm"], "R4": [1, "2019, middle of the window"], "R5": [2, "quantified upper bound 4.34 GW"], "R6": [1, "adds a Saudi city case"]}}
```
## ids.json (for `core --select`): `["SCO-IMP-01", "GOV-PP-02", …]`

## clusters.json
```json
[{"name": "Renewable energy in cities", "keywords": "solar PV; rooftop PV; wind; distributed generation"}, {"name": "…", "keywords": "…"}]
```
## coding.json (core items only)
```json
{"SCO-IMP-01": {"method_family": "Simulation/Modelling", "design": "GIS-assisted capacity model", "data_source": "Riyadh Metro land-lot data",
                "sample": "4 building types", "contribution_types": ["CT4", "CT3"], "clusters": [1, 7], "rq": ["RQ1", "RQ3"],
                "key_findings": "Upper limit 4.34 GW rooftop PV ≈ 22 % of peak load …", "limitations": "technical bound only; no economics",
                "future_research": "…", "open_issue": "…", "lead_group": "Elshurafa", "focus": "Riyadh · rooftop PV potential"}}
```
## findings.json
```json
[{"id": "KF1", "text": "Urban rooftop and distributed solar potential is large across the region, but realised deployment remains marginal.",
  "rq": "RQ1", "cluster": "K1", "ids": ["WOS-IMP-01", "SCO-FRO-02", "GOV-PP-01", "EMV-GLS-01"]}]
```
Families and Triangulation Strength are derived from the IDs; you never type them.

## distillate.json — see distillate_guide.md

## confirm
`mdl.py confirm STATE --what scores --ids SCO-IMP-01,SCO-IMP-02 [--changes changes.json]` where changes.json maps an ID to a
full scores object (when the researcher altered scores). `--what core` sets core membership as confirmed (`--changes` maps ID
to true/false). `--what coding` and `--what gate1` likewise.

## Outputs of `build` (OUTDIR)
`360MDL_Toolkit_v2026_<short>_v<n>.xlsx` (master; formulas recalculated when LibreOffice is available) · `calculator.json` ·
`gaps_report.md` · `methods_draft.md` · `ai_use_statement.md` · `mdlrc_checklist.md` · `knowledge_distillate.md` +
`distillate_map.json` (when drafted) · `audit_log.jsonl` · `review_state_v<n>.json`.

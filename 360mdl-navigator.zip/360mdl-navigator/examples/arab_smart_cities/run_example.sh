#!/usr/bin/env bash
# Replays the author's published review "Energy transition for smart cities in the Arab world" through the Navigator
# (Scenario A: the author's verified records as input). Reproduces the published indices exactly.
set -e
M="$(dirname "$0")/../../scripts/mdl.py"; D="$(dirname "$0")"; S="$D/review_state.json"
rm -f "$S"
python3 "$M" init "$S" --title "Energy Transition for Smart Cities in the Arab World" --tier Standard --short ArabSmartCities
python3 "$M" canvas "$S" "$D/canvas.json";      python3 "$M" key "$S" 1 --note "replay"
python3 "$M" streams "$S" "$D/streams.json";    python3 "$M" log "$S" "$D/log.json"
python3 "$M" add "$S" "$D/records.json";        python3 "$M" dedupe "$S";   python3 "$M" gate1 "$S" "$D/rules.json"
python3 "$M" scores "$S" "$D/scores.json"
IDS=$(python3 -c "import json,sys;print(','.join(r['id'] for r in json.load(open(sys.argv[1]))['records'] if not r['duplicate_of']))" "$S")
python3 "$M" confirm "$S" --what scores --ids "$IDS";  python3 "$M" key "$S" 2 --note "replay"
python3 "$M" core "$S" --select "$D/core.json"
IDS=$(python3 -c "import json,sys;print(','.join(r['id'] for r in json.load(open(sys.argv[1]))['records'] if r['core']))" "$S")
python3 "$M" confirm "$S" --what core --ids "$IDS"
python3 "$M" clusters "$S" "$D/clusters.json";  python3 "$M" coding "$S" "$D/coding.json"
python3 "$M" findings "$S" "$D/findings.json"; python3 "$M" key "$S" 3 --note "replay"
python3 "$M" distillate "$S" "$D/distillate.json"; python3 "$M" key "$S" 4 --note "replay (test distillate)"
python3 "$M" status "$S"
python3 "$M" build "$S" "$D/output"

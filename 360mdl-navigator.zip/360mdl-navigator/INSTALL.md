# Install and start — 360° MDL Navigator (v0.1.1)

## 1. Install the skill (2 minutes)
**Claude.ai (web or desktop app):** profile menu (bottom left) → **Settings → Customize → Skills → Upload skill** → choose `360mdl-navigator.zip` as it is (do not unzip). The skill appears as *360mdl-navigator*; keep it enabled.
**Claude Code:** unzip into `.claude/skills/360mdl-navigator/` in your project folder.
Requirements inside Claude's environment: Python 3.9+, `openpyxl`, `matplotlib` (usually present). `pandoc` (Word export) and LibreOffice (formula recalculation) are optional.

## 2. Prepare (10 minutes)
- Your topic in one sentence and the tier (Lite for a short chapter, Standard for a thesis chapter or journal review, Advanced for a flagship review).
- If you already have search results: export them (Scopus → CSV with abstracts; Web of Science → tab-delimited; Zotero/EndNote → RIS or BibTeX).
- The empty toolkit is inside the skill; you do not need to download it.

## 3. Start a review
Open a new conversation (ideally inside a Project for your review), attach your exports if any, and write:

> Use the 360mdl-navigator skill. Start a 360° MDL review on "<your topic>", Standard tier. I have a Scopus export attached (stream SCO, slice IMP). Help me discover the other streams.

Without exports: `Use the 360mdl-navigator skill. Start a 360° MDL review on "<your topic>", Standard tier, from scratch.`

## 4. The four keys
The Navigator stops four times and waits for you: **Key 1** Review Canvas · **Key 2** 6R scores and core corpus (PASS and RESERVE items one by one; clear excludes in a batch after a 10 % sample) · **Key 3** key findings · **Key 4** the Knowledge Distillate, dimension by dimension. Answer in plain words ("confirm", "R6 should be 2 because…", "merge dimensions 2 and 5"). Nothing is final until you turn the key.

## 5. What you get
A folder with the official `360MDL_Toolkit_v2026_<topic>_v1.xlsx`, `calculator.json` (open it in the Index Calculator: https://mlytras.github.io/360mdl/calculator.html), `gaps_report.md`, `methods_draft.md`, `ai_use_statement.md`, `mdlrc_checklist.md`, `navigator_run_checklist.md`, the `distillate/` folder (Markdown and Word in the citation style you choose, with figures and the evidence appendix), `audit_log.jsonl` and the versioned `review_state.json`. Keep the state file: it is your review's memory for the next iteration.

## 6. Iterate
Add exports or DOIs at any time ("here is the Scopus export for the Recency slice"), ask the Navigator what would raise a weak index, and build again. Each build is a new version; compare the indices before and after.

## Help
Questions and bug reports: mlytras@acg.edu (subject "360° MDL Navigator"). Method, Playbook and calculator: https://mlytras.github.io/360mdl/

# 360° MDL Navigator — v0.1.1 (public beta)

A Claude Skill that executes the **360° MDL — Multidimensional Literature Review Model, Version 2026** for a researcher,
from a topic sentence to a verified **Core Knowledge** (filled toolkit, indices, gaps report) and a **Knowledge Distillate**
(the organised discussion of the literature), under the Two-Key Rule: the agent proposes, the researcher confirms at four keys.

Author of the method and of this tool: Miltiadis D. Lytras (Deree — The American College of Greece; Effat University).
Methodology: https://doi.org/10.5281/zenodo.23724393 · Calculator and User Guide: https://doi.org/10.5281/zenodo.24033376 ·
Site: https://mlytras.github.io/360mdl/

## Install (researcher) — see INSTALL.md for the full guide
1. Unzip this folder. In Claude.ai, create a Project for your review and add the folder as a skill (Project → Skills → Add),
   or in Claude Code copy it to `.claude/skills/360mdl-navigator/`.
2. Attach your exports if you have them (Scopus CSV, Web of Science, RIS, BibTeX, EndNote, Zotero).
3. Say: *"Start a 360° MDL review on <your topic>, Standard tier."* Then answer at the four keys.
4. Needs Python 3.9+ with `openpyxl` (`pip install openpyxl`). LibreOffice is optional (recalculates the toolkit's formulas).

## What is inside
```
SKILL.md                 the agent's instructions (role, phases, keys, guardrails)
reference/spec_v2026.md  the methodology (contract)
reference/gate_rules.md  Gate 1, 6R scoring guide, Gate 3, indices and targets
reference/data_contract.md  the JSON each command expects, ID scheme
reference/distillate_guide.md  how the Knowledge Distillate is drafted and reviewed (Key 4)
reference/handover.md    how the researcher runs Scopus / WoS / Scholar and exports for import
scripts/mdl.py           the command line: init, canvas, key, streams, log, add, import, dedupe, gate1, scores, confirm,
                         batch-exclude, core, clusters, coding, findings, distillate, author, build, status
scripts/state.py         the review state (one JSON per review) and its rules
scripts/importers.py     Scopus/WoS CSV, RIS, BibTeX, PubMed CSV, OpenAlex/Crossref JSON readers
scripts/dedupe.py, gate.py, indices.py, distillate.py, build.py, navigator_data.py, toolkit_writer.py
scripts/search/          openalex.py, crossref.py, pubmed.py, arxiv.py (documented public APIs only)
templates/360MDL_Toolkit_v2026.xlsx   the official empty toolkit
examples/arab_smart_cities/            full worked example: replays the author's published review (run_example.sh)
```

## The Knowledge Distillate
`mdl.py build` renders the Distillate in three citation styles (toolkit IDs, APA 7, Harvard), each as Markdown and Word,
with four data-driven figures (knowledge map, triangulation of findings, future-axes matrix, index profile; `--dimension-figures`
adds one per dimension), a closing section on the method, the Navigator, the tools and the researcher's profiles (`mdl.py author`),
and an evidence appendix (streams and families, most-cited items, most influential researchers
with ORCID when the source supplied it, grey literature, emerging voices). `--styles apa` selects one style.

## Verified
`examples/arab_smart_cities/run_example.sh` rebuilds the author's published review (94 records, 56 core items, 15 key findings)
and reproduces its indices exactly: SBI 0.919 · CovI 1.00 · MDI 0.859 · RI 0.90 · LOSO 0.80 · Convergence 5.4 %.
The toolkit it writes opens in the 360° MDL Index Calculator and in Excel; the workbook's own formulas (T5, T16) agree with
`scripts/indices.py`.

## Licence
Scripts: MIT. SKILL.md, reference files and templates: CC BY 4.0. © 2026 Miltiadis D. Lytras. 360° MDL is a trademark of the author.

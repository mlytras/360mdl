# -*- coding: utf-8 -*-
"""360° MDL Navigator — review state: the single JSON file that every script reads and writes.

The state is the Navigator's memory for one review. Claude (the agent) never edits it by hand: it calls the
commands in mdl.py, which validate every change and append to the audit log. Schema version 0.1.

Rules enforced here (see SKILL.md, "Guardrails"):
  * a record must carry provenance (source + retrieval date) and at least one identifier (doi / pmid / openalex / url)
  * status fields are 'proposed' until the researcher confirms them; only mdl.py confirm/… may set 'confirmed'
  * stream family is derived from the ID prefix, never typed
"""
import datetime as dt
import json
import os
import re

SCHEMA = "360mdl-navigator-state/0.1"

# ------------------------------------------------------------------ method constants (spec v2026, Lists sheet)
STREAMS = {  # code: (stream name, approach, family)
    "WOS": ("A1 Web of Science", "A", "F1"), "SCO": ("A2 Scopus", "A", "F1"), "GSC": ("A3 Google Scholar", "A", "F1"),
    "DOM": ("A6 Domain database (PubMed, IEEE Xplore, ACM DL, ERIC, OpenAlex…)", "A", "F1"),
    "IND": ("A4 Industry & consulting white papers", "A", "F3"),
    "GOV": ("A5 Government & global organisations policy papers", "A", "F4"),
    "HCR": ("B1 Clarivate Highly Cited Researchers", "B", "F2"), "T2P": ("B2 Stanford–Elsevier Top 2%", "B", "F2"),
    "GSP": ("B3 Google Scholar top profiles", "B", "F2"), "RCO": ("B4 Research.com top scientists", "B", "F2"),
    "ADS": ("B5 AD Scientific Index", "B", "F2"), "INS": ("B6 Institutional profile signal", "B", "F2"),
    "AUT": ("B* Review author's own papers (declared)", "B", "F2"),
    "EMV": ("C Emerging & diverse voices (C1–C5)", "C", "F5"),
}
FAMILY_OF = {k: v[2] for k, v in STREAMS.items()}
FAMILIES = {"F1": "Academic databases", "F2": "Influencer scholarship", "F3": "Industry practice",
            "F4": "Policy & global organisations", "F5": "Emerging & diverse voices"}
SLICES = {"IMP": "Impact – most cited", "REC": "Recency – last 2 years", "FRO": "Frontier – last 5 years / special issues",
          "TOP": "Top papers by citations (Scholar)", "WP": "White paper (industry)", "PP": "Position / policy paper",
          "MC": "Most-cited paper of influencer", "MR": "Most-recent paper of influencer",
          "RIS": "C1 Rising papers", "GLS": "C2 Global South / under-represented regions", "REG": "C3 Regional & non-English",
          "PRE": "C4 Preprints & top conference papers", "CRI": "C5 Critical, dissenting or null results",
          "SC": "Author's own papers (declared)"}
METHODS = ["Quantitative", "Qualitative", "Mixed", "Design science/Artefact", "Conceptual/Theoretical",
           "Review/Bibliometric", "Simulation/Modelling", "Case study", "Delphi/Expert"]
CTS = {"CT1": "Theoretical", "CT2": "Conceptual framework/model", "CT3": "Methodological", "CT4": "Empirical evidence",
       "CT5": "Artefact/Technological", "CT6": "Policy", "CT7": "Practice/Managerial", "CT8": "Societal/Educational"}
R_NAMES = ["R1 Relevance", "R2 Rigour", "R3 Reach", "R4 Recency", "R5 Richness", "R6 Representativeness"]
TARGETS = {
    "Lite": dict(sbi=0.70, covi=0.80, mdi=0.60, ri=0.60, loso=None, core=(20, 30), covMin=2, f5=0.10, streamsMin=3, greyReq=False),
    "Standard": dict(sbi=0.70, covi=0.80, mdi=0.60, ri=0.60, loso=None, core=(40, 50), covMin=3, f5=0.10, streamsMin=4, greyReq=True),
    "Advanced": dict(sbi=0.70, covi=0.80, mdi=0.60, ri=0.60, loso=0.70, core=(30, 50), covMin=3, f5=0.15, streamsMin=5, greyReq=True),
}
ID_RE = re.compile(r"^([A-Z]{3})-([A-Z]{2,3})-(\d{2,3})$")


def now():
    return dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()


def today():
    return dt.date.today().isoformat()


# ------------------------------------------------------------------ state I/O
def new_state(title, tier="Standard", short=None, researcher=None):
    assert tier in TARGETS, f"tier must be one of {list(TARGETS)}"
    short = short or re.sub(r"[^A-Za-z0-9]+", "_", title)[:40].strip("_")
    return {
        "schema": SCHEMA,
        "meta": {"title": title, "short": short, "tier": tier, "mode": "360", "created": now(), "updated": now(),
                 "version": 1, "researcher": researcher or {}, "navigator": "360° MDL Navigator v0.1"},
        "canvas": {"title": title, "tier": tier, "mode": "360", "rqs": [], "inclusion": [], "exclusion": [],
                   "team": [], "ai": [], "status": "draft"},
        "streams": {},          # code -> {"use": "Y", "slices": [...], "note": ""}
        "stream_log": [],       # dicts: log, code, slice, source, date, query, filters, hits, exported, notes
        "clusters": [],         # dicts: k, name, keywords
        "records": [],
        "key_findings": [],     # dicts: id, text, rq, cluster, families, ids, status
        "distillate": None,
        "keys": {},             # key1..key4 -> {"turned_at", "by", "note"}
        "audit": [],
    }


def load(path):
    with open(path, encoding="utf-8") as f:
        st = json.load(f)
    assert st.get("schema") == SCHEMA, f"not a Navigator state file (schema {st.get('schema')})"
    return st


def save(st, path):
    st["meta"]["updated"] = now()
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(st, f, ensure_ascii=False, indent=1)
    os.replace(tmp, path)


def audit(st, action, by="navigator", **detail):
    st["audit"].append({"at": now(), "by": by, "action": action, **detail})


# ------------------------------------------------------------------ records
def family_of(rec_id):
    m = ID_RE.match(rec_id or "")
    return FAMILY_OF.get(m.group(1)) if m else None


def next_id(st, stream, slice_):
    assert stream in STREAMS, f"unknown stream code {stream}"
    assert slice_ in SLICES, f"unknown slice code {slice_}"
    n = 1 + sum(1 for r in st["records"] if r["id"].startswith(f"{stream}-{slice_}-"))
    return f"{stream}-{slice_}-{n:02d}"


def has_identifier(rec):
    return any(rec.get(k) for k in ("doi", "pmid", "openalex", "url"))


def add_record(st, stream, slice_, title, provenance, **fields):
    """Add a candidate record. provenance = {"source": "openalex", "query_log": 3, "retrieved": "2026-11-07"}.
    Refuses a record with no identifier (doi / pmid / openalex / url) unless fields['unverified'] is True."""
    rec = {"id": next_id(st, stream, slice_), "stream": stream, "slice": slice_, "family": FAMILY_OF[stream],
           "title": (title or "").strip(), "authors": None, "organisation": None, "year": None, "venue": None,
           "doi": None, "url": None, "pmid": None, "openalex": None, "orcid": None, "abstract": None, "open_access": None,
           "provenance": provenance, "found_in": [stream], "duplicate_of": None,
           "gate1": {"status": "pending", "reason": None},
           "sixR": None, "sixR_status": None, "decision": None,
           "core": False, "core_status": None, "coding": {}, "unverified": False}
    rec.update({k: v for k, v in fields.items() if k in rec or k.startswith("_")})
    if not rec.get("doi") and rec.get("url") and "doi.org/" in rec["url"]:
        rec["doi"] = re.sub(r"^.*doi\.org/", "", rec["url"]).strip().lower()
    assert rec["title"], "record needs a title"
    assert provenance and provenance.get("source") and provenance.get("retrieved"), "record needs provenance"
    if not has_identifier(rec):
        if fields.get("unverified"):
            rec["unverified"] = True
        else:
            raise ValueError(f"record '{rec['title'][:60]}' has no DOI / PMID / OpenAlex ID / URL — refused (Guardrail 2)")
    st["records"].append(rec)
    return rec


def rec_by_id(st, rid):
    for r in st["records"]:
        if r["id"] == rid:
            return r
    raise KeyError(rid)


def decision_of(sixR):
    """6R decision rule (spec §5B): Pass if R1 ≥ 1, R2 ≥ 1 and total ≥ 7; Reserve if total 5–6; else Exclude."""
    if not sixR or any(f"R{i}" not in sixR for i in range(1, 7)):
        return None
    s = [int(sixR[f"R{i}"][0]) for i in range(1, 7)]
    t = sum(s)
    if s[0] >= 1 and s[1] >= 1 and t >= 7:
        return "Pass"
    return "Reserve" if 5 <= t <= 6 else "Exclude"


def set_scores(st, rid, scores, by="navigator"):
    """scores = {"R1": [2, "why"], ... "R6": [...]}; stays 'proposed' until confirmed."""
    rec = rec_by_id(st, rid)
    for i in range(1, 7):
        k = f"R{i}"
        assert k in scores and len(scores[k]) == 2 and int(scores[k][0]) in (0, 1, 2), f"{rid}: bad {k}"
        assert str(scores[k][1]).strip(), f"{rid}: {k} needs a one-line justification"
    rec["sixR"] = {f"R{i}": [int(scores[f"R{i}"][0]), str(scores[f"R{i}"][1]).strip()] for i in range(1, 7)}
    rec["decision"] = decision_of(rec["sixR"])
    rec["sixR_status"] = "proposed" if by == "navigator" else "confirmed"
    return rec


def confirm(st, rid, what, by="researcher", change=None):
    """Turn a key on one record: what in {'gate1','scores','core','coding'}. change = optional new values."""
    rec = rec_by_id(st, rid)
    if what == "scores":
        if change:
            set_scores(st, rid, change, by=by)
        assert rec["sixR"], f"{rid}: no scores to confirm"
        rec["sixR_status"] = "confirmed"
    elif what == "core":
        if change is not None:
            rec["core"] = bool(change)
        rec["core_status"] = "confirmed"
    elif what == "gate1":
        if change:
            rec["gate1"].update(change)
        rec["gate1"]["confirmed"] = True
    elif what == "coding":
        if change:
            rec["coding"].update(change)
        rec["coding"]["status"] = "confirmed"
    else:
        raise ValueError(what)
    audit(st, f"confirm:{what}", by=by, id=rid, change=change)
    return rec


def counts(st):
    recs = [r for r in st["records"] if not r["duplicate_of"]]
    elig = [r for r in recs if r["gate1"]["status"] == "eligible"]
    out = {"harvested": len(st["records"]), "unique": len(recs), "eligible": len(elig),
           "pass": sum(1 for r in elig if r["decision"] == "Pass"),
           "reserve": sum(1 for r in elig if r["decision"] == "Reserve"),
           "exclude": sum(1 for r in elig if r["decision"] == "Exclude"),
           "unscored": sum(1 for r in elig if not r["decision"]),
           "core": sum(1 for r in recs if r["core"])}
    out["pool"] = max(0, out["pass"] - out["core"])
    return out

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""360° MDL Navigator — command line. Every command reads and writes ONE state file and appends to its audit log.

  mdl.py init STATE --title "…" --tier Standard [--short NAME]
  mdl.py canvas STATE canvas.json                 # set / update T1 fields (Navigator proposal)
  mdl.py key STATE 1|2|3|4 [--note "…"]            # the researcher turns a key (recorded, never implied)
  mdl.py streams STATE streams.json               # which streams/slices are used: {"SCO": {"use":"Y","slices":["IMP","REC"],"note":""}}
  mdl.py log STATE log.json                       # append stream-log entries (queries actually run)
  mdl.py add STATE records.json                   # add candidate records (list; each with provenance + identifier)
  mdl.py import STATE FILE --stream SCO --slice IMP --source "Scopus export" [--date YYYY-MM-DD]   # CSV/RIS/BibTeX/JSON exports
  mdl.py dedupe STATE                             # DOI then title similarity; marks duplicate_of, found_in (convergence)
  mdl.py gate1 STATE [rules.json]                 # eligibility: years, languages, doc types, required keywords; marks eligible/excluded
  mdl.py scores STATE scores.json                 # proposed 6R: {"SCO-IMP-01": {"R1":[2,"why"],…}}
  mdl.py confirm STATE --what scores|core|gate1|coding --ids ID,ID… [--changes changes.json]   # researcher's key on rows
  mdl.py batch-exclude STATE --sample 0.10        # Key 2 helper: lists clear Excludes and a random sample to check
  mdl.py core STATE [--select ids.json | --auto]  # propose / set the core corpus (auto = all Pass, CCD-curated to tier max)
  mdl.py clusters STATE clusters.json             # [{"k":1,"name":"…","keywords":"…"}]
  mdl.py coding STATE coding.json                 # per core item: method_family, design, contribution_types, clusters, rq, key_findings, limitations…
  mdl.py findings STATE findings.json             # key findings: [{"id":"KF1","text":"…","rq":"RQ1","cluster":"K1","ids":[…]}] (families derived)
  mdl.py distillate STATE distillate.json         # Knowledge Distillate draft (checked: every claim cites IDs)
  mdl.py build STATE OUTDIR                       # toolkit xlsx + calculator.json + indices + gaps report + methods draft + checklist + audit
  mdl.py status STATE                             # counts, indices, what is proposed vs confirmed, next step
"""
import argparse
import json
import os
import random
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import state as S  # noqa: E402


def jl(p):
    with open(p, encoding="utf-8") as f:
        return json.load(f)


def cmd_init(a):
    st = S.new_state(a.title, a.tier, a.short, {"name": a.researcher} if a.researcher else None)
    S.audit(st, "init", title=a.title, tier=a.tier)
    S.save(st, a.state)
    print(f"created {a.state} · {a.title} · {a.tier}")


def cmd_canvas(a):
    st = S.load(a.state)
    c = jl(a.file)
    st["canvas"].update(c)
    st["canvas"]["status"] = "proposed"
    if "title" in c:
        st["meta"]["title"] = c["title"]
    if "tier" in c:
        assert c["tier"] in S.TARGETS
        st["meta"]["tier"] = c["tier"]
    S.audit(st, "canvas:update", fields=sorted(c))
    S.save(st, a.state)
    print("canvas updated:", ", ".join(sorted(c)))


def cmd_key(a):
    st = S.load(a.state)
    k = f"key{a.key}"
    pre = {"1": lambda: st["canvas"].get("status") in ("proposed", "confirmed") and st["canvas"].get("rqs"),
           "2": lambda: any(r.get("sixR") for r in st["records"]),
           "3": lambda: st["key_findings"],
           "4": lambda: st["distillate"]}[a.key]()
    assert pre, f"nothing to confirm for key {a.key} yet"
    st["keys"][k] = {"turned_at": S.now(), "by": "researcher", "note": a.note}
    if a.key == "1":
        st["canvas"]["status"] = "confirmed"
    if a.key == "3":
        for kf in st["key_findings"]:
            kf["status"] = "confirmed"
    if a.key == "4":
        st["distillate"]["status"] = "confirmed"
    S.audit(st, f"key:{a.key}", by="researcher", note=a.note)
    S.save(st, a.state)
    print(f"Key {a.key} turned by the researcher.")


def cmd_streams(a):
    st = S.load(a.state)
    d = jl(a.file)
    for code, v in d.items():
        assert code in S.STREAMS, code
        for s in v.get("slices", []):
            assert s in S.SLICES, s
    st["streams"].update(d)
    S.audit(st, "streams:update", codes=sorted(d))
    S.save(st, a.state)
    print("streams:", ", ".join(f"{c}({'Y' if v.get('use') == 'Y' else 'N'})" for c, v in st["streams"].items()))


def cmd_log(a):
    st = S.load(a.state)
    for e in jl(a.file):
        assert e.get("code") in S.STREAMS and e.get("query") and e.get("date"), e
        e["log"] = len(st["stream_log"]) + 1
        st["stream_log"].append(e)
    S.audit(st, "log:append", n=len(jl(a.file)))
    S.save(st, a.state)
    print(f"stream log: {len(st['stream_log'])} entries")


def cmd_add(a):
    st = S.load(a.state)
    added, refused = [], []
    for r in jl(a.file):
        try:
            prov = r.pop("provenance")
            stream, slice_, title = r.pop("stream"), r.pop("slice"), r.pop("title")
            rec = S.add_record(st, stream, slice_, title, prov, **r)
            added.append(rec["id"])
        except Exception as e:  # noqa: BLE001
            refused.append(f"{r.get('title', '?')[:60]}: {e}")
    S.audit(st, "records:add", added=len(added), refused=len(refused), file=os.path.basename(a.file))
    S.save(st, a.state)
    print(f"added {len(added)} records; refused {len(refused)}")
    for x in refused:
        print("  refused:", x)


def cmd_import(a):
    import importers
    st = S.load(a.state)
    recs = importers.read_any(a.file)
    date = a.date or S.today()
    prov = {"source": a.source, "file": os.path.basename(a.file), "retrieved": date}
    added, refused = [], []
    for r in recs:
        try:
            title = r.pop("title", None)
            rec = S.add_record(st, a.stream, a.slice, title, dict(prov), **r)
            added.append(rec["id"])
        except Exception as e:  # noqa: BLE001
            refused.append(f"{str(title)[:60]}: {e}")
    S.audit(st, "records:import", file=os.path.basename(a.file), stream=a.stream, slice=a.slice, added=len(added), refused=len(refused))
    S.save(st, a.state)
    print(f"imported {len(added)} records from {os.path.basename(a.file)} into {a.stream}-{a.slice}; refused {len(refused)}")
    for x in refused[:20]:
        print("  refused:", x)


def cmd_dedupe(a):
    import dedupe
    st = S.load(a.state)
    n = dedupe.run(st)
    S.audit(st, "dedupe", merged=n)
    S.save(st, a.state)
    print(f"de-duplication: {n} duplicates merged (kept in first stream in protocol order; Convergence Flag set)")


def cmd_gate1(a):
    import gate
    st = S.load(a.state)
    rules = jl(a.rules) if a.rules else {}
    res = gate.gate1(st, rules)
    S.audit(st, "gate1", **res)
    S.save(st, a.state)
    print("Gate 1:", res)


def cmd_scores(a):
    st = S.load(a.state)
    d = jl(a.file)
    n = 0
    for rid, sc in d.items():
        S.set_scores(st, rid, sc, by="navigator")
        n += 1
    S.audit(st, "scores:propose", n=n)
    S.save(st, a.state)
    c = S.counts(st)
    print(f"proposed 6R for {n} records · Gate 2 now: {c['pass']} Pass, {c['reserve']} Reserve, {c['exclude']} Exclude, {c['unscored']} unscored")


def cmd_confirm(a):
    st = S.load(a.state)
    ids = [x.strip() for x in a.ids.split(",") if x.strip()]
    changes = jl(a.changes) if a.changes else {}
    for rid in ids:
        S.confirm(st, rid, a.what, by="researcher", change=changes.get(rid))
    S.save(st, a.state)
    print(f"confirmed {a.what} for {len(ids)} records ({len(changes)} with changes)")


def cmd_batch_exclude(a):
    st = S.load(a.state)
    exc = [r for r in st["records"] if not r["duplicate_of"] and r["decision"] == "Exclude" and r.get("sixR_status") == "proposed"]
    random.seed(a.seed)
    k = max(1, round(len(exc) * a.sample)) if exc else 0
    sample = random.sample(exc, k) if exc else []
    print(f"{len(exc)} records proposed as Exclude. Random sample of {k} to check before batch confirmation:")
    for r in sample:
        tot = sum(v[0] for v in r["sixR"].values())
        print(f"  {r['id']} · {r['title'][:80]} · total {tot} · R1 {r['sixR']['R1'][0]}: {r['sixR']['R1'][1][:70]}")
    print("If the sample is right, confirm all with:  mdl.py confirm STATE --what scores --ids " + ",".join(r["id"] for r in exc))


def cmd_core(a):
    import gate
    st = S.load(a.state)
    if a.select:
        ids = set(jl(a.select))
        for r in st["records"]:          # a selected record merged as a duplicate: swap it with the kept one
            if r["id"] in ids and r["duplicate_of"]:
                k = S.rec_by_id(st, r["duplicate_of"])
                k["duplicate_of"], r["duplicate_of"] = r["id"], None
                r["gate1"] = dict(k["gate1"])
                r["found_in"], k["found_in"] = sorted(set(k["found_in"]) | set(r["found_in"])), [k["stream"]]
                for x in st["records"]:
                    if x["duplicate_of"] == k["id"] and x is not r:
                        x["duplicate_of"] = r["id"]
        for r in st["records"]:
            r["core"] = r["id"] in ids
            r["core_status"] = "proposed"
        res = {"selected": len(ids)}
    else:
        res = gate.propose_core(st)
    S.audit(st, "core:propose", **res)
    S.save(st, a.state)
    print("core corpus proposed:", res)


def cmd_clusters(a):
    st = S.load(a.state)
    cl = jl(a.file)
    assert 1 <= len(cl) <= 10 and all("name" in c for c in cl)
    st["clusters"] = [{"k": i + 1, "name": c["name"], "keywords": c.get("keywords", "")} for i, c in enumerate(cl)]
    S.audit(st, "clusters:set", n=len(cl))
    S.save(st, a.state)
    print("clusters:", "; ".join(f"K{c['k']} {c['name']}" for c in st["clusters"]))


def cmd_coding(a):
    st = S.load(a.state)
    d = jl(a.file)
    allowed = {"method_family", "design", "data_source", "sample", "contribution_types", "clusters", "rq", "key_findings",
               "limitations", "future_research", "open_issue", "lead_group", "focus", "own_rq"}
    n = 0
    for rid, cd in d.items():
        rec = S.rec_by_id(st, rid)
        bad = set(cd) - allowed
        assert not bad, f"{rid}: unknown coding fields {bad}"
        if "method_family" in cd:
            assert cd["method_family"] in S.METHODS, f"{rid}: method_family must be one of {S.METHODS}"
        if "contribution_types" in cd:
            assert all(c in S.CTS for c in cd["contribution_types"]), f"{rid}: CT codes"
        if "clusters" in cd:
            assert all(1 <= int(c) <= len(st["clusters"]) for c in cd["clusters"]), f"{rid}: cluster numbers"
        rec["coding"].update(cd)
        rec["coding"]["status"] = "proposed"
        n += 1
    S.audit(st, "coding:propose", n=n)
    S.save(st, a.state)
    print(f"coding proposed for {n} records")


def cmd_findings(a):
    st = S.load(a.state)
    kfs = jl(a.file)
    out = []
    for i, k in enumerate(kfs):
        ids = k.get("ids") or []
        assert ids, f"{k.get('id', i)}: a key finding must cite item IDs"
        fams = sorted({S.rec_by_id(st, x)["family"] for x in ids})
        out.append({"id": k.get("id") or f"KF{i + 1}", "text": k["text"], "rq": k.get("rq"), "cluster": k.get("cluster"),
                    "ids": ids, "families": fams, "status": "proposed"})
    st["key_findings"] = out
    S.audit(st, "findings:propose", n=len(out))
    S.save(st, a.state)
    print(f"{len(out)} key findings proposed; families derived from the cited IDs")


def cmd_distillate(a):
    import distillate
    st = S.load(a.state)
    d = jl(a.file)
    problems = distillate.validate(st, d)
    if problems:
        print("Distillate refused:")
        for p in problems:
            print("  -", p)
        sys.exit(2)
    d["status"] = "proposed"
    st["distillate"] = d
    S.audit(st, "distillate:propose", parts=sorted(d))
    S.save(st, a.state)
    print("Knowledge Distillate draft stored (every claim cites IDs). Ask the researcher for Key 4.")


def cmd_author(a):
    """author.json: {"name": "…", "affiliation": "…", "orcid": "…", "bio": "…", "profiles": [{"label": "ORCID", "url": "https://orcid.org/…"}]}"""
    st = S.load(a.state)
    d = jl(a.file)
    for p in d.get("profiles", []):
        assert p.get("label") and str(p.get("url", "")).startswith("http"), f"profile needs label and http(s) url: {p}"
    st["meta"]["researcher"] = {**(st["meta"].get("researcher") or {}), **d}
    S.audit(st, "author:set", fields=sorted(d))
    S.save(st, a.state)
    print("author:", st["meta"]["researcher"].get("name"), "·", len(d.get("profiles", [])), "profile links")


def cmd_build(a):
    import build
    st = S.load(a.state)
    out = build.run(st, a.state, a.outdir, styles=tuple(a.styles.split(",")), dimension_figures=a.dimension_figures)
    S.audit(st, "build", outdir=a.outdir, files=sorted(out))
    S.save(st, a.state)
    for f in out:
        print(" ", f)


def cmd_status(a):
    import indices
    st = S.load(a.state)
    c = S.counts(st)
    print(f"{st['meta']['title']} · {st['meta']['tier']} tier · state v{st['meta']['version']}")
    print(f"Canvas: {st['canvas'].get('status')} · keys turned: {', '.join(st['keys']) or 'none'}")
    print(f"Records: {c}")
    prop = sum(1 for r in st['records'] if r.get('sixR_status') == 'proposed')
    print(f"6R: {prop} proposed, {sum(1 for r in st['records'] if r.get('sixR_status') == 'confirmed')} confirmed")
    print(f"Clusters: {len(st['clusters'])} · key findings: {len(st['key_findings'])} · distillate: {(st['distillate'] or {}).get('status')}")
    R = indices.compute(st)
    print(f"Indices: SBI {R['sbi']:.2f} · CovI {R['covi'] if R['covi'] is None else round(R['covi'], 2)} · MDI {R['mdi'] if R['mdi'] is None else round(R['mdi'], 2)} · "
          f"RI {R['ri'] if R['ri'] is None else round(R['ri'], 2)} · LOSO {R['losoMin'] if R['losoMin'] is None else round(R['losoMin'], 2)} · N {R['N']}")
    print("Next:", indices.next_step(st))


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sp = p.add_subparsers(dest="cmd", required=True)
    x = sp.add_parser("init"); x.add_argument("state"); x.add_argument("--title", required=True); x.add_argument("--tier", default="Standard")
    x.add_argument("--short"); x.add_argument("--researcher"); x.set_defaults(f=cmd_init)
    for name, fn in [("canvas", cmd_canvas), ("streams", cmd_streams), ("log", cmd_log), ("add", cmd_add), ("scores", cmd_scores),
                     ("clusters", cmd_clusters), ("coding", cmd_coding), ("findings", cmd_findings), ("distillate", cmd_distillate)]:
        x = sp.add_parser(name); x.add_argument("state"); x.add_argument("file"); x.set_defaults(f=fn)
    x = sp.add_parser("key"); x.add_argument("state"); x.add_argument("key", choices=["1", "2", "3", "4"]); x.add_argument("--note"); x.set_defaults(f=cmd_key)
    x = sp.add_parser("import"); x.add_argument("state"); x.add_argument("file"); x.add_argument("--stream", required=True)
    x.add_argument("--slice", required=True); x.add_argument("--source", required=True); x.add_argument("--date"); x.set_defaults(f=cmd_import)
    x = sp.add_parser("dedupe"); x.add_argument("state"); x.set_defaults(f=cmd_dedupe)
    x = sp.add_parser("gate1"); x.add_argument("state"); x.add_argument("rules", nargs="?"); x.set_defaults(f=cmd_gate1)
    x = sp.add_parser("confirm"); x.add_argument("state"); x.add_argument("--what", required=True, choices=["scores", "core", "gate1", "coding"])
    x.add_argument("--ids", required=True); x.add_argument("--changes"); x.set_defaults(f=cmd_confirm)
    x = sp.add_parser("batch-exclude"); x.add_argument("state"); x.add_argument("--sample", type=float, default=0.10); x.add_argument("--seed", type=int, default=360); x.set_defaults(f=cmd_batch_exclude)
    x = sp.add_parser("core"); x.add_argument("state"); x.add_argument("--select"); x.add_argument("--auto", action="store_true"); x.set_defaults(f=cmd_core)
    x = sp.add_parser("build"); x.add_argument("state"); x.add_argument("outdir"); x.add_argument("--styles", default="ids,apa,harvard", help="citation styles for the Distillate: ids, apa, harvard")
    x.add_argument("--dimension-figures", action="store_true", help="also draw one figure per dimension"); x.set_defaults(f=cmd_build)
    x = sp.add_parser("author"); x.add_argument("state"); x.add_argument("file"); x.set_defaults(f=cmd_author)
    x = sp.add_parser("status"); x.add_argument("state"); x.set_defaults(f=cmd_status)
    a = p.parse_args()
    a.f(a)


if __name__ == "__main__":
    main()

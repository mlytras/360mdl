# -*- coding: utf-8 -*-
"""D4b Evidence Landscape Report — who shapes the evidence of a 360° MDL review.

Companion to D4 (Core Corpus & Flow Diagram), produced at the same stage as the toolkit workbook. It answers three questions
from the records already in the state, with nothing added from memory:
  1. Influencers  — which authors dominate the eligible pool (top-10 by productivity, top-10 by citations) and which of them
                    reach the core; the influencer-stream (F2) papers in the core and the role they play.
  2. Most cited   — the most-cited core items, the most-cited eligible records and their status, and the rising records
                    (fastest citations per year in the last three years).
  3. Emerging     — the Emerging & Diverse Voices family (F5) by slice and Gate 2 decision, and every F5 core item with its role.
Citation counts are the ones carried by the imported exports (Scopus 'Cited by', WoS 'TC', OpenAlex cited_by_count).
Writes D4b_Evidence_Landscape_<short>_v<n>.docx, a Markdown twin and two figures. Usage: mdl.py landscape STATE OUTDIR
"""
import datetime as dt
import os
import re
import sys
from collections import Counter, defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import state as S  # noqa: E402
import cite  # noqa: E402

NAVY, TEAL, GREY = "14213D", "0F7C8C", "6B7280"
FAMC = {"F1": "1F4E79", "F2": "7B3F99", "F3": "2A9D8F", "F4": "E09F3E", "F5": "C8553D"}
SLICE_ORDER = ["RIS", "GLS", "REG", "CRI", "PRE"]
SLICE_NAME = {"RIS": "Rising", "GLS": "Global South & regional", "REG": "Regional & non-English", "CRI": "Critical & dissenting",
              "PRE": "Preprints & conference"}


# ------------------------------------------------------------------ data
def _c(r):
    v = r.get("_cited_by")
    try:
        return int(str(v).strip())
    except (TypeError, ValueError):
        return None


def _y(r):
    try:
        return int(str(r.get("year"))[:4])
    except (TypeError, ValueError):
        return None


def _cpy(r, now):
    c, y = _c(r), _y(r)
    return None if c is None or y is None else round(c / max(1, now - y + 1), 1)


def _authors(r):
    a = (r.get("authors") or "").strip()
    if not a:
        return []
    return [f"{f}, {i}".strip(", ") for f, i in cite.surnames(r)]


def _short(t, n=92):
    t = (t or "").strip()
    return t if len(t) <= n else t[:n - 1].rsplit(" ", 1)[0] + "…"


def _role(r):
    c = r.get("coding") or {}
    return c.get("focus") or _short(c.get("key_findings") or "", 110) or "—"


def collect(st):
    now = dt.date.today().year
    recs = [r for r in st["records"] if not r.get("duplicate_of")]
    el = [r for r in recs if (r.get("gate1") or {}).get("status") == "eligible"]
    core = [r for r in el if r.get("core")]
    kf_of = defaultdict(list)
    for k in st.get("key_findings", []):
        for i in k.get("ids", []):
            kf_of[i].append(k["id"])
    has_cites = sum(1 for r in el if _c(r) is not None)
    # authors in the eligible pool
    pap, cit, mc = Counter(), Counter(), {}
    for r in el:
        for a in _authors(r):
            pap[a] += 1
            cit[a] += _c(r) or 0
            if a not in mc or (_c(r) or -1) > (_c(mc[a]) or -1):
                mc[a] = r
    prod = sorted(pap, key=lambda a: (-pap[a], -cit[a]))[:10]
    floor = 3 if len(el) > 300 else 2  # an influential author has a body of work on the topic, not one hit
    infl = [a for a in sorted(cit, key=lambda a: (-cit[a], -pap[a])) if a not in prod and pap[a] >= floor][:10]
    infl_rows = []
    for rule, lst in (("Productivity", prod), ("Citations", infl)):
        for a in lst:
            in_core = [r for r in core if a in _authors(r)]
            infl_rows.append(dict(rule=rule, author=a, n=pap[a], c=cit[a], mc=mc[a], core=in_core))
    f2 = [r for r in core if r.get("family") == "F2"]
    ranked_core = sorted([r for r in core if _c(r) is not None], key=lambda r: -_c(r))
    top_el = sorted([r for r in el if _c(r) is not None and _y(r)], key=lambda r: -_c(r))[:12]
    rising = sorted([r for r in el if _c(r) and _y(r) and _y(r) >= now - 3], key=lambda r: -_cpy(r, now))[:10]
    f5_pool = [r for r in el if r.get("family") == "F5"]
    sl = Counter((r.get("slice"), r.get("decision") or "—") for r in f5_pool)
    f5 = sorted([r for r in core if r.get("family") == "F5"],
                key=lambda r: (SLICE_ORDER.index(r.get("slice")) if r.get("slice") in SLICE_ORDER else 9, -(_c(r) or 0)))
    fam = Counter(r.get("family") for r in core)
    return dict(now=now, el=el, core=core, kf_of=kf_of, has_cites=has_cites, infl=infl_rows, f2=f2, ranked_core=ranked_core,
                top_el=top_el, rising=rising, f5_pool=f5_pool, sl=sl, f5=f5, fam=fam)


# ------------------------------------------------------------------ figures
def figures(d, outdir, short):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.patches import Patch
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9})
    out = {}
    top = d["ranked_core"][:15]
    if top:
        fig, ax = plt.subplots(figsize=(7.2, 0.3 * len(top) + 1.2), dpi=220)
        rows = top[::-1]
        ax.barh([cite.intext(r, "apa") for r in rows], [_c(r) for r in rows], color=["#" + FAMC.get(r.get("family"), "888888") for r in rows], height=.66)
        mx = max(_c(r) for r in top)
        for j, r in enumerate(rows):
            ax.text(_c(r) + mx * .012, j, f"{_c(r)}  ({_cpy(r, d['now'])}/yr)", va="center", fontsize=7.6, color="#333")
        ax.set_xlim(0, mx * 1.22)
        ax.spines[["top", "right"]].set_visible(False)
        ax.set_xlabel("Citations (as exported)")
        fams = sorted({r.get("family") for r in top})
        ax.legend(handles=[Patch(color="#" + FAMC[f], label=f"{f} {S.FAMILIES[f]}") for f in fams], frameon=False, loc="lower right", fontsize=7.5)
        plt.tight_layout()
        p = os.path.join(outdir, f"D4b_fig1_most_cited_{short}.png")
        plt.savefig(p)
        plt.close()
        out["cited"] = p
    if d["f5_pool"]:
        sls = [s for s in SLICE_ORDER if any(k[0] == s for k in d["sl"])]
        fig, ax = plt.subplots(figsize=(7.2, 0.42 * len(sls) + 1.3), dpi=220)
        left = [0] * len(sls)
        for dec, col in (("Pass", "#2A9D8F"), ("Reserve", "#E09F3E"), ("Exclude", "#B9B9B9")):
            v = [d["sl"].get((s, dec), 0) for s in sls]
            ax.barh([f"{s} {SLICE_NAME[s]}" for s in sls][::-1], v[::-1], left=left[::-1], color=col, label=dec, height=.6)
            left = [a + b for a, b in zip(left, v)]
        mx = max(left) or 1
        for j, s in enumerate(sls[::-1]):
            tot = left[::-1][j]
            ax.text(tot + mx * .015, j, f"{tot}  ·  core {sum(1 for r in d['f5'] if r.get('slice') == s)}", va="center", fontsize=7.6)
        ax.set_xlim(0, mx * 1.25)
        ax.spines[["top", "right"]].set_visible(False)
        ax.legend(frameon=False, ncol=3, loc="lower right", fontsize=7.5)
        ax.set_xlabel("Eligible F5 records by Gate 2 decision")
        plt.tight_layout()
        p = os.path.join(outdir, f"D4b_fig2_emerging_voices_{short}.png")
        plt.savefig(p)
        plt.close()
        out["f5"] = p
    return out


# ------------------------------------------------------------------ docx helpers
def _doc():
    from docx import Document
    from docx.shared import Pt, Cm
    doc = Document()
    sec = doc.sections[0]
    sec.page_width, sec.page_height = Cm(21), Cm(29.7)
    sec.left_margin = sec.right_margin = Cm(2.0)
    sec.top_margin = sec.bottom_margin = Cm(2.0)
    st = doc.styles["Normal"]
    st.font.name, st.font.size = "Georgia", Pt(10.5)
    st.paragraph_format.space_after = Pt(6)
    st.paragraph_format.line_spacing = 1.2
    return doc


def _run(p, text, size=None, bold=False, italic=False, color=None, font=None):
    from docx.shared import Pt, RGBColor
    r = p.add_run(text)
    r.bold, r.italic = bold, italic
    if size:
        r.font.size = Pt(size)
    if color:
        r.font.color.rgb = RGBColor.from_string(color)
    if font:
        r.font.name = font
    return r


def _md(p, text, **kw):
    for part in re.split(r"(\*[^*]+\*)", text):
        if part.startswith("*") and part.endswith("*") and len(part) > 2:
            _run(p, part[1:-1], italic=True, **kw)
        elif part:
            _run(p, part, **kw)


def _shade(cell, fill):
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    tcPr = cell._tc.get_or_add_tcPr()
    sh = OxmlElement("w:shd")
    sh.set(qn("w:val"), "clear"); sh.set(qn("w:color"), "auto"); sh.set(qn("w:fill"), fill)
    tcPr.append(sh)


def _borders(table, color="C9D1DB"):
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    tblPr = table._tbl.tblPr
    b = OxmlElement("w:tblBorders")
    for e in ("top", "left", "bottom", "right", "insideH", "insideV"):
        x = OxmlElement(f"w:{e}")
        x.set(qn("w:val"), "single"); x.set(qn("w:sz"), "4"); x.set(qn("w:color"), color); x.set(qn("w:space"), "0")
        b.append(x)
    tblPr.append(b)


def _fixed(t, W):
    """Fixed layout with an explicit grid, so Word and LibreOffice both honour the column widths."""
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    tblPr = t._tbl.tblPr
    lay = OxmlElement("w:tblLayout"); lay.set(qn("w:type"), "fixed"); tblPr.append(lay)
    tw = OxmlElement("w:tblW"); tw.set(qn("w:w"), str(sum(int(w.twips) for w in W))); tw.set(qn("w:type"), "dxa"); tblPr.append(tw)
    for gc, w in zip(t._tbl.tblGrid.findall(qn("w:gridCol")), W):
        gc.set(qn("w:w"), str(int(w.twips)))


def _repeat_header(row):
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    trPr = row._tr.get_or_add_trPr()
    h = OxmlElement("w:tblHeader"); h.set(qn("w:val"), "true"); trPr.append(h)
    c = OxmlElement("w:cantSplit"); c.set(qn("w:val"), "true")


def H1(doc, t):
    from docx.shared import Pt
    p = doc.add_paragraph()
    p.paragraph_format.space_before, p.paragraph_format.space_after = Pt(16), Pt(6)
    p.paragraph_format.keep_with_next = True
    _run(p, t, 15, bold=True, color=NAVY, font="Arial")
    return p


def H2(doc, t):
    from docx.shared import Pt
    p = doc.add_paragraph()
    p.paragraph_format.space_before, p.paragraph_format.space_after = Pt(10), Pt(4)
    p.paragraph_format.keep_with_next = True
    _run(p, t, 11.5, bold=True, color=TEAL, font="Arial")


def para(doc, t, size=10.5, color=None):
    p = doc.add_paragraph()
    _md(p, t, size=size, color=color)
    return p


def bullet(doc, t):
    p = doc.add_paragraph(style="List Bullet")
    _md(p, t, size=10.5)


def caption(doc, t):
    from docx.shared import Pt
    p = doc.add_paragraph()
    p.paragraph_format.space_before, p.paragraph_format.space_after = Pt(8), Pt(3)
    p.paragraph_format.keep_with_next = True
    _md(p, t, size=8.5, color="333333", font="Arial")


def note(doc, t):
    p = doc.add_paragraph()
    _md(p, t, size=7.8, color=GREY, font="Arial")


def table(doc, head, rows, widths, right=()):
    from docx.shared import Cm, Pt
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    t = doc.add_table(rows=1, cols=len(head))
    t.autofit = False
    _borders(t)
    tot = sum(widths)
    W = [Cm(17 * w / tot) for w in widths]
    _fixed(t, W)
    for i, h in enumerate(head):
        c = t.rows[0].cells[i]
        c.width = W[i]
        _shade(c, NAVY)
        p = c.paragraphs[0]
        _run(p, h, 7.8, bold=True, color="FFFFFF", font="Arial")
    _repeat_header(t.rows[0])
    for k, row in enumerate(rows):
        cells = t.add_row().cells
        for i, v in enumerate(row):
            c = cells[i]
            c.width = W[i]
            if k % 2:
                _shade(c, "F3F6F9")
            p = c.paragraphs[0]
            p.paragraph_format.space_after = Pt(0)
            p.paragraph_format.line_spacing = 1.0
            if i in right:
                p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
            opts = {}
            if isinstance(v, tuple):
                v, opts = v
            _md(p, str(v), size=7.8, font="Arial", **opts)
    return t


def tiles(doc, items):
    from docx.shared import Cm, Pt
    t = doc.add_table(rows=1, cols=len(items))
    t.autofit = False
    _fixed(t, [Cm(17 / len(items))] * len(items))
    for i, (n, label, col) in enumerate(items):
        c = t.rows[0].cells[i]
        c.width = Cm(17 / len(items))
        _shade(c, "F7F9FB")
        p = c.paragraphs[0]
        _run(p, n, 20, bold=True, color=col, font="Arial")
        p2 = c.add_paragraph()
        p2.paragraph_format.space_after = Pt(2)
        _run(p2, label, 7.8, color="374151", font="Arial")


# ------------------------------------------------------------------ report
def write(st, outdir, anonymous=False):
    os.makedirs(outdir, exist_ok=True)
    d = collect(st)
    m = st["meta"]
    short, v = m["short"], m["version"]
    figs = figures(d, outdir, short)
    now = d["now"]
    kf = lambda r: ", ".join(d["kf_of"].get(r["id"], [])) or "—"  # noqa: E731
    cs = lambda r: "—" if _c(r) is None else str(_c(r))  # noqa: E731
    core_ids = {r["id"] for r in d["core"]}
    confirmed = all(r.get("core_status") == "confirmed" for r in d["core"]) if d["core"] else False
    from docx.shared import Pt, Cm
    doc = _doc()
    hdr = doc.sections[0].header.paragraphs[0]
    _run(hdr, f"D4b · Evidence Landscape Report · {short}", 7.5, italic=True, color=GREY, font="Arial")
    p = doc.add_paragraph(); _run(p, "360° MDL · DELIVERABLE D4b · COMPANION TO D4 CORE CORPUS", 8.5, bold=True, color=TEAL, font="Arial")
    p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(8)
    _run(p, "Evidence Landscape Report: Influencers, Most-Cited Papers and Emerging Voices", 20, bold=True, color=NAVY, font="Arial")
    para(doc, f"Review: *{m['title']}*", 10, "374151")
    if not anonymous and m.get("researcher", {}).get("name"):
        para(doc, f"{m['researcher']['name']} · {m['researcher'].get('affiliation', '')}", 9.5, "374151")
    para(doc, f"Build v{v} · {m['tier']} tier · {S.today()} · {len(d['el'])} eligible records · core of {len(d['core'])} items "
              f"({'confirmed at Key 2' if confirmed else 'PROPOSED — awaiting Key 2 confirmation'}) · 360° MDL Navigator", 8, GREY)

    # 1 at a glance
    H1(doc, "1  At a glance")
    n_inf_core = sum(1 for x in d["infl"] if x["core"])
    top = d["ranked_core"][0] if d["ranked_core"] else None
    nf5 = len(d["f5"])
    tiles(doc, [(str(len(d["infl"])), "leading authors in the eligible pool (top-10 by productivity, top-10 by citations)", FAMC["F2"]),
                (str(n_inf_core), f"of them represented in the core; {len(d['f2'])} influencer-stream (F2) papers in the core", FAMC["F2"]),
                (cs(top) if top else "—", f"citations of the most-cited core item ({cite.intext(top, 'apa')})" if top else "no citation data", FAMC["F1"]),
                (str(nf5), f"emerging and diverse voices (F5) in the core ({nf5 / max(1, len(d['core'])):.0%})", FAMC["F5"])])
    H2(doc, "Composition of the core by stream family")
    table(doc, ["Family", "Core items", "Share", "Items with citation data", "Median citations"],
          [[f"{f} {S.FAMILIES[f]}", str(d["fam"].get(f, 0)), f"{d['fam'].get(f, 0) / max(1, len(d['core'])):.0%}",
            str(sum(1 for r in d["core"] if r.get("family") == f and _c(r) is not None)),
            (lambda xs: str(sorted(xs)[len(xs) // 2]) if xs else "—")([_c(r) for r in d["core"] if r.get("family") == f and _c(r) is not None])]
           for f in S.FAMILIES], [40, 14, 12, 20, 16], right=(1, 2, 3, 4))
    if d["has_cites"] < len(d["el"]) * 0.5:
        note(doc, f"Only {d['has_cites']} of {len(d['el'])} eligible records carry a citation count in the imported exports; rankings below cover those records only.")

    # 2 influencers
    H1(doc, "2  Influencer scholarship")
    para(doc, "The method identifies the authors who dominate the topic in two ways: the ten most *productive* authors (most eligible "
              "records) and the ten most *cited* authors (sum of citations of their eligible records). The influencer stream (F2) adds the "
              "most-cited (MC) and most-recent (MR) on-topic paper of leading authors; those papers then pass the same 6R gate as any other record.")
    caption(doc, "*Table D4b.1.* Leading authors in the eligible pool and their presence in the core")
    table(doc, ["Rule", "Author", "Records", "Citations", "Most-cited eligible record", "In the core as"],
          [[x["rule"], (x["author"], {"bold": True}), str(x["n"]), str(x["c"]), _short(x["mc"].get("title"), 80),
            ("; ".join(cite.intext(r, "apa") for r in x["core"]), {"bold": True, "color": "5B2C83"}) if x["core"] else ("— pool only", {"color": GREY})]
           for x in d["infl"]], [11, 16, 8, 9, 36, 20], right=(2, 3))
    note(doc, "Counts are within this review's eligible pool, not career totals. Author names are matched as written in the exports; "
              "variant spellings of the same person are counted separately and should be merged by the researcher.")
    if d["f2"]:
        caption(doc, f"*Table D4b.2.* The {len(d['f2'])} influencer-stream (F2) papers in the core and the role they play")
        table(doc, ["ID", "Paper", "Venue · citations", "Role in the review", "Findings"],
              [[r["id"], (cite.intext(r, "apa"), {"bold": True}), f"{r.get('venue') or '—'} · {cs(r)}", _role(r), kf(r)] for r in d["f2"]],
              [13, 16, 22, 37, 12])

    # 3 most cited
    H1(doc, "3  The most-cited papers")
    if not d["ranked_core"]:
        para(doc, "The imported records carry no citation counts, so this section cannot rank them. Import a Scopus or Web of Science export "
                  "(fields 'Cited by' / 'TC') or OpenAlex records (cited_by_count) and run the build again.")
    if "cited" in figs:
        doc.add_picture(figs["cited"], width=Cm(16.5))
        caption(doc, "*Figure D4b.1.* The most-cited core items, coloured by stream family; citations per year since publication in brackets")
    if d["ranked_core"]:
        caption(doc, "*Table D4b.3.* The most-cited core items")
        table(doc, ["#", "Paper", "Title", "Family", "Cites", "Per year", "Findings"],
              [[str(i + 1), (cite.intext(r, "apa"), {"bold": True}), _short(r.get("title"), 80), (r.get("family"), {"bold": True, "color": FAMC.get(r.get("family"))}),
                cs(r), str(_cpy(r, now)), kf(r)] for i, r in enumerate(d["ranked_core"][:15])], [4, 17, 40, 7, 7, 8, 14], right=(0, 4, 5))
    if d["top_el"]:
        H2(doc, "Most-cited records in the whole eligible pool")
        para(doc, "Citation rank alone does not make the core: Gate 2 (6R) and Gate 3 (complementarity, coverage, diversity) decide. "
                  "This table shows where the most-cited eligible records ended up.")
        caption(doc, "*Table D4b.4.* The most-cited eligible records and their status")
        table(doc, ["ID", "First author, year", "Title", "Cites", "Gate 2", "Core"],
              [[r["id"], cite.intext(r, "apa"), _short(r.get("title"), 78), cs(r), r.get("decision") or "—",
                ("Core", {"bold": True, "color": TEAL}) if r["id"] in core_ids else ("—", {"color": GREY})] for r in d["top_el"]],
              [13, 17, 44, 7, 10, 9], right=(3,))
    if d["rising"]:
        H2(doc, f"Rising records: fastest citation growth since {now - 3}")
        caption(doc, f"*Table D4b.5.* Eligible records from {now - 3}–{now} ranked by citations per year")
        table(doc, ["ID", "First author, year", "Title", "Cites", "Per year", "Core"],
              [[r["id"], cite.intext(r, "apa"), _short(r.get("title"), 78), cs(r), str(_cpy(r, now)),
                ("Core", {"bold": True, "color": TEAL}) if r["id"] in core_ids else ("—", {"color": GREY})] for r in d["rising"]],
              [13, 17, 45, 7, 8, 9], right=(3, 4))
        note(doc, "Rising records outside the core are candidates for the next iteration (P7) of the review.")

    # 4 emerging
    H1(doc, "4  Emerging and diverse voices (F5)")
    para(doc, "The F5 family keeps the review from reproducing only the most-cited, mostly Western, English-language canon. Its slices are:")
    for s in SLICE_ORDER:
        bullet(doc, f"*{s} — {SLICE_NAME[s]}*: {S.SLICES[s].split(' ', 1)[1]}")
    if "f5" in figs:
        doc.add_picture(figs["f5"], width=Cm(16.5))
        caption(doc, "*Figure D4b.2.* Eligible F5 records by slice and Gate 2 decision, with the number reaching the core")
    if d["f5"]:
        caption(doc, f"*Table D4b.6.* The {len(d['f5'])} emerging and diverse voices in the core")
        table(doc, ["Slice", "Paper", "Venue · cites", "What it adds", "Findings"],
              [[(SLICE_NAME.get(r.get("slice"), r.get("slice")), {"bold": True, "color": FAMC["F5"]}), (cite.intext(r, "apa"), {"bold": True}),
                f"{r.get('venue') or '—'} · {cs(r)}" + (f" · {r['_language']}" if r.get("_language") and str(r["_language"]).lower() not in ("english", "en") else ""),
                _role(r), kf(r)] for r in d["f5"]], [13, 16, 22, 37, 12])
    else:
        para(doc, "No F5 item is in the core. The gaps report flags this; add rising, Global-South, non-English, critical or preprint items.")

    # 5 reading notes
    H1(doc, "5  How to read these rankings")
    for t in ["Citation counts are those carried by the imported exports on the stated retrieval dates; they change daily and differ between databases.",
              "Older papers accumulate more citations; citations per year corrects partly for age.",
              "Citations measure attention, not quality or relevance. The core was selected by the 6R scorecard and the CCD rules of Gate 3, not by citation rank.",
              "Industry (F3), policy (F4) and preprint sources usually have no comparable citation data; their role is read from the coding.",
              "Every record can be traced by its ID in the toolkit workbook and the audit log."]:
        bullet(doc, t)

    # references (core items named in this report)
    H1(doc, "References (core items named in this report)")
    named = {r["id"]: r for r in d["f2"] + d["ranked_core"][:15] + d["f5"]}
    for r in sorted(named.values(), key=cite.sort_key):
        p = doc.add_paragraph()
        p.paragraph_format.left_indent, p.paragraph_format.first_line_indent = Cm(0.8), Cm(-0.8)
        p.paragraph_format.space_after = Pt(3)
        _md(p, cite.reference(r, "apa"), size=8.8)
    note(doc, "References are built only from the stored record fields. Records outside the core are identified by their ID; "
              "full data are in the toolkit workbook.")
    path = os.path.join(outdir, f"D4b_Evidence_Landscape_{short}_v{v}.docx")
    doc.save(path)
    return [path] + list(figs.values())


if __name__ == "__main__":
    st = S.load(sys.argv[1])
    for f in write(st, sys.argv[2]):
        print(" ", f)

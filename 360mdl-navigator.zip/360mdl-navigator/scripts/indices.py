# -*- coding: utf-8 -*-
"""The six indices and the Gate 3 CCD checks — the same formulas as the 360° MDL Index Calculator (spec §7).
compute(st) -> result dict; model(st) -> the calculator.json record the Index Calculator reads."""
import math

from state import TARGETS, METHODS, FAMILIES, counts

FAM = list(FAMILIES)


def entropy(cs):
    n = sum(cs)
    if not n:
        return 0.0
    return -sum((c / n) * math.log(c / n) for c in cs if c > 0)


def model(st):
    tier = st["meta"]["tier"]
    core = [r for r in st["records"] if r["core"] and not r["duplicate_of"]]
    cbf, mc, authors = {}, {}, {}
    for r in core:
        cbf[r["family"]] = cbf.get(r["family"], 0) + 1
        m = (r.get("coding") or {}).get("method_family")
        if m:
            mc[m] = mc.get(m, 0) + 1
        a = (r.get("coding") or {}).get("lead_group") or (r.get("authors") or r.get("organisation") or "").split(",")[0].split(";")[0].strip()
        if a:
            authors[a] = authors.get(a, 0) + 1
    ncl = len(st["clusters"])
    cc = [sum(1 for r in core if i + 1 in [int(x) for x in (r.get("coding") or {}).get("clusters", [])]) for i in range(ncl)] if ncl else None
    conv = sum(1 for r in core if len(set(r.get("found_in") or [])) >= 2)
    harv = {}
    for r in st["records"]:
        harv[r["family"]] = harv.get(r["family"], 0) + 1
    c = counts(st)
    return {"name": st["meta"]["title"], "tier": tier, "coreByFamily": cbf, "methodCounts": mc, "clusterCounts": cc,
            "clusters": [x["name"] for x in st["clusters"]],
            "kfs": [{"id": k["id"], "text": k["text"], "families": k["families"], "ids": "; ".join(k["ids"])} for k in st["key_findings"]],
            "convergence": conv, "authorMax": max(authors.values()) if authors else None, "harvByFam": harv,
            "gates": {"harvested": c["harvested"], "unique": c["unique"], "eligible": c["eligible"], "pass": c["pass"],
                      "reserve": c["reserve"], "exclude": c["exclude"], "core": c["core"], "pool": c["pool"]}}


def compute(st):
    m = model(st)
    T = TARGETS[m["tier"]]
    cc = [m["coreByFamily"].get(f, 0) for f in FAM]
    N = sum(cc)
    k = sum(1 for c in cc if c > 0)
    sbi = entropy(cc) / math.log(k) if k > 1 else 0.0
    mcs = [m["methodCounts"].get(x, 0) for x in METHODS]
    mt = sum(mcs)
    mdi = entropy(mcs) / math.log(9) if mt else None
    mfam = sum(1 for c in mcs if c > 0)
    covi, ncl, covered = None, 0, 0
    if m["clusterCounts"]:
        ncl = len(m["clusterCounts"])
        covered = sum(1 for c in m["clusterCounts"] if c >= T["covMin"])
        covi = covered / ncl if ncl else None
    kfs = []
    for kf in m["kfs"]:
        fams = sorted({f for f in kf["families"] if f in FAM})
        ts = len(fams)
        kfs.append({**kf, "families": fams, "ts": ts, "cls": "Robust" if ts >= 3 else "Supported" if ts == 2 else "Tentative" if ts == 1 else "None"})
    nkf = len(kfs)
    nR = sum(1 for x in kfs if x["cls"] == "Robust")
    nS = sum(1 for x in kfs if x["cls"] == "Supported")
    nT = sum(1 for x in kfs if x["cls"] == "Tentative")
    ri = (nR + 0.5 * nS) / nkf if nkf else None
    loso, lmin = {}, None
    if nkf:
        for f in FAM:
            keep = sum(1 for x in kfs if len([g for g in x["families"] if g != f]) >= 2) / nkf
            loso[f] = keep
            lmin = keep if lmin is None else min(lmin, keep)
    conv = m["convergence"] / N if N else None
    grey = (m["coreByFamily"].get("F3", 0) + m["coreByFamily"].get("F4", 0)) / N if N else 0
    f5 = m["coreByFamily"].get("F5", 0) / N if N else 0
    mx = max(cc) / N if N else 0
    am = m["authorMax"]
    checks = [
        ("Core corpus size", f"{N}", f"{T['core'][0]}–{T['core'][1]}", T["core"][0] <= N <= T["core"][1]),
        ("Stream families used (k)", f"{k}", f"≥ {min(T['streamsMin'], 5)}", k >= min(T["streamsMin"], 5)),
        ("Largest family share", f"{mx * 100:.0f}%", "≤ 40%", mx <= 0.40),
        ("Grey literature (F3 + F4)", f"{grey * 100:.0f}%", "10–30%" if T["greyReq"] else "10–30% (optional)",
         (0.10 <= grey <= 0.30) if T["greyReq"] else (grey == 0 or 0.10 <= grey <= 0.30)),
        ("Emerging & diverse voices (F5)", f"{f5 * 100:.0f}%", f"≥ {T['f5'] * 100:.0f}%", f5 >= T["f5"]),
        (f"Clusters covered (≥ {T['covMin']} items)", f"{covered} / {ncl}" if ncl else "—", "all", (covered == ncl) if ncl else None),
        ("Method families represented", f"{mfam}" if mt else "—", "≥ 3", (mfam >= 3) if mt else None),
        ("Max items per lead author/group", "—" if am is None else f"{am}", "≤ 3", None if am is None else am <= 3),
    ]
    return {"tier": m["tier"], "T": T, "N": N, "k": k, "coreCounts": cc, "sbi": sbi, "mdi": mdi, "mFam": mfam, "mcounts": mcs,
            "covi": covi, "nClusters": ncl, "covered": covered, "clusterCounts": m["clusterCounts"], "kfs": kfs, "nKF": nkf,
            "nR": nR, "nS": nS, "nT": nT, "ri": ri, "loso": loso, "losoMin": lmin, "conv": conv, "grey": grey, "f5": f5,
            "maxShare": mx, "checks": checks, "gates": m["gates"], "harvByFam": m["harvByFam"], "name": m["name"], "model": m}


def status_of(val, target, higher_is_better=True):
    if val is None or target is None:
        return "REPORT"
    return "PASS" if (val >= target if higher_is_better else val <= target) else "CHECK"


def next_step(st):
    c = counts(st)
    if st["canvas"].get("status") != "confirmed":
        return "Key 1: ask the researcher to approve the Review Canvas (mdl.py key STATE 1)."
    if c["unique"] == 0:
        return "P2: harvest or import records (mdl.py import / add)."
    if any(r["gate1"]["status"] == "pending" for r in st["records"] if not r["duplicate_of"]):
        return "P3: run Gate 1 (mdl.py gate1 STATE rules.json)."
    if c["unscored"]:
        return f"P3: propose 6R scores for {c['unscored']} eligible records (mdl.py scores)."
    if "key2" not in st["keys"]:
        return "Key 2: have the researcher confirm PASS/RESERVE item by item and the Exclude batch (mdl.py confirm, batch-exclude), then mdl.py key STATE 2."
    if not c["core"]:
        return "P3: propose the core corpus (mdl.py core STATE --auto) and have it confirmed."
    if not st["clusters"]:
        return "P4: propose keyword clusters (mdl.py clusters)."
    if any(not (r.get("coding") or {}).get("method_family") for r in st["records"] if r["core"]):
        return "P4: code the core items (mdl.py coding) — method family, contribution types, clusters, findings."
    if not st["key_findings"]:
        return "P5: draft key findings with supporting IDs (mdl.py findings)."
    if "key3" not in st["keys"]:
        return "Key 3: have the researcher confirm the key findings (mdl.py key STATE 3)."
    if not st["distillate"]:
        return "P6: draft the Knowledge Distillate (mdl.py distillate)."
    if "key4" not in st["keys"]:
        return "Key 4: review the Distillate dimension by dimension (mdl.py key STATE 4)."
    return "Build the outputs (mdl.py build) and read the gaps report; iterate (P7)."

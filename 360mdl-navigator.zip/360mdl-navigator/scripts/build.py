# -*- coding: utf-8 -*-
"""Build every output of a run into OUTDIR (spec Section 6). The toolkit xlsx is the master; all else is derived."""
import datetime as dt
import json
import os
import shutil
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import state as S  # noqa: E402
import indices  # noqa: E402
import distillate as D  # noqa: E402

RC = [
    ("Title & abstract", 1, "Identify the review as a 360° MDL review and state the tier and mode"),
    ("Title & abstract", 2, "Structured abstract including streams, corpus size, matrices and Resilience Index"),
    ("Introduction", 3, "Rationale and the knowledge problem"), ("Introduction", 4, "Review questions"),
    ("Protocol (P1)", 5, "Review Canvas: scope, time window, languages, disciplines"),
    ("Protocol (P1)", 6, "Protocol registration (registry and ID) or justification"),
    ("Protocol (P1)", 7, "Team, roles and calibration procedure"),
    ("Sourcing (P2)", 8, "Streams and slices used, with rationale (≥ 3)"),
    ("Sourcing (P2)", 9, "Full search strings, filters and dates per stream (Stream Log)"),
    ("Sourcing (P2)", 10, "Influencer identification sources and profile-selection rules (if Approach B)"),
    ("Sourcing (P2)", 11, "Emerging & Diverse Voices strategy (if Approach C)"),
    ("Selection (P3)", 12, "Eligibility criteria and de-duplication; Convergence Flags"),
    ("Selection (P3)", 13, "6R scoring scheme, thresholds and calibration (κ)"),
    ("Selection (P3)", 14, "CCD curation decisions and portfolio rules"),
    ("Selection (P3)", 15, "Flow diagram with numbers per stream and per gate"),
    ("Codification (P4)", 16, "ID scheme and Master Table fields"),
    ("Codification (P4)", 17, "Keyword-unification procedure and final cluster list"),
    ("Analysis (P5)", 18, "Matrices used (≥ 3) and coding rules"), ("Analysis (P5)", 19, "Contribution taxonomy applied"),
    ("Analysis (P5)", 20, "Coverage heatmap and Coverage Index"), ("Analysis (P5)", 21, "Method diversity (M2) and MDI"),
    ("Synthesis (P6)", 22, "Key findings with Triangulation Strength"),
    ("Synthesis (P6)", 23, "Resilience Index and (Advanced) LOSO test"),
    ("Synthesis (P6)", 24, "Academic–practice–policy convergence and divergence"),
    ("Interpretation (P6)", 25, "Interpretation and exploitation (M7)"),
    ("Interpretation (P6)", 26, "Value-Based Framework (M8) and its derivation from the evidence"),
    ("Interpretation (P6)", 27, "Research agenda from M5/M6"),
    ("Transparency (P7)", 28, "Open data: matrices and Stream Log as supplementary files"),
    ("Transparency (P7)", 29, "AI-use statement (tools, tasks, verification)"),
    ("Transparency (P7)", 30, "Limitations (stream coverage, language, metrics bias) and update plan"),
]


def f2(x):
    return "—" if x is None else f"{x:.2f}"


def pct(x):
    return "—" if x is None else f"{x * 100:.0f}%"


def gaps_report(st, R):
    """Fixed sections, never omitted even when empty (author's rule, 7 Nov 2026)."""
    T = R["T"]
    c = R["gates"]
    L = [f"# Gaps report — {st['meta']['title']}", "",
         f"*Build v{st['meta']['version']} · {st['meta']['tier']} tier · {dt.date.today()} · 360° MDL Navigator v0.1. This report lists what the Core Knowledge does NOT "
         "yet contain. It is part of the deliverable to the supervisor and is copied into the Distillate's limitations.*", ""]
    # 1 unreached sources
    L += ["## 1. Unreached or pending sources", "", "| Stream | Source | Why not reached | What to do |", "|---|---|---|---|"]
    rows = 0
    for e in st["stream_log"]:
        if e.get("status") in ("handed_over", "failed", "planned"):
            why = {"handed_over": "closed database: string handed to the researcher, export not yet imported",
                   "failed": "source unreachable from the Navigator's environment", "planned": "not run yet"}[e["status"]]
            L.append(f"| {e['code']}-{e.get('slice', '')} | {e.get('source', '')} | {why} | run the string in `{str(e.get('query', ''))[:60]}…` and import the export |")
            rows += 1
    used_fam = {S.FAMILY_OF[c0] for c0, v in st["streams"].items() if v.get("use") == "Y"}
    for f, name in S.FAMILIES.items():
        if f not in used_fam or R["harvByFam"].get(f, 0) == 0:
            L.append(f"| {f} | {name} | no stream of this family searched | " + {
                "F1": "run Scopus / Web of Science / Scholar strings (T2) and upload the exports",
                "F2": "identify 5–8 leading authors from F1 (OpenAlex authors) and add their most-cited and most-recent on-topic papers",
                "F3": "search industry and consultancy reports on the official sites of the main players (IND)",
                "F4": "search government, agency and international-organisation documents (GOV)",
                "F5": "add preprints, theses, Global-South and critical items (EMV)"}[f] + " |")
            rows += 1
    if not rows:
        L.append("| — | — | every planned source was searched | — |")
    # 2 below-target indices
    L += ["", "## 2. Indices and portfolio checks below target", "", "| Index / check | Value | Target | Gap | Recommended action |", "|---|---|---|---|---|"]
    rows = 0
    items = [("SBI", R["sbi"], T["sbi"], "add core items from the smallest families (see §1) or rebalance at Gate 3"),
             ("CovI", R["covi"], T["covi"], "search directly the clusters with fewer than " + str(T["covMin"]) + " items: " + (", ".join(f"K{i + 1}" for i, x in enumerate(R["clusterCounts"] or []) if x < T["covMin"]) or "—")),
             ("MDI", R["mdi"], T["mdi"], "look for studies of the under-used designs: " + (", ".join(m for m, x in zip(S.METHODS, R["mcounts"]) if x == 0) or "—")),
             ("RI", R["ri"], T["ri"], "seek a second family for findings with TS ≤ 1: " + (", ".join(k["id"] for k in R["kfs"] if k["ts"] <= 1) or "—")),
             ("LOSO", R["losoMin"], T["loso"], "strengthen the family whose removal hurts most: " + (min(R["loso"], key=R["loso"].get) if R["loso"] else "—"))]
    for name, val, tgt, action in items:
        if tgt is not None and (val is None or val < tgt):
            L.append(f"| {name} | {f2(val)} | {tgt:.2f} | {('—' if val is None else f'{tgt - val:.2f}')} | {action} |")
            rows += 1
    for lab, val, tgt, ok in R["checks"]:
        if ok is False:
            L.append(f"| CCD: {lab} | {val} | {tgt} | rule not met | adjust the core at Gate 3 or document the adaptation in T1 |")
            rows += 1
    if not rows:
        L.append("| — | — | — | — | all indices and checks meet the tier targets |")
    # 3 keys
    L += ["", "## 3. Keys not yet turned", "", "| Key | Phase | What is pending |", "|---|---|---|"]
    pend = {"key1": ("P1", "Review Canvas approval"), "key2": ("P3", "confirmation of 6R scores and core corpus"),
            "key3": ("P5", "confirmation of key findings"), "key4": ("P6", "review of the Knowledge Distillate")}
    rows = 0
    for k, (ph, what) in pend.items():
        if k not in st["keys"]:
            L.append(f"| {k.replace('key', 'Key ')} | {ph} | {what} |")
            rows += 1
    unv = sum(1 for r in st["records"] if r.get("unverified"))
    prop = sum(1 for r in st["records"] if r.get("sixR_status") == "proposed" and r["gate1"]["status"] == "eligible")
    pc = sum(1 for r in st["records"] if r["core"] and r.get("core_status") != "confirmed")
    if unv or prop or pc:
        L.append(f"| rows | P3 | {unv} records without identifier (blocked); {prop} eligible records with unconfirmed 6R; {pc} core items unconfirmed |")
        rows += 1
    if not rows:
        L.append("| — | — | all four keys turned; all rows confirmed |")
    # 4 under-represented
    N = R["N"] or 1
    L += ["", "## 4. Under-represented families and clusters", ""]
    weak = [f"{f} {S.FAMILIES[f]}: {R['model']['coreByFamily'].get(f, 0)} items ({R['model']['coreByFamily'].get(f, 0) / N * 100:.0f}%)" for f in S.FAMILIES if R["model"]["coreByFamily"].get(f, 0) / N < 0.10]
    wk = [f"K{i + 1} {st['clusters'][i]['name']}: {x} items" for i, x in enumerate(R["clusterCounts"] or []) if x < T["covMin"]]
    L += ["- Families below 10 % of the core: " + ("; ".join(weak) if weak else "none"),
          f"- Clusters below the coverage threshold ({T['covMin']}): " + ("; ".join(wk) if wk else "none"),
          f"- Method families absent: " + (", ".join(m for m, x in zip(S.METHODS, R["mcounts"]) if x == 0) or "none")]
    # 5 next actions
    L += ["", "## 5. Recommended next-iteration actions (priority order)", ""]
    acts = []
    if "key2" not in st["keys"]:
        acts.append("Confirm the 6R scores and the core corpus (Key 2); nothing else is final before this.")
    for e in st["stream_log"]:
        if e.get("status") == "handed_over":
            acts.append(f"Run the {e['code']} string in {e.get('source', 'the database')} and import the export.")
            break
    if weak:
        acts.append("Add 3–5 verified items from the under-represented families listed in §4 and re-run Gate 2 and Gate 3.")
    if wk:
        acts.append("Search the under-covered clusters directly (cluster keywords as search terms) and re-run.")
    if any(k["ts"] <= 1 for k in R["kfs"]):
        acts.append("For each Tentative finding, look for one item from a second family; re-compute RI and LOSO.")
    if not st.get("distillate"):
        acts.append("Draft the Knowledge Distillate from the confirmed rows and review it (Key 4).")
    acts.append("Appoint a second coder for a 20 % sample of 6R scores and report Cohen's κ (Standard: recommended; Advanced: required).")
    L += [f"{i}. {a}" for i, a in enumerate(acts, 1)]
    L += ["", "## 6. What this Core Knowledge is", "",
          f"A first-cycle corpus of {R['N']} core items from {R['k']} stream families ({c['harvested']} harvested, {c['unique']} unique, {c['eligible']} eligible, "
          f"{c['pass']} Pass), built on {dt.date.today()} from the sources in the Stream Log. It is a starting point to extend, not a complete review."]
    return "\n".join(L) + "\n"


def methods_draft(st, R):
    c = R["gates"]
    T = R["T"]
    fams = ", ".join(f"{f} {n}" for f, n in R["model"]["coreByFamily"].items())
    streams = ", ".join(f"{c0} ({', '.join(v.get('slices', []))})" for c0, v in st["streams"].items() if v.get("use") == "Y")
    return f"""# Methods (draft, MDL-RC 2026 order) — {st['meta']['title']}

*Drafted by the 360° MDL Navigator v0.1 on {dt.date.today()}; numbers come from the toolkit. Text in [brackets] is for the researcher to write.*

## Design
This review follows the 360° MDL — Multidimensional Literature Review Model, Version 2026 (Lytras, 2026; doi:10.5281/zenodo.23724393), at the {st['meta']['tier']} tier in Mode 360. [State the knowledge problem and the review questions RQ1–RQ{len(st['canvas'].get('rqs', [])) or 'n'} (T1).]

## Sourcing (P2)
Evidence was harvested from {R['k']} stream families through the streams {streams or '[streams]'} (Stream Log, T3: {len(st['stream_log'])} queries). [Rationale for the streams; influencer selection rules if Approach B; emerging-voices strategy if Approach C.]

## Selection (P3)
{c['harvested']} records were harvested, {c['unique']} were unique after de-duplication ({c['harvested'] - c['unique']} cross-stream duplicates merged with a Convergence Flag), and {c['eligible']} were eligible at Gate 1 [criteria]. Gate 2 applied the 6R scorecard (Relevance, Rigour, Reach, Recency, Richness, Representativeness; 0–2 each; Pass if R1 ≥ 1, R2 ≥ 1 and total ≥ 7; Reserve 5–6): {c['pass']} Pass, {c['reserve']} Reserve, {c['exclude']} Exclude. Scores were proposed with a written justification per criterion and confirmed by the researcher [calibration / second coder]. Gate 3 (CCD curation) retained a core corpus of {R['N']} items ({fams}); {c['pool']} Pass items form the Extended Evidence Pool.

## Codification and analysis (P4–P5)
Core items were coded in the Master Table (T6) and matrices M1–M4 [+ M5–M8], with {R['nClusters']} keyword clusters (T1 §6). Method families: {R['mFam']} of 9.

## Indices (P5–P6)
Stream Balance Index {f2(R['sbi'])} (target ≥ {T['sbi']:.2f}); Coverage Index {f2(R['covi'])} (≥ {T['covi']:.2f}); Method Diversity Index {f2(R['mdi'])} (≥ {T['mdi']:.2f}); {R['nKF']} key findings of which {R['nR']} Robust and {R['nS']} Supported; Resilience Index {f2(R['ri'])} (≥ {T['ri']:.2f}); Leave-One-Stream-Out worst case {f2(R['losoMin'])}{'' if T['loso'] is None else f" (≥ {T['loso']:.2f})"}; Convergence Rate {pct(R['conv'])}.

## Transparency (P7)
The toolkit, Stream Log and audit log are supplied as supplementary files. [AI-use statement: see ai_use_statement.md.] [Limitations and update plan: see gaps_report.md.]
"""


def ai_statement(st):
    keys = {k: v["turned_at"][:10] for k, v in st["keys"].items()}
    kd = lambda k: keys.get(k, "not yet turned")  # noqa: E731
    return f"""# AI Use Statement

This literature review was conducted with the assistance of the 360° MDL Navigator (v0.1), an AI assistant (Claude, Anthropic)
that implements the 360° MDL method (Lytras, 2026), under the method's Two-Key Rule.

## What the AI did
- Drafted the Review Canvas, stream plan and search strings
- Harvested records from open APIs where reachable, parsed uploaded exports, de-duplicated across streams
- Applied Gate 1 against the canvas criteria and proposed 6R scores with a one-line justification per criterion
- Proposed keyword clusters, coding of core items and the mapping to review questions
- Drafted the key findings and the Knowledge Distillate from confirmed rows
- Computed the indices (SBI, CovI, MDI, TS, RI, LOSO, Convergence Rate) and generated the toolkit and reports

## What the researcher confirmed (Two-Key Rule)
- Review Canvas (Key 1): {kd("key1")}
- 6R scores and core corpus (Key 2): {kd("key2")}
- Key findings (Key 3): {kd("key3")}
- Knowledge Distillate (Key 4): {kd("key4")}

## What the AI did not do
- Invent, fabricate or complete any citation, DOI, author, year or venue
- Summarise any paper from its title alone
- Access any database requiring authentication on the researcher's behalf
- Make any final decision: every score, selection and finding was confirmed by the researcher

## Verification
Every record entered the review state from an uploaded export, an open API response or an opened page, with a DOI, PubMed ID,
OpenAlex ID or URL; records without an identifier were blocked at Gate 1. The file audit_log.jsonl documents every action with
timestamps. Indices and figures can be re-computed with the 360° MDL Index Calculator (Lytras, 2026; doi:10.5281/zenodo.24033376).

## Short form for a manuscript
Generative AI (Claude, Anthropic; via the 360° MDL Navigator v0.1, {dt.date.today().strftime("%B %Y")}) was used for search-string design,
harvesting and de-duplication, Gate 1 screening, proposed 6R scores, coding, and drafting of findings and synthesis. All AI-assisted outputs were
verified by the author(s) against the original sources in line with the 360° MDL Two-Key Rule; no record was included without an identifier
obtained from a database, an export file or an opened page. The author(s) take full responsibility for the content.

## Method citation
Lytras, M. D. (2026). *360° MDL: The Multidimensional Literature Review Model — Version 2026*. Zenodo. https://doi.org/10.5281/zenodo.23724393
"""


def run_checklist(st, R, out_files):
    """Navigator run checklist: 20 process criteria for THIS run (complements, never replaces, the 30-item MDL-RC 2026)."""
    recs = [r for r in st["records"] if not r["duplicate_of"]]
    elig = [r for r in recs if r["gate1"]["status"] == "eligible"]
    core = [r for r in recs if r["core"]]
    T = R["T"]
    fams_used = {S.FAMILY_OF[c] for c, v in st["streams"].items() if v.get("use") == "Y"}
    grey = any(f in fams_used for f in ("F3", "F4"))
    d = st.get("distillate") or {}
    names = [os.path.basename(x) for x in out_files]
    rows = [
        ("Review Canvas approved by the researcher (Key 1)", "key1" in st["keys"], ""),
        (f"≥ {T['streamsMin']} streams used, incl. ≥ 1 grey (Standard/Advanced)", len([c for c, v in st["streams"].items() if v.get("use") == "Y"]) >= T["streamsMin"] and (grey or not T["greyReq"]), f"{len(fams_used)} families"),
        ("Every search query logged in the Stream Log", bool(st["stream_log"]), f"{len(st['stream_log'])} entries"),
        ("Gate 1 applied with documented rules", all(r["gate1"]["status"] != "pending" for r in recs), ""),
        ("Every eligible record scored on all six R", all(r.get("sixR") for r in elig), ""),
        ("6R scores confirmed by the researcher (Key 2)", "key2" in st["keys"] and all(r.get("sixR_status") == "confirmed" for r in elig), ""),
        ("Core corpus confirmed by the researcher", bool(core) and all(r.get("core_status") == "confirmed" for r in core), f"N = {len(core)}"),
        ("≤ 10 keyword clusters, all named", 0 < len(st["clusters"]) <= 10, ""),
        ("Every core item coded (method, clusters, contribution, RQ)", bool(core) and all((r.get("coding") or {}).get("method_family") and (r.get("coding") or {}).get("clusters") for r in core), ""),
        ("≥ 8 key findings, each with supporting IDs", len(st["key_findings"]) >= 8 and all(k.get("ids") for k in st["key_findings"]), f"{len(st['key_findings'])} findings"),
        ("Key findings confirmed by the researcher (Key 3)", "key3" in st["keys"], ""),
        ("Knowledge Distillate drafted with ≥ 4 dimensions", len(d.get("dimensions", [])) >= 4, ""),
        ("Every Distillate claim carries item IDs (validated)", bool(d), ""),
        ("Knowledge Distillate confirmed by the researcher (Key 4)", "key4" in st["keys"], ""),
        ("gaps_report.md produced with all sections", "gaps_report.md" in names, ""),
        ("ai_use_statement.md produced", "ai_use_statement.md" in names, ""),
        ("audit_log.jsonl complete", "audit_log.jsonl" in names, f"{len(st['audit'])} entries"),
        ("Official 360MDL_Toolkit_v2026 xlsx produced (T1–T17)", any(n.endswith(".xlsx") and "simplified" not in n for n in names), ""),
        ("calculator.json produced", "calculator.json" in names, ""),
        ("No record without identifier in the core", not any(r.get("unverified") for r in core), ""),
    ]
    met = sum(1 for _, ok, _ in rows if ok)
    L = [f"# Navigator run checklist — {st['meta']['title']}", "", f"*Build v{st['meta']['version']} · {dt.date.today()}. Process criteria for this run; "
         "the reporting checklist for the manuscript is the 30-item MDL-RC 2026 (mdlrc_checklist.md).*", "",
         "| # | Criterion | Status | Notes |", "|---|---|---|---|"]
    for i, (crit, ok, note) in enumerate(rows, 1):
        L.append(f"| {i} | {crit} | {'✅' if ok else '❌'} | {note} |")
    L += ["", f"**Overall: {met}/20 criteria met.**"]
    return "\n".join(L) + "\n"


def checklist_md(st, R):
    done = {5: "T1", 8: "T1 §4, T3", 9: "T3", 12: "T4; audit_log.jsonl", 14: "T5", 15: "Flow diagram (Index Calculator)", 16: "T6",
            17: "T1 §6, M4", 18: "M1–M6", 20: f"M4; CovI {f2(R['covi'])}", 21: f"M2; MDI {f2(R['mdi'])}", 22: f"T15; {R['nKF']} KF",
            23: f"RI {f2(R['ri'])}; LOSO {f2(R['losoMin'])}", 29: "ai_use_statement.md", 30: "gaps_report.md"}
    L = [f"# MDL-RC 2026 reporting checklist — {st['meta']['title']}", "", "| # | Section | Item | Status | Where |", "|---|---|---|---|---|"]
    for sec, n, txt in RC:
        L.append(f"| {n} | {sec} | {txt} | {'computed' if n in done else 'researcher'} | {done.get(n, '')} |")
    return "\n".join(L) + "\n"


def recalc(xlsx):
    """Let LibreOffice (if installed) compute the workbook's formulas so cached values exist for viewers and for the
    Index Calculator, which reads values, not formulas. Silently skipped when soffice is absent."""
    soffice = shutil.which("soffice") or shutil.which("libreoffice")
    if not soffice:
        return False
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        src = os.path.join(td, "in.xlsx")
        shutil.copy(xlsx, src)
        r = subprocess.run([soffice, "--headless", "--convert-to", "xlsx:Calc MS Excel 2007 XML", "--outdir", os.path.join(td, "out"), src],
                           capture_output=True, text=True, timeout=300)
        dst = os.path.join(td, "out", "in.xlsx")
        if r.returncode == 0 and os.path.exists(dst):
            shutil.copy(dst, xlsx)
            return True
    return False


def run(st, state_path, outdir, styles=("ids", "apa", "harvard"), dimension_figures=False):
    os.makedirs(outdir, exist_ok=True)
    out = []
    R = indices.compute(st)
    short = st["meta"]["short"]
    v = st["meta"]["version"]
    # 1 toolkit xlsx (master)
    xlsx = os.path.join(outdir, f"360MDL_Toolkit_v2026_{short}_v{v}.xlsx")
    env = dict(os.environ, MDL_STATE=os.path.abspath(state_path))
    r = subprocess.run([sys.executable, os.path.join(HERE, "toolkit_writer.py"), xlsx], env=env, capture_output=True, text=True)
    if r.returncode != 0:
        # Never leave the researcher without a workbook: write a clearly named simplified export and record the failure.
        import simplified_xlsx
        xlsx = os.path.join(outdir, f"360MDL_Records_{short}_v{v}_simplified.xlsx")
        simplified_xlsx.write(st, R, xlsx)
        S.audit(st, "build:toolkit_writer_failed", error=r.stderr[-800:], fallback=os.path.basename(xlsx))
        open(os.path.join(outdir, "BUILD_WARNING.txt"), "w", encoding="utf-8").write(
            "The official 360MDL_Toolkit_v2026 workbook (T1–T17) could not be written in this environment.\n"
            "A simplified records workbook was produced instead. Re-run `mdl.py build` where openpyxl works, or send review_state.json "
            "to the author's environment. Error:\n" + r.stderr[-800:])
        out.append(os.path.join(outdir, "BUILD_WARNING.txt"))
    else:
        recalc(xlsx)
    out.append(xlsx)
    # 2 calculator json
    p = os.path.join(outdir, "calculator.json")
    json.dump({"generated": S.now(), "tool": "360° MDL Navigator v0.1", "input": R["model"],
               "result": {"N": R["N"], "SBI": R["sbi"], "CovI": R["covi"], "MDI": R["mdi"], "RI": R["ri"], "LOSO": R["loso"],
                          "LOSO_min": R["losoMin"], "convergence": R["conv"],
                          "kfs": [{"id": k["id"], "TS": k["ts"], "class": k["cls"], "families": k["families"]} for k in R["kfs"]],
                          "checks": R["checks"], "gates": R["gates"]}}, open(p, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    out.append(p)
    # 3 reports
    for name, text in [("gaps_report.md", gaps_report(st, R)), ("methods_draft.md", methods_draft(st, R)),
                       ("ai_use_statement.md", ai_statement(st)), ("mdlrc_checklist.md", checklist_md(st, R))]:
        p = os.path.join(outdir, name)
        open(p, "w", encoding="utf-8").write(text)
        out.append(p)
    p = os.path.join(outdir, "navigator_run_checklist.md")
    open(p, "w", encoding="utf-8").write(run_checklist(st, R, out + ["audit_log.jsonl", "calculator.json"]))
    out.append(p)
    # 4 distillate (markdown with figures + appendix, in the chosen citation style; Word export via pandoc when present)
    if st.get("distillate"):
        import figures
        ddir = os.path.join(outdir, "distillate")
        figs = figures.all_figures(st, st["distillate"], R, ddir)
        figs["dimension_figures"] = dimension_figures
        import docx_style
        ref = docx_style.REF if os.path.exists(docx_style.REF) else docx_style.make()
        for sty in styles:
            p = os.path.join(ddir, f"knowledge_distillate_{sty}.md")
            open(p, "w", encoding="utf-8").write(D.render(st, st["distillate"], style=sty, figs=figs, R=R))
            out.append(p)
            if shutil.which("pandoc"):
                docx = p.replace(".md", ".docx")
                r = subprocess.run(["pandoc", os.path.basename(p), "-o", os.path.basename(docx), "--resource-path", ddir,
                                    "--reference-doc", os.path.abspath(ref)], cwd=ddir, capture_output=True, text=True)
                if r.returncode == 0:
                    out.append(docx)
        p = os.path.join(outdir, "distillate_map.json")
        json.dump(D.map_json(st, st["distillate"]), open(p, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        out.append(p)
    # 5 audit log + state copy
    p = os.path.join(outdir, "audit_log.jsonl")
    with open(p, "w", encoding="utf-8") as f:
        for e in st["audit"]:
            f.write(json.dumps(e, ensure_ascii=False) + "\n")
    out.append(p)
    p = os.path.join(outdir, f"review_state_v{v}.json")
    shutil.copy(state_path, p)
    out.append(p)
    st["meta"]["version"] = v + 1
    return out

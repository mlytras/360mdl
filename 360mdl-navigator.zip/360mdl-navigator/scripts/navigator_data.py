# -*- coding: utf-8 -*-
"""Adapter: review_state.json  ->  the data interface consumed by toolkit_writer.py.

Set MDL_STATE to the state path before importing (mdl.py does this). Everything here is derived; nothing is invented:
cells the Navigator cannot fill from the state stay empty for the researcher.
"""
import datetime as dt
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import state as S  # noqa: E402

ST = S.load(os.environ["MDL_STATE"])
META, CANV = ST["meta"], ST["canvas"]
RECS = [r for r in ST["records"] if not r["duplicate_of"]]
REC = {r["id"]: r for r in ST["records"]}
CORE = [r for r in RECS if r["core"]]
CLUSTERS = [(c["name"], c.get("keywords", "")) for c in ST["clusters"]]
CNAME = [c[0] for c in CLUSTERS]
KFS = ST["key_findings"]
KF_OF = {}
for k in KFS:
    for i in k.get("ids", []):
        KF_OF.setdefault(i, []).append(k["id"])
KF_TEXT = {k["id"]: k["text"] for k in KFS}

CT_FULL = {k: f"{k} {v}" for k, v in S.CTS.items()}
CREF = {"CT1": "Theory", "CT2": "Theory", "CT3": "Theory", "CT4": "Theory", "CT5": "Industry", "CT6": "Practice",
        "CT7": "Practice", "CT8": "Practice"}
LOCUS = {"CT1": "Theory", "CT2": "Theory", "CT3": "Theory", "CT4": "Theory", "CT5": "Practice", "CT6": "Policy",
         "CT7": "Practice", "CT8": "Society"}
EXPL = {"CT1": "Theory building", "CT2": "Theory building", "CT3": "Benchmark", "CT4": "Theory building",
        "CT5": "Design guideline", "CT6": "Policy instrument", "CT7": "Managerial toolkit", "CT8": "Curriculum"}
RQFAM_DEFAULT = ["What (descriptive)", "Why (explanatory)", "How (design)", "What-if (predictive)", "Should (normative)"]


def _st(rec):
    return "proposed" if rec.get("sixR_status") != "confirmed" else "confirmed"


def citation(r):
    who = r.get("authors") or r.get("organisation") or ""
    venue = r.get("venue") or ""
    doi = f" https://doi.org/{r['doi']}" if r.get("doi") else (f" {r['url']}" if r.get("url") else "")
    return f"{who} ({r.get('year') or 'n.d.'}). {r['title']}. {venue}.{doi}".replace("..", ".")


def lead(r):
    if r.get("organisation") and not r.get("authors"):
        return r["organisation"]
    a = (r.get("authors") or "").split(",")[0].split(";")[0].strip()
    return a or r.get("organisation") or ""


def short_cite(r):
    return f"{lead(r)} ({r.get('year') or 'n.d.'})"


def sig(total):
    return "High" if total >= 10 else ("Medium" if total >= 8 else "Low")


def sixr_note(r):
    return " · ".join(f"{k} {v[0]}: {v[1]}" for k, v in (r.get("sixR") or {}).items())


# ------------------------------------------------------------------ banner (Start Here sheet)
c = S.counts(ST)
BANNER = (f"NAVIGATOR BUILD — {META['title']} ({META['tier']} tier, Mode {META.get('mode', '360')}), "
          f"{dt.date.today().strftime('%b %Y')}. Built by the 360° MDL Navigator v0.1. "
          "Values marked 'proposed' are AI proposals awaiting the researcher's key; nothing here is final until confirmed.")
BANNER_NOTE = (f"Records: {c['harvested']} harvested, {c['unique']} unique, {c['eligible']} eligible at Gate 1; Gate 2: "
               f"{c['pass']} Pass, {c['reserve']} Reserve, {c['exclude']} Exclude, {c['unscored']} unscored; core corpus {c['core']} "
               f"(Extended Evidence Pool {c['pool']}). Key findings: {len(KFS)}. "
               + " ".join(f"{k.upper()} turned {v.get('turned_at', '')[:10]}." for k, v in ST['keys'].items())
               + " Every record carries provenance (source, query, date, identifier); see the audit log.")

# ------------------------------------------------------------------ T1 canvas
_streams = {}
for code in S.STREAMS:
    u = ST["streams"].get(code)
    _streams[code] = ("Y", ", ".join(u.get("slices", [])), u.get("note", "")) if u and u.get("use") == "Y" else ("N", "", "")
_rqs = []
for i, q in enumerate(CANV.get("rqs", [])):
    if isinstance(q, dict):
        _rqs.append((q.get("text"), q.get("family") or RQFAM_DEFAULT[min(i, 4)], q.get("maps_to")))
    else:
        _rqs.append((q, RQFAM_DEFAULT[min(i, 4)], None))
CANVAS = {
    "title": CANV.get("title") or META["title"], "purpose": CANV.get("purpose"), "rationale": CANV.get("rationale"),
    "rqs": _rqs, "window": CANV.get("window"), "languages": CANV.get("languages"), "disciplines": CANV.get("disciplines"),
    "doctypes": CANV.get("doctypes"), "tier": META["tier"], "mode": META.get("mode", "360"),
    "registry": CANV.get("registry"), "calibration": CANV.get("calibration"), "update": CANV.get("update"),
    "adaptation": CANV.get("adaptation"), "streams": _streams, "clusters": CLUSTERS,
    "inclusion": CANV.get("inclusion", []), "exclusion": CANV.get("exclusion", []),
    "matrices": CANV.get("matrices") or {m: ("Y" if m in ("M1", "M2", "M3", "M4", "M6") else "N", "") for m in
                                         ("M1", "M2", "M3", "M4", "M5", "M6", "M7", "M8")},
    "team": CANV.get("team", []), "ai": CANV.get("ai") or [[
        f"Claude (Anthropic) via 360° MDL Navigator v0.1, {dt.date.today().strftime('%b %Y')}",
        "Search-string design; harvesting from open APIs; parsing of exports; de-duplication; Gate 1; proposed 6R scores with "
        "justification; proposed coding, clusters and key findings; draft Knowledge Distillate; index computation",
        "Two-Key Rule: every proposal confirmed by the researcher at Keys 1–4; no record without an identifier from an API, "
        "export or opened page", "audit_log.jsonl; gaps_report.md; ai_use_statement.md"]],
}
for k, v in list(CANVAS["matrices"].items()):
    if isinstance(v, list):
        CANVAS["matrices"][k] = tuple(v)

# ------------------------------------------------------------------ T3 stream log
STREAMLOG = []
for L in ST["stream_log"]:
    d = L.get("date")
    try:
        d = dt.date.fromisoformat(d) if isinstance(d, str) else d
    except ValueError:
        pass
    STREAMLOG.append((L["code"], L.get("slice"), L.get("source"), d, L.get("query"), L.get("filters"),
                      L.get("hits"), L.get("exported"), L.get("notes")))

# ------------------------------------------------------------------ T4 gate rows: core first, then pool, reserve, exclude
def _gate_row(r, status):
    dups = [x["id"] for x in ST["records"] if x["duplicate_of"] == r["id"]]
    note = f"{status}. Family {r['family']}. {short_cite(r)}. 6R {_st(r)} ({sixr_note(r)})" if r.get("sixR") else \
        f"{status}. Family {r['family']}. {short_cite(r)}. Not yet scored."
    if dups:
        note = f"Convergence: merged duplicate(s) at Gate 1: {', '.join(dups)}. " + note
    if r.get("unverified"):
        note = "UNVERIFIED (no identifier) — blocked at Gate 1. " + note
    return {"id": r["id"], "title": r["title"], "r": [r["sixR"][f"R{j}"][0] for j in range(1, 7)] if r.get("sixR") else [None] * 6,
            "found": len(set(r.get("found_in") or [r["stream"]])), "also": "; ".join(dups) or None,
            "aacods": ("AACODS: " + r["sixR"]["R2"][1]) if (r.get("sixR") and r["family"] in ("F3", "F4")) else None,
            "note": note}


GATE = []
for r in RECS:
    if r["gate1"]["status"] != "eligible":
        continue
    if r["core"]:
        GATE.append(_gate_row(r, "Core corpus" + ("" if r.get("core_status") == "confirmed" else " (proposed)")))
for r in RECS:
    if r["gate1"]["status"] != "eligible" or r["core"]:
        continue
    st = {"Pass": "Extended Evidence Pool – Pass, not in core", "Reserve": "Reserve – 6R total 5–6",
          "Exclude": "Excluded at Gate 2"}.get(r["decision"], "Awaiting 6R scores")
    GATE.append(_gate_row(r, st))

# ------------------------------------------------------------------ T6 master table + M4
MASTER, M4 = [], {}
for r in CORE:
    cd = r.get("coding") or {}
    cls = [int(x) for x in cd.get("clusters", [])]
    cts = cd.get("contribution_types") or []
    ct = cts[0] if cts else None
    kfs = KF_OF.get(r["id"], [])
    cname = "; ".join(f"K{c} {CNAME[c - 1]}" for c in cls if 0 < c <= len(CNAME))
    tot = sum(v[0] for v in r["sixR"].values()) if r.get("sixR") else None
    MASTER.append({
        "id": r["id"], "title": r["title"], "citation": citation(r), "group": cd.get("lead_group") or lead(r), "year": r.get("year"),
        "topics": cname, "focus": cd.get("focus"),
        "methodology": (f"{cd['method_family']}: {cd.get('design', '')}".strip(": ") if cd.get("method_family") else None),
        "method": cd.get("method_family"), "findings": cd.get("key_findings") or r.get("abstract"),
        "analysis": ("; ".join(f"K{c}" for c in cls) + (" · review " + ", ".join(cd["rq"]) if cd.get("rq") else "")) or None,
        "ct": CT_FULL.get(ct), "contribution": ("Primary: " + S.CTS[ct] + ("; also " + "; ".join(S.CTS[c] for c in cts[1:]) if len(cts) > 1 else "")) if ct else None,
        "significance": sig(tot) if tot is not None else None,
        "future": cd.get("future_research"), "limitations": cd.get("limitations"),
        "rescontrib": (f"Evidence for {', '.join(cd['rq'])} in {cname}" if cd.get("rq") and cname else None),
        "interpretation": ("Supports " + "; ".join(f"{k}: {KF_TEXT[k]}" for k in kfs)) if kfs else None,
        "exploit": EXPL.get(ct), "vbf": None,
        "_cls": cls, "_ct": ct, "_rec": r, "_kfs": kfs, "_cd": cd,
    })
    M4[r["id"]] = cls


def matrix_fill(k):
    def fn(m):
        r, ct, cls, kfs, cd = m["_rec"], m["_ct"], m["_cls"], m["_kfs"], m["_cd"]
        if k == 1:
            return {5: m["methodology"], 8: CREF.get(ct)}
        if k == 2:
            return {6: cd.get("data_source"), 7: cd.get("sample"), 8: cd.get("design"),
                    9: f"Coding status: {cd.get('status', 'proposed')}. Extracted from abstract / opened page; confirm against full text."}
        if k == 3:
            return {6: LOCUS.get(ct), 9: (f"Reach (R3 = {r['sixR']['R3'][0]}): {r['sixR']['R3'][1]}" if r.get("sixR") else None)}
        if k == 5:
            rq = cd.get("rq") or []
            fam = CANV.get("rqs", [])
            return {4: cd.get("own_rq"), 6: None, 7: rq[0] if rq else None, 9: ("Also " + ", ".join(rq[1:])) if len(rq) > 1 else None}
        if k == 6:
            return {4: cd.get("future_research"), 5: cd.get("limitations"), 6: cd.get("open_issue"),
                    7: f"K{cls[0]}" if cls else None,
                    8: "Practice" if r["family"] == "F3" else ("Policy" if r["family"] == "F4" else "Academic")}
        if k == 7:
            return {7: ("Use as evidence for " + "; ".join(kfs)) if kfs else "Context item (no key finding cited)",
                    9: "; ".join(kfs) if kfs else None}
        return {}
    return fn


# ------------------------------------------------------------------ T15 key findings
KF = [{"text": k["text"] + ("" if k.get("status") == "confirmed" else " [proposed]"),
       "rq": " / ".join(x for x in (k.get("rq"), k.get("cluster")) if x), "fams": k.get("families", []),
       "ids": "; ".join(k.get("ids", []))} for k in KFS]

# ------------------------------------------------------------------ T17 checklist: only what the Navigator can assert
_computed = {5: "T1", 8: "T1 §4, T3", 9: "T3", 12: "T4 (Convergence Flags), audit log", 14: "T5", 15: "Flow diagram (calculator)",
             16: "T6", 17: "T1 §6, M4", 18: "M1–M6", 20: "M4, T5", 21: "M2, T5", 22: "T15", 23: "T16", 29: "ai_use_statement.md"}
CHECK = {n: (("Y" if n in _computed else None), _computed.get(n), ("Pre-filled by the Navigator from the toolkit" if n in _computed else None))
         for n in range(1, 31)}

# ------------------------------------------------------------------ M8 value framework (from the Distillate, if drafted)
_fw = (ST.get("distillate") or {}).get("framework") or {}
_layers = ["Enablers", "Capabilities", "Processes", "Outcomes", "Value", "Measures"]
_stake = (_fw.get("stakeholders") or [])[:5]
_stake = _stake + ["—"] * (5 - len(_stake)) if _stake else ["Stakeholder 1", "Stakeholder 2", "Stakeholder 3", "Stakeholder 4", "Stakeholder 5"]
_cells = {lay["layer"]: lay for lay in _fw.get("layers", [])} if _fw else {}
M8 = {
    "name": _fw.get("name"),
    "stakeholders": _stake,
    "cells": [((_cells.get(L, {}).get("cells") or []) + [None] * 5)[:5] for L in _layers],
    "ids": ["; ".join(_cells.get(L, {}).get("ids", [])) or None for L in _layers],
    "kf": ["; ".join(_cells.get(L, {}).get("kf", [])) or None for L in _layers],
}

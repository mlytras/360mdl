# -*- coding: utf-8 -*-
"""Figures for the Knowledge Distillate, drawn from the state (never from the text). PNG at 200 dpi, 360° MDL palette.
Every figure is a view of toolkit data, so a reader can check it against the Master Table."""
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.patches import Patch  # noqa: E402

from state import FAMILIES, METHODS, TARGETS  # noqa: E402

FAMCOL = {"F1": "#1F4E79", "F2": "#7B3F99", "F3": "#E09F3E", "F4": "#2A9D8F", "F5": "#C8553D"}
NAVY, TEAL, LINE, MUTED = "#14213D", "#0F7C8C", "#D5DBE1", "#5B6B7F"
FOOT = "360° MDL v2026 · Navigator"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9, "axes.edgecolor": LINE, "axes.labelcolor": NAVY,
                     "xtick.color": MUTED, "ytick.color": MUTED, "axes.titleweight": "bold", "axes.titlecolor": NAVY,
                     "axes.spines.top": False, "axes.spines.right": False})
FAM = list(FAMILIES)


def _save(fig, path):
    fig.text(0.99, 0.01, FOOT, ha="right", va="bottom", fontsize=6.5, color=MUTED)
    fig.savefig(path, dpi=200, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    return path


def _ids_fams(st, ids):
    recs = {r["id"]: r for r in st["records"]}
    return [recs[i]["family"] for i in ids if i in recs]


def fig_phenomenon(st, d, path):
    """Dimensions × stream families: how many core items of each family support each dimension (the knowledge map)."""
    dims = d["dimensions"]
    data = [[sum(1 for f in _ids_fams(st, x.get("ids", [])) if f == fam) for fam in FAM] for x in dims]
    fig, ax = plt.subplots(figsize=(7.2, 0.5 + 0.55 * len(dims)))
    left = [0] * len(dims)
    for j, fam in enumerate(FAM):
        vals = [row[j] for row in data]
        ax.barh(range(len(dims)), vals, left=left, color=FAMCOL[fam], label=f"{fam} {FAMILIES[fam]}")
        left = [a + b for a, b in zip(left, vals)]
    ax.set_yticks(range(len(dims)))
    ax.set_yticklabels([x["name"] if len(x["name"]) < 48 else x["name"][:46] + "…" for x in dims])
    ax.invert_yaxis()
    ax.set_xlabel("core items supporting the dimension (an item may support several)")
    ts = [len(set(_ids_fams(st, x.get("ids", [])))) for x in dims]
    for i, (t, tot) in enumerate(zip(ts, left)):
        ax.text(tot + 0.3, i, f"TS {t}", va="center", fontsize=8, color=NAVY)
    ax.set_title("Knowledge map: every dimension is supported by several stream families")
    ax.set_xlim(0, max(left) * 1.18 + 1)
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.22), fontsize=7, frameon=False, ncol=3)
    return _save(fig, path)


def fig_dimension(st, dim, path):
    """One dimension: items by family and by year (left), method families (right)."""
    recs = {r["id"]: r for r in st["records"]}
    items = [recs[i] for i in dim.get("ids", []) if i in recs]
    years = sorted({int(r["year"]) for r in items if r.get("year")})
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(7.2, 2.6), gridspec_kw={"width_ratios": [1.5, 1]})
    if years:
        bottoms = {y: 0 for y in years}
        for fam in FAM:
            vals = [sum(1 for r in items if r["family"] == fam and r.get("year") == y) for y in years]
            a1.bar(years, vals, bottom=[bottoms[y] for y in years], color=FAMCOL[fam], width=0.7)
            for y, v in zip(years, vals):
                bottoms[y] += v
        a1.set_xticks(years)
        a1.set_xticklabels([str(y)[2:] if len(years) > 8 else str(y) for y in years])
        a1.set_ylabel("core items")
        a1.set_title("Items by year and stream family", fontsize=9)
        a1.yaxis.get_major_locator().set_params(integer=True)
    mc = {m: sum(1 for r in items if (r.get("coding") or {}).get("method_family") == m) for m in METHODS}
    mc = {k: v for k, v in mc.items() if v}
    if mc:
        ks = sorted(mc, key=mc.get)
        a2.barh(ks, [mc[k] for k in ks], color=TEAL)
        a2.set_title("Method families", fontsize=9)
        a2.xaxis.get_major_locator().set_params(integer=True)
    fams = sorted(set(r["family"] for r in items))
    fig.suptitle(f"{dim['name']} — {len(items)} items, TS {len(fams)} ({', '.join(fams)})", fontsize=10, fontweight="bold", color=NAVY, x=0.01, ha="left")
    fig.tight_layout()
    return _save(fig, path)


def fig_findings(st, path):
    """Triangulation strength of every key finding, coloured by class."""
    kfs = st["key_findings"]
    if not kfs:
        return None
    fig, ax = plt.subplots(figsize=(7.2, 0.4 + 0.3 * len(kfs)))
    col = {"Robust": "#1C7A5F", "Supported": "#E09F3E", "Tentative": "#C8553D"}
    for i, k in enumerate(kfs):
        ts = len(set(k["families"]))
        cls = "Robust" if ts >= 3 else "Supported" if ts == 2 else "Tentative"
        left = 0
        for fam in FAM:
            if fam in k["families"]:
                ax.barh(i, 1, left=left, color=FAMCOL[fam], edgecolor="white")
                left += 1
        ax.text(5.15, i, cls, va="center", fontsize=8, color=col[cls], fontweight="bold")
    ax.set_yticks(range(len(kfs)))
    ax.set_yticklabels([f"{k['id']}  {k['text'][:58]}…" if len(k["text"]) > 60 else f"{k['id']}  {k['text']}" for k in kfs], fontsize=7.5)
    ax.invert_yaxis()
    ax.set_xlim(0, 6.3)
    ax.set_xticks(range(0, 6))
    ax.set_xlabel("stream families supporting the finding (TS)")
    ax.axvline(3, color=LINE, ls="--", lw=1)
    ax.set_title("Established knowledge: findings supported by three or more families are Robust")
    ax.legend(handles=[Patch(color=FAMCOL[f], label=f) for f in FAM], loc="lower right", fontsize=7, frameon=False, ncol=5)
    return _save(fig, path)


def fig_contested(st, d, path):
    """Which families speak on each contested point."""
    items = d.get("contested", [])
    if not items:
        return None
    fig, ax = plt.subplots(figsize=(7.2, 0.6 + 0.42 * len(items)))
    for i, e in enumerate(items):
        fams = set(_ids_fams(st, e.get("ids", [])))
        for j, fam in enumerate(FAM):
            ax.add_patch(plt.Rectangle((j, i), 0.92, 0.82, color=FAMCOL[fam] if fam in fams else "#EEF1F4"))
    ax.set_xlim(0, 5)
    ax.set_ylim(len(items), 0)
    ax.set_xticks([j + 0.46 for j in range(5)])
    ax.set_xticklabels(FAM)
    ax.set_yticks([i + 0.41 for i in range(len(items))])
    ax.set_yticklabels([(e["text"][:70] + "…") if len(e["text"]) > 72 else e["text"] for e in items], fontsize=7.5)
    ax.set_title("Contested and emerging knowledge: which families speak on each point")
    for s in ("left", "bottom"):
        ax.spines[s].set_visible(False)
    ax.tick_params(length=0)
    return _save(fig, path)


def fig_axes(st, d, path):
    """Future research axes × (methods under-used, streams to consult)."""
    axes = d.get("future_axes", [])
    if not axes:
        return None
    cols = [f"{f}" for f in FAM] + [m.split("/")[0] for m in METHODS]
    fig, ax = plt.subplots(figsize=(7.4, 0.8 + 0.42 * len(axes)))
    for i, e in enumerate(axes):
        for j, c in enumerate(cols):
            on = (c in e.get("streams_needed", [])) if j < 5 else (METHODS[j - 5] in e.get("methods_underused", []))
            color = (FAMCOL[c] if j < 5 else TEAL) if on else "#EEF1F4"
            ax.add_patch(plt.Rectangle((j, i), 0.92, 0.82, color=color))
    ax.set_xlim(0, len(cols))
    ax.set_ylim(len(axes), 0)
    ax.set_xticks([j + 0.46 for j in range(len(cols))])
    ax.set_xticklabels(cols, rotation=40, ha="right", fontsize=7)
    ax.set_yticks([i + 0.41 for i in range(len(axes))])
    ax.set_yticklabels([e["title"] for e in axes], fontsize=8)
    ax.axvline(5, color=NAVY, lw=1)
    ax.text(2.5, -0.3, "streams to consult", ha="center", fontsize=7.5, color=MUTED)
    ax.text(9.5, -0.3, "methods under-used in the corpus", ha="center", fontsize=7.5, color=MUTED)
    ax.set_ylim(len(axes), -0.7)
    ax.set_title("Future research axes: where the next evidence should come from", pad=10)
    for s in ("left", "bottom"):
        ax.spines[s].set_visible(False)
    ax.tick_params(length=0)
    return _save(fig, path)


def fig_limits(st, R, path):
    """Index profile against the tier targets (the honest picture)."""
    T = R["T"]
    names = ["SBI", "CovI", "MDI", "RI", "LOSO"]
    vals = [R["sbi"], R["covi"], R["mdi"], R["ri"], R["losoMin"]]
    tg = [T["sbi"], T["covi"], T["mdi"], T["ri"], T["loso"]]
    fig, ax = plt.subplots(figsize=(7.2, 2.8))
    x = range(len(names))
    bars = ax.bar(x, [v or 0 for v in vals], color=[("#1C7A5F" if (t is None or (v is not None and v >= t)) else "#C8553D") for v, t in zip(vals, tg)], width=0.55)
    for i, t in enumerate(tg):
        if t is not None:
            ax.plot([i - 0.33, i + 0.33], [t, t], color=NAVY, lw=1.5)
    for b, v in zip(bars, vals):
        ax.text(b.get_x() + b.get_width() / 2, (v or 0) + 0.02, "—" if v is None else f"{v:.2f}", ha="center", fontsize=8, color=NAVY)
    ax.set_xticks(list(x))
    ax.set_xticklabels(names)
    ax.set_ylim(0, 1.12)
    ax.set_title(f"Index profile of this Core Knowledge ({R['tier']} tier; bars = value, lines = target)")
    return _save(fig, path)


def fig_open_issues(st, d, path):
    issues = d.get("open_issues", [])
    if not issues:
        return None
    dims = [x["name"] for x in d["dimensions"]]
    counts = [sum(1 for e in issues if e.get("dimension") == n) for n in dims]
    fig, ax = plt.subplots(figsize=(7.2, 0.5 + 0.4 * len(dims)))
    ax.barh(range(len(dims)), counts, color="#E09F3E")
    ax.set_yticks(range(len(dims)))
    ax.set_yticklabels([n if len(n) < 48 else n[:46] + "…" for n in dims])
    ax.invert_yaxis()
    ax.xaxis.get_major_locator().set_params(integer=True)
    ax.set_xlabel("open research issues raised by the corpus")
    ax.set_title("Open research issues by dimension")
    return _save(fig, path)


def all_figures(st, d, R, outdir):
    os.makedirs(outdir, exist_ok=True)
    out = {"phenomenon": fig_phenomenon(st, d, os.path.join(outdir, "D1_knowledge_map.png")),
           "findings": fig_findings(st, os.path.join(outdir, "D3_triangulation.png")),
           "contested": fig_contested(st, d, os.path.join(outdir, "D4_contested.png")),
           "open_issues": fig_open_issues(st, d, os.path.join(outdir, "D5_open_issues.png")),
           "axes": fig_axes(st, d, os.path.join(outdir, "D6_future_axes.png")),
           "limits": fig_limits(st, R, os.path.join(outdir, "D7_index_profile.png")), "dims": []}
    for i, dim in enumerate(d["dimensions"], 1):
        out["dims"].append(fig_dimension(st, dim, os.path.join(outdir, f"D2_{i}_dimension.png")))
    return out

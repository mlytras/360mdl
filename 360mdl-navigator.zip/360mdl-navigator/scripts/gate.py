# -*- coding: utf-8 -*-
"""Gate 1 (eligibility, mechanical) and the core-corpus proposal (Gate 3 CCD curation, spec §5C).

Gate 1 rules (rules.json, all optional):
  {"years": [2015, 2026], "languages": ["English"], "exclude_types": ["erratum", "editorial"],
   "require_any": ["smart cit", "urban"], "require_all": [], "exclude_any": ["retracted"]}
Text matching uses title + abstract, case-insensitive. A record without identifier (unverified) is always blocked.
"""
import re

from state import TARGETS, FAMILY_OF


def gate1(st, rules):
    y0, y1 = (rules.get("years") or [None, None])
    langs = [x.lower() for x in rules.get("languages", [])]
    ex_types = [x.lower() for x in rules.get("exclude_types", [])]
    req_any = [x.lower() for x in rules.get("require_any", [])]
    req_all = [x.lower() for x in rules.get("require_all", [])]
    ex_any = [x.lower() for x in rules.get("exclude_any", [])]
    n_el = n_ex = 0
    for r in st["records"]:
        if r["duplicate_of"]:
            continue
        reason = None
        text = f"{r.get('title') or ''} {r.get('abstract') or ''}".lower()
        if r.get("unverified"):
            reason = "no identifier (unverified)"
        elif y0 and r.get("year") and int(r["year"]) < y0:
            reason = f"year {r['year']} < {y0}"
        elif y1 and r.get("year") and int(r["year"]) > y1:
            reason = f"year {r['year']} > {y1}"
        elif langs and r.get("_language") and r["_language"].lower() not in langs:
            reason = f"language {r['_language']}"
        elif ex_types and r.get("_doctype") and any(t in r["_doctype"].lower() for t in ex_types):
            reason = f"document type {r['_doctype']}"
        elif req_any and not any(t in text for t in req_any):
            reason = "none of the required terms in title/abstract"
        elif req_all and not all(t in text for t in req_all):
            reason = "a required term is missing"
        elif ex_any and any(t in text for t in ex_any):
            reason = "an exclusion term is present"
        if reason:
            r["gate1"] = {"status": "excluded", "reason": reason}
            n_ex += 1
        else:
            r["gate1"] = {"status": "eligible", "reason": None}
            n_el += 1
    return {"eligible": n_el, "excluded": n_ex, "rules": rules}


def propose_core(st):
    """All Gate-2 Pass items, curated to the tier's maximum with the CCD rules: family share ≤ 40 %, keep ≥ 10 % F5 (15 %
    Advanced), ≤ 3 items per lead author/group, prefer the highest 6R total, then convergence (found in ≥ 2 streams)."""
    T = TARGETS[st["meta"]["tier"]]
    recs = [r for r in st["records"] if not r["duplicate_of"] and r["gate1"]["status"] == "eligible" and r["decision"] == "Pass"]
    recs.sort(key=lambda r: (-sum(v[0] for v in r["sixR"].values()), -len(r.get("found_in") or []), r["id"]))
    cap = T["core"][1]
    chosen, fam, auth = [], {}, {}

    def lead(r):
        return (r.get("coding") or {}).get("lead_group") or (r.get("authors") or r.get("organisation") or "").split(",")[0].split(";")[0].strip().lower()

    # first pass: guarantee F5 and grey quotas by taking the best of each family up to the share cap
    for r in recs:
        if len(chosen) >= cap:
            break
        f = r["family"]
        if fam.get(f, 0) + 1 > max(1, int(0.40 * cap)):
            continue
        if auth.get(lead(r), 0) >= 3:
            continue
        chosen.append(r)
        fam[f] = fam.get(f, 0) + 1
        auth[lead(r)] = auth.get(lead(r), 0) + 1
    ids = {r["id"] for r in chosen}
    for r in st["records"]:
        r["core"] = r["id"] in ids
        r["core_status"] = "proposed" if r["core"] else None
    return {"pass": len(recs), "core": len(chosen), "cap": cap, "by_family": fam}

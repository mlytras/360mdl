# -*- coding: utf-8 -*-
"""Readers for the files a researcher already has: Scopus CSV, Web of Science (tab-delimited or 'savedrecs.txt'),
RIS (Zotero, EndNote, Mendeley), BibTeX, PubMed CSV, OpenAlex/Crossref JSON, or a generic CSV with a 'title' column.
Every reader returns a list of dicts with the record fields of state.add_record (title, authors, year, venue, doi, url,
abstract, open_access …). Nothing is invented: a field the file does not carry stays None.
"""
import csv
import json
import os
import re

csv.field_size_limit(10 ** 8)


def _clean_doi(x):
    if not x:
        return None
    x = str(x).strip()
    x = re.sub(r"^(https?://)?(dx\.)?doi\.org/", "", x, flags=re.I)
    x = re.sub(r"^doi:\s*", "", x, flags=re.I)
    return x.lower() or None


def _year(x):
    m = re.search(r"(19|20)\d{2}", str(x or ""))
    return int(m.group(0)) if m else None


def _pick(row, *names):
    low = {k.lower().strip(): v for k, v in row.items() if k}
    for n in names:
        v = low.get(n.lower())
        if v not in (None, ""):
            return str(v).strip()
    return None


def read_csv(path):
    with open(path, encoding="utf-8-sig", newline="") as f:
        sample = f.read(4096)
        f.seek(0)
        try:
            dialect = csv.Sniffer().sniff(sample, delimiters=",;\t")
        except csv.Error:
            dialect = csv.excel
        rows = list(csv.DictReader(f, dialect=dialect))
    out = []
    for row in rows:
        title = _pick(row, "Title", "Article Title", "TI", "Document Title", "title")
        if not title:
            continue
        out.append({
            "title": title,
            "authors": _pick(row, "Authors", "Author full names", "AU", "AF", "Author(s)", "authors"),
            "year": _year(_pick(row, "Year", "PY", "Publication Year", "year", "Pub Date", "Date")),
            "venue": _pick(row, "Source title", "SO", "Source Title", "Journal", "Publication Title", "venue", "Journal/Book"),
            "doi": _clean_doi(_pick(row, "DOI", "DI", "doi")),
            "url": _pick(row, "Link", "URL", "url"),
            "pmid": _pick(row, "PMID", "pmid"),
            "abstract": _pick(row, "Abstract", "AB", "abstract"),
            "open_access": _pick(row, "Open Access", "OA", "open_access"),
            "_cited_by": _pick(row, "Cited by", "TC", "Times Cited, All Databases", "cited_by"),
            "_doctype": _pick(row, "Document Type", "DT", "Publication Type"),
            "_language": _pick(row, "Language of Original Document", "LA", "Language"),
        })
    return out


def read_ris(path):
    out, cur = [], {}
    with open(path, encoding="utf-8-sig", errors="replace") as f:
        for line in f:
            m = re.match(r"^([A-Z][A-Z0-9])  - ?(.*)$", line.rstrip("\n"))
            if not m:
                continue
            tag, val = m.group(1), m.group(2).strip()
            if tag == "TY":
                cur = {"_type": val, "authors": []}
            elif tag == "ER":
                if cur.get("title"):
                    cur["authors"] = "; ".join(cur["authors"]) or None
                    out.append(cur)
                cur = {}
            elif tag in ("TI", "T1"):
                cur["title"] = val
            elif tag in ("AU", "A1"):
                cur["authors"].append(val)
            elif tag in ("PY", "Y1", "DA"):
                cur["year"] = cur.get("year") or _year(val)
            elif tag in ("JO", "JF", "T2", "J2"):
                cur["venue"] = cur.get("venue") or val
            elif tag == "DO":
                cur["doi"] = _clean_doi(val)
            elif tag == "UR":
                cur["url"] = cur.get("url") or val
            elif tag in ("AB", "N2"):
                cur["abstract"] = val
            elif tag == "LA":
                cur["_language"] = val
    for r in out:
        r.pop("_type", None)
    return out


def read_bibtex(path):
    txt = open(path, encoding="utf-8-sig", errors="replace").read()
    out = []
    for m in re.finditer(r"@(\w+)\s*\{\s*([^,]*),(.*?)\n\}", txt, flags=re.S):
        body = m.group(3)
        fields = {}
        for fm in re.finditer(r"(\w+)\s*=\s*(\{(?:[^{}]|\{[^{}]*\})*\}|\"[^\"]*\"|[^,\n]+)", body):
            k, v = fm.group(1).lower(), fm.group(2).strip().strip("{}\"").strip()
            fields[k] = re.sub(r"\s+", " ", v)
        if not fields.get("title"):
            continue
        out.append({"title": fields["title"], "authors": fields.get("author", "").replace(" and ", "; ") or None,
                    "year": _year(fields.get("year")), "venue": fields.get("journal") or fields.get("booktitle"),
                    "doi": _clean_doi(fields.get("doi")), "url": fields.get("url"), "abstract": fields.get("abstract")})
    return out


def read_json(path):
    d = json.load(open(path, encoding="utf-8"))
    if isinstance(d, dict):
        d = d.get("results") or d.get("message", {}).get("items") or d.get("records") or d.get("items") or []
    out = []
    for w in d:
        if "display_name" in w or "primary_location" in w:      # OpenAlex work
            loc = (w.get("primary_location") or {}).get("source") or {}
            auths = "; ".join(a.get("author", {}).get("display_name", "") for a in w.get("authorships", []) if a.get("author"))
            orcid = next((a["author"].get("orcid") for a in w.get("authorships", []) if a.get("author") and a["author"].get("orcid")), None)
            out.append({"title": w.get("display_name") or w.get("title"), "authors": auths or None, "orcid": orcid, "year": w.get("publication_year"),
                        "venue": loc.get("display_name"), "doi": _clean_doi(w.get("doi")), "openalex": w.get("id"),
                        "url": (w.get("primary_location") or {}).get("landing_page_url"),
                        "open_access": (w.get("open_access") or {}).get("oa_status"), "abstract": _inv_abstract(w.get("abstract_inverted_index")),
                        "_cited_by": w.get("cited_by_count"), "_doctype": w.get("type"), "_language": w.get("language")})
        elif "DOI" in w and "title" in w:                         # Crossref item
            t = w.get("title"); t = t[0] if isinstance(t, list) else t
            cont = w.get("container-title"); cont = cont[0] if isinstance(cont, list) else cont
            auths = "; ".join(f"{a.get('family', '')}, {a.get('given', '')}".strip(", ") for a in w.get("author", []))
            yr = (w.get("issued") or {}).get("date-parts", [[None]])[0][0]
            out.append({"title": t, "authors": auths or None, "year": yr, "venue": cont, "doi": _clean_doi(w.get("DOI")),
                        "url": w.get("URL"), "abstract": re.sub(r"<[^>]+>", "", w.get("abstract", "")) or None, "_doctype": w.get("type")})
        elif "title" in w:                                         # generic / Navigator records
            r = dict(w)
            r["doi"] = _clean_doi(r.get("doi"))
            out.append(r)
    return out


def _inv_abstract(inv):
    if not inv:
        return None
    pos = {}
    for word, idxs in inv.items():
        for i in idxs:
            pos[i] = word
    return " ".join(pos[i] for i in sorted(pos))


def read_any(path):
    ext = os.path.splitext(path)[1].lower()
    head = open(path, encoding="utf-8-sig", errors="replace").read(2000)
    if ext == ".ris" or re.search(r"^TY  - ", head, flags=re.M):
        return read_ris(path)
    if ext == ".bib" or head.lstrip().startswith("@"):
        return read_bibtex(path)
    if ext == ".json" or head.lstrip().startswith(("{", "[")):
        return read_json(path)
    if ext in (".csv", ".txt", ".tsv"):
        return read_csv(path)
    raise ValueError(f"unknown export format: {path}")

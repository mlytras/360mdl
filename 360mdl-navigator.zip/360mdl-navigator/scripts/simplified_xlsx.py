# -*- coding: utf-8 -*-
"""Fallback workbook, used ONLY when the official 360MDL_Toolkit_v2026 writer fails in the researcher's environment.
Six plain sheets (Master Records, 6R Scores, Cluster Matrix, Findings, Stream Log, Indices). It is NOT the toolkit of the
method and is named *_simplified.xlsx so that nobody mistakes it for T1–T17; the Index Calculator does not read it."""
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter

from state import FAMILIES, METHODS

HDR = PatternFill("solid", fgColor="DBEAFE")
ALT = PatternFill("solid", fgColor="F8FAFC")


def _sheet(wb, title, header, rows, widths=None):
    ws = wb.create_sheet(title)
    ws.append(header)
    for c in ws[1]:
        c.font = Font(bold=True)
        c.fill = HDR
        c.alignment = Alignment(wrap_text=True, vertical="top")
    for i, r in enumerate(rows, start=2):
        ws.append(r)
        if i % 2 == 0:
            for c in ws[i]:
                c.fill = ALT
    ws.freeze_panes = "A2"
    for j, h in enumerate(header, 1):
        w = max([len(str(h))] + [len(str(r[j - 1])) if j - 1 < len(r) and r[j - 1] is not None else 0 for r in rows[:200]])
        ws.column_dimensions[get_column_letter(j)].width = max(10, min(60, w + 2))
    return ws


def write(st, R, path):
    wb = Workbook()
    wb.remove(wb.active)
    recs = [r for r in st["records"] if not r["duplicate_of"]]
    cl = st["clusters"]
    rows = []
    for r in recs:
        cd = r.get("coding") or {}
        sx = r.get("sixR") or {}
        tot = sum(v[0] for v in sx.values()) if sx else None
        rows.append([r["id"], r["title"], r.get("authors") or r.get("organisation"), r.get("year"), r.get("venue"),
                     r.get("doi") or r.get("url"), r["stream"], r["slice"], r["family"], (r.get("provenance") or {}).get("source"),
                     r.get("_doctype"), r.get("_cited_by"), r["gate1"]["status"], tot] + [sx.get(f"R{i}", [None])[0] for i in range(1, 7)] +
                    [r.get("decision"), "core" if r["core"] else "", r.get("sixR_status"), cd.get("method_family"),
                     ", ".join(f"K{c}" for c in cd.get("clusters", [])), ", ".join(cd.get("rq", [])), ", ".join(cd.get("contribution_types", [])),
                     cd.get("key_findings")])
    _sheet(wb, "Master Records", ["ID", "Title", "Authors/Org", "Year", "Source", "DOI/URL", "Stream", "Slice", "Family", "Source_DB", "Document_Type",
                                  "Cited_By", "Gate1_Status", "Score_Total", "R1", "R2", "R3", "R4", "R5", "R6", "Decision", "Core", "Score_Status",
                                  "Method_Family", "Clusters", "RQs", "Contribution_Types", "Key_Finding"], rows)
    rows = []
    for r in recs:
        if r["gate1"]["status"] != "eligible" or not r.get("sixR"):
            continue
        sx = r["sixR"]
        row = [r["id"], r["title"]]
        for i in range(1, 7):
            row += [sx[f"R{i}"][0], sx[f"R{i}"][1]]
        row += [sum(v[0] for v in sx.values()), r.get("decision"), r.get("sixR_status")]
        rows.append(row)
    hdr = ["ID", "Title"]
    for i in range(1, 7):
        hdr += [f"R{i}", f"R{i} justification"]
    _sheet(wb, "6R Scores", hdr + ["Total", "Decision", "Status"], rows)
    core = [r for r in recs if r["core"]]
    rows = [[f"K{c['k']}", c["name"]] + [1 if c["k"] in [int(x) for x in (r.get("coding") or {}).get("clusters", [])] else 0 for r in core] for c in cl]
    for row in rows:
        row.append(sum(row[2:]))
    _sheet(wb, "Cluster Matrix", ["Cluster", "Name"] + [r["id"] for r in core] + ["Coverage"], rows)
    _sheet(wb, "Findings", ["ID", "Cluster", "RQ", "Finding", "Supporting IDs", "Families", "TS", "Class", "Status"],
           [[k["id"], k.get("cluster"), k.get("rq"), k["text"], ", ".join(k["ids"]), ", ".join(k["families"]), len(k["families"]),
             "Robust" if len(k["families"]) >= 3 else "Supported" if len(k["families"]) == 2 else "Tentative", k.get("status")] for k in st["key_findings"]])
    _sheet(wb, "Stream Log", ["#", "Stream", "Slice", "Source", "Date", "Query", "Filters", "Hits", "Exported", "Status", "Notes"],
           [[e.get("log"), e["code"], e.get("slice"), e.get("source"), e.get("date"), e.get("query"), e.get("filters"), e.get("hits"), e.get("exported"),
             e.get("status"), e.get("notes")] for e in st["stream_log"]])
    T = R["T"]
    idx = [["SBI", R["sbi"], T["sbi"]], ["CovI", R["covi"], T["covi"]], ["MDI", R["mdi"], T["mdi"]], ["RI", R["ri"], T["ri"]],
           ["LOSO (worst case)", R["losoMin"], T["loso"]], ["Convergence Rate", R["conv"], None], ["Core N", R["N"], f"{T['core'][0]}–{T['core'][1]}"]]
    rows = [[n, v, t, ("PASS" if (t is None or (isinstance(t, str)) or (v is not None and v >= t)) else "CHECK")] for n, v, t in idx]
    rows.append([])
    rows.append(["Core items by family"] + [f"{f}: {R['model']['coreByFamily'].get(f, 0)}" for f in FAMILIES])
    rows.append(["Method families"] + [f"{m}: {c}" for m, c in zip(METHODS, R["mcounts"]) if c])
    _sheet(wb, "Indices", ["Index", "Value", "Target", "Status"], rows)
    wb.save(path)
    return path

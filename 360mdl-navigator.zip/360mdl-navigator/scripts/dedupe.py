# -*- coding: utf-8 -*-
"""De-duplication across streams (Gate 1, spec §5A): the same work found in two streams is ONE unique item,
kept in the first stream in protocol order, with a Convergence Flag (found_in lists every stream).
Match by DOI (exact, case-insensitive), then by normalised title (≥ 0.93 similarity and same year ± 1 if both known)."""
import difflib
import re

ORDER = ["WOS", "SCO", "GSC", "DOM", "IND", "GOV", "HCR", "T2P", "GSP", "RCO", "ADS", "INS", "AUT", "EMV"]


def norm_title(t):
    t = re.sub(r"[^a-z0-9 ]", " ", (t or "").lower())
    return re.sub(r"\s+", " ", t).strip()


def run(st, threshold=0.93):
    recs = [r for r in st["records"]]
    recs.sort(key=lambda r: (ORDER.index(r["stream"]) if r["stream"] in ORDER else 99, r["id"]))
    kept = []
    merged = 0
    for r in recs:
        if r["duplicate_of"]:
            continue
        match = None
        for k in kept:
            if r["doi"] and k["doi"] and r["doi"].lower() == k["doi"].lower():
                match = k
                break
            a, b = norm_title(r["title"]), norm_title(k["title"])
            if a and b and len(a) > 20 and difflib.SequenceMatcher(None, a, b).ratio() >= threshold:
                if r.get("year") and k.get("year") and abs(int(r["year"]) - int(k["year"])) > 1:
                    continue
                match = k
                break
        if match and match is not r:
            r["duplicate_of"] = match["id"]
            if r["stream"] not in match["found_in"]:
                match["found_in"].append(r["stream"])
            for f in ("doi", "url", "abstract", "pmid", "openalex", "year", "venue", "authors", "open_access"):
                if not match.get(f) and r.get(f):
                    match[f] = r[f]
            merged += 1
        else:
            kept.append(r)
    return merged

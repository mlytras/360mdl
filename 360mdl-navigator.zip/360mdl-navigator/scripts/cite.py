# -*- coding: utf-8 -*-
"""Citation formatting for the Distillate: in-text (Author, Year) and reference lists in APA 7 or Harvard,
built only from the record fields (authors / organisation, year, title, venue, doi, url). Nothing is completed from memory."""
import re

ID_RE = re.compile(r"\b[A-Z]{3}-[A-Z]{2,3}-\d{2,3}\b")


def surnames(rec):
    """Return list of (surname, initials) from the stored authors string, or [(organisation, '')]."""
    a = (rec.get("authors") or "").strip()
    if not a:
        return [(rec.get("organisation") or "Unknown", "")]
    if ";" in a:                                                   # "Family, Given; Family, Given"  (RIS, Scopus full names)
        parts = [p.strip() for p in a.split(";") if p.strip()]
    elif re.search(r"[A-Za-z'\-]+\s+[A-Z]{1,3}(,|$)", a) and not re.search(r",\s*[A-Z][a-z]", a):
        parts = [p.strip() for p in a.split(",") if p.strip()]        # "Family AB, Family CD"  (PubMed / WoS short)
    elif re.search(r",\s*[A-Z]\.", a):                               # "Family, G., Family, G. & Family, G."
        toks = [t.strip() for t in re.split(r",\s*(?:&\s*|and\s*)?", a.replace(" & ", ", ").replace(" and ", ", ")) if t.strip()]
        parts = [f"{toks[i]}, {toks[i + 1]}" if i + 1 < len(toks) and re.fullmatch(r"(?:[A-Z]\.\s?)+(?:-[A-Z]\.)?", toks[i + 1]) else toks[i]
                 for i in range(0, len(toks), 2)]
    else:
        parts = [p.strip() for p in re.split(r",| and | & ", a) if p.strip()]
    out = []
    for p in parts:
        p = p.strip(" .")
        if "," in p:                                   # Family, Given
            fam, giv = [x.strip() for x in p.split(",", 1)]
            ini = "".join(w[0] + "." for w in re.split(r"[\s\-]+", giv) if w)
        else:
            toks = p.split()
            if len(toks) >= 2 and re.fullmatch(r"[A-Z]{1,3}", toks[-1]):      # Family AB
                fam, ini = " ".join(toks[:-1]), "".join(c + "." for c in toks[-1])
            elif len(toks) >= 2:                                               # Given Family
                fam, ini = toks[-1], "".join(w[0] + "." for w in toks[:-1])
            else:
                fam, ini = p, ""
        out.append((fam, ini))
    return out or [(rec.get("organisation") or "Unknown", "")]


def intext(rec, style):
    s = surnames(rec)
    y = rec.get("year") or "n.d."
    if len(s) == 1:
        who = s[0][0]
    elif len(s) == 2:
        who = f"{s[0][0]} {'&' if style == 'apa' else 'and'} {s[1][0]}"
    else:
        who = f"{s[0][0]} et al."
    return f"{who}, {y}"


def reference(rec, style):
    s = surnames(rec)
    y = rec.get("year") or "n.d."
    title = rec.get("title", "").rstrip(".")
    venue = rec.get("venue") or ""
    link = f"https://doi.org/{rec['doi']}" if rec.get("doi") else (rec.get("url") or "")
    if style == "apa":
        if rec.get("authors"):
            names = [f"{f}, {i}" if i else f for f, i in s]
            auth = names[0] if len(names) == 1 else (", ".join(names[:-1]) + ", & " + names[-1] if len(names) <= 20 else ", ".join(names[:19]) + ", … " + names[-1])
        else:
            auth = s[0][0]
        return f"{auth} ({y}). {title}. *{venue}*. {link}".replace("*.", "").replace("  ", " ").strip()
    # harvard
    if rec.get("authors"):
        names = [f"{f}, {i}" if i else f for f, i in s]
        auth = names[0] if len(names) == 1 else (", ".join(names[:-1]) + " and " + names[-1])
    else:
        auth = s[0][0]
    avail = f" Available at: {link}" if link else ""
    return f"{auth} ({y}) '{title}', *{venue}*.{avail}".replace("**", "").strip()


def convert_text(text, recs, style):
    """Replace every [ID; ID] group with (Author, Year; Author, Year) for apa/harvard; leave as is for 'ids'."""
    if style == "ids":
        return text

    def repl(m):
        ids = ID_RE.findall(m.group(0))
        cites = []
        for i in ids:
            r = recs.get(i)
            cites.append(intext(r, style) if r else i)
        return "(" + "; ".join(cites) + ")"
    return re.sub(r"\[(?:[A-Z]{3}-[A-Z]{2,3}-\d{2,3}(?:\s*[;,]\s*)?)+\]", repl, text)


def sort_key(rec):
    return (surnames(rec)[0][0].lower(), str(rec.get("year") or ""))

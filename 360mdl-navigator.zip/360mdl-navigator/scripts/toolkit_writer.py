# -*- coding: utf-8 -*-
"""Builder for the 360° MDL v2026 operational Excel toolkit (blank + illustrative example)."""
import sys
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter as CL
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.formatting.rule import CellIsRule, FormulaRule, ColorScaleRule
from openpyxl.workbook.defined_name import DefinedName
from openpyxl.chart import BarChart, Reference
from openpyxl.chart.label import DataLabelList
from openpyxl.comments import Comment

import os
# Data module: navigator_data (reads MDL_STATE env var -> review_state.json). Any module exposing the same
# names (CANVAS, STREAMLOG, GATE, MASTER, M4, KF, CHECK, matrix_fill, optional PRISMA) can be substituted via MDL_DATA.
import importlib
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
EX = importlib.import_module(os.environ.get("MDL_DATA", "navigator_data"))

NAVY, TEAL, AMBER, CORAL, SLATE, LIGHT, LINE = "14213D", "0F7C8C", "E09F3E", "C8553D", "5B6B7F", "F4F6F8", "D5DBE1"
FAM_COL = {"F1": "1F4E79", "F2": "7B3F99", "F3": "E09F3E", "F4": "2A9D8F", "F5": "C8553D"}
FONT = "Calibri"
FOOTER = "360° MDL v2026 · © 2026 Miltiadis D. Lytras · CC BY 4.0 · 360° MDL is a trademark of the author"
LICENSE = "© 2026 Miltiadis D. Lytras · CC BY 4.0 · 360° MDL is a trademark of the author"
CITATION = ("Lytras, M. D. (2026). 360° MDL: The Multidimensional Literature Review Model — Version 2026 "
            "(Methodology Overview, Handbook and Toolkit). Zenodo. https://doi.org/[DOI to be assigned]")

thin = Side(style="thin", color=LINE)
BORDER = Border(left=thin, right=thin, top=thin, bottom=thin)
F_IN = PatternFill("solid", fgColor=LIGHT)
F_NAVY = PatternFill("solid", fgColor=NAVY)
F_TEAL = PatternFill("solid", fgColor=TEAL)
F_SEC = PatternFill("solid", fgColor="E3E8ED")
F_WHITE = PatternFill("solid", fgColor="FFFFFF")
F_PASS = PatternFill("solid", fgColor="D8F0E3")
F_CHECK = PatternFill("solid", fgColor="FBE3D6")
F_AMB = PatternFill("solid", fgColor="FDEBD0")
WRAP = Alignment(wrap_text=True, vertical="top")
CENTER = Alignment(horizontal="center", vertical="center", wrap_text=True)

# ----------------------------------------------------------------- spec lists
STREAMS = [  # code, stream name, approach, family
    ("WOS", "A1 Web of Science", "A Holistic", "F1"),
    ("SCO", "A2 Scopus", "A Holistic", "F1"),
    ("GSC", "A3 Google Scholar", "A Holistic", "F1"),
    ("DOM", "A6 Domain database (e.g., PubMed, IEEE Xplore, ACM DL, ERIC)", "A Holistic", "F1"),
    ("IND", "A4 Industry & Consulting white papers", "A Holistic", "F3"),
    ("GOV", "A5 Government & Global Organisations position/policy papers", "A Holistic", "F4"),
    ("HCR", "B1 Clarivate Highly Cited Researchers", "B Influencers", "F2"),
    ("T2P", "B2 Stanford–Elsevier Top 2% scientists", "B Influencers", "F2"),
    ("GSP", "B3 Google Scholar top profiles", "B Influencers", "F2"),
    ("RCO", "B4 Research.com top scientists", "B Influencers", "F2"),
    ("ADS", "B5 AD Scientific Index top scientists", "B Influencers", "F2"),
    ("INS", "B6 Institutional profile signal", "B Influencers", "F2"),
    ("AUT", "B* Review author's own OA papers (declared)", "B Influencers", "F2"),
    ("EMV", "C Emerging & Diverse Voices (C1–C5)", "C Emerging & Diverse", "F5"),
]
SLICES = [
    ("IMP", "Impact – most-cited of all time (A1/A2: 25)"),
    ("REC", "Recency – last 2 years (A1/A2: 10)"),
    ("FRO", "Frontier – special issues, last 5 years (A1/A2: 25)"),
    ("TOP", "Top papers by citations over time (A3: 10)"),
    ("WP", "White paper – industry/consulting (A4: 10)"),
    ("PP", "Position/policy paper – government & global orgs (A5: 10)"),
    ("MC", "Most-cited paper of influencer on topic (B)"),
    ("MR", "Most-recent paper of influencer on topic (B)"),
    ("RIS", "C1 Rising papers – high citation velocity, last 3 years"),
    ("GLS", "C2 Under-represented regions – Global South / non-dominant"),
    ("REG", "C3 Regional & non-English scholarship"),
    ("PRE", "C4 Frontier preprints & top conference papers"),
    ("CRI", "C5 Critical, dissenting or null-result studies"),
    ("SC", "Review author's own OA smart-city papers (B*, declared self-citation)"),
]
FAMILIES = [
    ("F1", "Academic databases", "A1, A2, A3, A6"),
    ("F2", "Influencer scholarship", "B1–B6, B*"),
    ("F3", "Industry practice", "A4"),
    ("F4", "Policy & global organisations", "A5"),
    ("F5", "Emerging & diverse voices", "C1–C5"),
]
METHODS = ["Quantitative", "Qualitative", "Mixed", "Design science/Artefact", "Conceptual/Theoretical",
           "Review/Bibliometric", "Simulation/Modelling", "Case study", "Delphi/Expert"]
CTS = ["CT1 Theoretical", "CT2 Conceptual framework/model", "CT3 Methodological", "CT4 Empirical evidence",
       "CT5 Artefact/Technological", "CT6 Policy", "CT7 Practice/Managerial", "CT8 Societal/Educational"]
EXPLOIT = ["Theory building", "Policy instrument", "Benchmark", "Design guideline", "Curriculum",
           "Managerial toolkit", "Standard", "Other"]
RQFAM = ["What (descriptive)", "Why (explanatory)", "How (design)", "What-if (predictive)", "Should (normative)"]
TIERS = ["Lite", "Standard", "Advanced"]
MODES = ["H", "I", "360"]
YNNA = ["Y", "N", "NA"]
YN = ["Y", "N"]
LOCUS = ["Theory", "Practice", "Industry", "Policy", "Society"]
VBF = ["Enablers", "Capabilities", "Processes", "Outcomes", "Value", "Measures"]
CREF = ["Theory", "Practice", "Industry"]
PERSP = ["Academic", "Practice", "Policy"]
PRIO = ["High", "Medium", "Low"]
RQTYPE = ["Explicit", "Implicit"]
RQIDS = [f"RQ{i}" for i in range(1, 7)]
KIDS = [f"K{i}" for i in range(1, 11)]
XMARK = ["x"]
MATRICES = [("M1", "General Matrix"), ("M2", "Methodology Matrix"), ("M3", "Contribution & Impact Matrix"),
            ("M4", "Topics/Keywords Coverage Matrix"), ("M5", "Research Questions Matrix"),
            ("M6", "Open Research Issues Matrix"), ("M7", "Interpretation & Exploitation Matrix"),
            ("M8", "Value-Based Framework Matrix")]
# tier parameters (spec §3, §4, §5C, §7). "—" = no target set by the spec for this tier.
TIER_PARAMS_HDR = ["Tier", "Core min", "Core max", "Min streams", "F5 quota", "CCD coverage threshold",
                   "SBI target", "CovI target", "MDI target", "RI target", "LOSO target", "Min matrices",
                   "Grey stream required", "Extended pool max"]
TIER_PARAMS = [
    ["Lite", 20, 30, 3, 0.10, 2, "—", "—", "—", "—", "—", 3, "N", "—"],
    ["Standard", 40, 50, 4, 0.10, 3, 0.70, 0.80, 0.60, 0.60, "—", 6, "Y", "—"],
    ["Advanced", 40, 50, 6, 0.15, 3, 0.70, 0.80, 0.60, 0.60, 0.70, 8, "Y", 30],
]
CHECKLIST = [
    ("Title & Abstract", 1, "Identify the review as a 360° MDL review and state the tier and mode."),
    ("Title & Abstract", 2, "Structured abstract including streams, corpus size, matrices and resilience index."),
    ("Introduction", 3, "Rationale and the knowledge problem."),
    ("Introduction", 4, "Review questions."),
    ("Protocol (P1)", 5, "Review Canvas: scope, time window, languages, disciplines."),
    ("Protocol (P1)", 6, "Protocol registration (registry & ID) or justification."),
    ("Protocol (P1)", 7, "Team, roles, and calibration procedure."),
    ("Sourcing (P2)", 8, "Streams and slices used, with rationale (≥ 3)."),
    ("Sourcing (P2)", 9, "Full search strings/filters and dates per stream (Stream Log)."),
    ("Sourcing (P2)", 10, "Influencer identification sources and profile-selection rules (if Approach B)."),
    ("Sourcing (P2)", 11, "Emerging & Diverse Voices strategy (if Approach C)."),
    ("Selection (P3)", 12, "Eligibility criteria & deduplication; convergence flags."),
    ("Selection (P3)", 13, "6R scoring scheme, thresholds and calibration (κ)."),
    ("Selection (P3)", 14, "CCD curation decisions and portfolio rules."),
    ("Selection (P3)", 15, "Flow diagram with numbers per stream and per gate."),
    ("Codification (P4)", 16, "ID scheme and Master Table fields."),
    ("Codification (P4)", 17, "Keyword-unification procedure and the final cluster list."),
    ("Analysis (P5)", 18, "Matrices used (≥ 3) and coding rules."),
    ("Analysis (P5)", 19, "Contribution taxonomy applied."),
    ("Analysis (P5)", 20, "Coverage heatmap and Coverage Index."),
    ("Analysis (P5)", 21, "Method diversity (M2) and MDI."),
    ("Synthesis & Interpretation (P6)", 22, "Key findings with Triangulation Strength."),
    ("Synthesis & Interpretation (P6)", 23, "Resilience Index and (Advanced) LOSO test."),
    ("Synthesis & Interpretation (P6)", 24, "Academic–practice–policy convergence/divergence."),
    ("Synthesis & Interpretation (P6)", 25, "Interpretation & exploitation (M7)."),
    ("Synthesis & Interpretation (P6)", 26, "Value-Based Framework (M8) and its derivation from the evidence."),
    ("Synthesis & Interpretation (P6)", 27, "Research agenda from M5/M6."),
    ("Transparency (P7)", 28, "Open data: matrices and Stream Log as supplementary files."),
    ("Transparency (P7)", 29, "AI-use statement (tools, tasks, verification)."),
    ("Transparency (P7)", 30, "Limitations of the review (stream coverage, language, metrics bias) and update plan."),
]

# sheet names
S0, S1, S3, S4, S5, S6 = ("Start Here", "T1 Review Canvas", "T3 Stream Log", "T4 6R Quality Gate",
                          "T5 CCD Portfolio", "T6 Master Table")
SM = {1: "M1 General", 2: "M2 Methodology", 3: "M3 Contribution", 4: "M4 Keyword Coverage",
      5: "M5 Research Questions", 6: "M6 Open Issues", 7: "M7 Interpretation", 8: "M8 Value Framework"}
S15, S16, S17, SL = "T15 Triangulation", "T16 Indices Dashboard", "T17 Reporting Checklist", "Lists"
SP = "PRISMA 2020 Checklist"
PRISMA_ITEMS = [  # PRISMA 2020 (Page et al., BMJ 2021;372:n71): section, item, checklist item
    ("TITLE", "Title", "1", "Identify the report as a systematic review."),
    ("ABSTRACT", "Abstract", "2", "See the PRISMA 2020 for Abstracts checklist."),
    ("INTRODUCTION", "Rationale", "3", "Describe the rationale for the review in the context of existing knowledge."),
    ("INTRODUCTION", "Objectives", "4", "Provide an explicit statement of the objective(s) or question(s) the review addresses."),
    ("METHODS", "Eligibility criteria", "5", "Specify the inclusion and exclusion criteria for the review and how studies were grouped for the syntheses."),
    ("METHODS", "Information sources", "6", "Specify all databases, registers, websites, organisations, reference lists and other sources searched or consulted to identify studies. Specify the date when each source was last searched or consulted."),
    ("METHODS", "Search strategy", "7", "Present the full search strategies for all databases, registers and websites, including any filters and limits used."),
    ("METHODS", "Selection process", "8", "Specify the methods used to decide whether a study met the inclusion criteria of the review, including how many reviewers screened each record and each report retrieved, whether they worked independently, and if applicable, details of automation tools used in the process."),
    ("METHODS", "Data collection process", "9", "Specify the methods used to collect data from reports, including how many reviewers collected data from each report, whether they worked independently, any processes for obtaining or confirming data from study investigators, and if applicable, details of automation tools used in the process."),
    ("METHODS", "Data items", "10a", "List and define all outcomes for which data were sought. Specify whether all results that were compatible with each outcome domain in each study were sought (e.g. for all measures, time points, analyses), and if not, the methods used to decide which results to collect."),
    ("METHODS", "Data items", "10b", "List and define all other variables for which data were sought (e.g. participant and intervention characteristics, funding sources). Describe any assumptions made about any missing or unclear information."),
    ("METHODS", "Study risk of bias assessment", "11", "Specify the methods used to assess risk of bias in the included studies, including details of the tool(s) used, how many reviewers assessed each study and whether they worked independently, and if applicable, details of automation tools used in the process."),
    ("METHODS", "Effect measures", "12", "Specify for each outcome the effect measure(s) (e.g. risk ratio, mean difference) used in the synthesis or presentation of results."),
    ("METHODS", "Synthesis methods", "13a", "Describe the processes used to decide which studies were eligible for each synthesis (e.g. tabulating the study intervention characteristics and comparing against the planned groups for each synthesis (item #5))."),
    ("METHODS", "Synthesis methods", "13b", "Describe any methods required to prepare the data for presentation or synthesis, such as handling of missing summary statistics, or data conversions."),
    ("METHODS", "Synthesis methods", "13c", "Describe any methods used to tabulate or visually display results of individual studies and syntheses."),
    ("METHODS", "Synthesis methods", "13d", "Describe any methods used to synthesize results and provide a rationale for the choice(s). If meta-analysis was performed, describe the model(s), method(s) to identify the presence and extent of statistical heterogeneity, and software package(s) used."),
    ("METHODS", "Synthesis methods", "13e", "Describe any methods used to explore possible causes of heterogeneity among study results (e.g. subgroup analysis, meta-regression)."),
    ("METHODS", "Synthesis methods", "13f", "Describe any sensitivity analyses conducted to assess robustness of the synthesized results."),
    ("METHODS", "Reporting bias assessment", "14", "Describe any methods used to assess risk of bias due to missing results in a synthesis (arising from reporting biases)."),
    ("METHODS", "Certainty assessment", "15", "Describe any methods used to assess certainty (or confidence) in the body of evidence for an outcome."),
    ("RESULTS", "Study selection", "16a", "Describe the results of the search and selection process, from the number of records identified in the search to the number of studies included in the review, ideally using a flow diagram."),
    ("RESULTS", "Study selection", "16b", "Cite studies that might appear to meet the inclusion criteria, but which were excluded, and explain why they were excluded."),
    ("RESULTS", "Study characteristics", "17", "Cite each included study and present its characteristics."),
    ("RESULTS", "Risk of bias in studies", "18", "Present assessments of risk of bias for each included study."),
    ("RESULTS", "Results of individual studies", "19", "For all outcomes, present, for each study: (a) summary statistics for each group (where appropriate) and (b) an effect estimate and its precision (e.g. confidence/credible interval), ideally using structured tables or plots."),
    ("RESULTS", "Results of syntheses", "20a", "For each synthesis, briefly summarise the characteristics and risk of bias among contributing studies."),
    ("RESULTS", "Results of syntheses", "20b", "Present results of all statistical syntheses conducted. If meta-analysis was done, present for each the summary estimate and its precision (e.g. confidence/credible interval) and measures of statistical heterogeneity. If comparing groups, describe the direction of the effect."),
    ("RESULTS", "Results of syntheses", "20c", "Present results of all investigations of possible causes of heterogeneity among study results."),
    ("RESULTS", "Results of syntheses", "20d", "Present results of all sensitivity analyses conducted to assess the robustness of the synthesized results."),
    ("RESULTS", "Reporting biases", "21", "Present assessments of risk of bias due to missing results (arising from reporting biases) for each synthesis assessed."),
    ("RESULTS", "Certainty of evidence", "22", "Present assessments of certainty (or confidence) in the body of evidence for each outcome assessed."),
    ("DISCUSSION", "Discussion", "23a", "Provide a general interpretation of the results in the context of other evidence."),
    ("DISCUSSION", "Discussion", "23b", "Discuss any limitations of the evidence included in the review."),
    ("DISCUSSION", "Discussion", "23c", "Discuss any limitations of the review processes used."),
    ("DISCUSSION", "Discussion", "23d", "Discuss implications for practice, policy, and future research."),
    ("OTHER INFORMATION", "Registration and protocol", "24a", "Provide registration information for the review, including register name and registration number, or state that the review was not registered."),
    ("OTHER INFORMATION", "Registration and protocol", "24b", "Indicate where the review protocol can be accessed, or state that a protocol was not prepared."),
    ("OTHER INFORMATION", "Registration and protocol", "24c", "Describe and explain any amendments to information provided at registration or in the protocol."),
    ("OTHER INFORMATION", "Support", "25", "Describe sources of financial or non-financial support for the review, and the role of the funders or sponsors in the review."),
    ("OTHER INFORMATION", "Competing interests", "26", "Declare any competing interests of review authors."),
    ("OTHER INFORMATION", "Availability of data, code and other materials", "27", "Report which of the following are publicly available and where they can be found: template data collection forms; data extracted from included studies; data used for all analyses; analytic code; any other materials used in the review."),
]


def q(s):
    return "'" + s + "'"


HDR = 4          # header row on data sheets
R0 = 5           # first data row
NM = 60          # master rows (adapted review: core target 50–60)
MR1, MRN = R0, R0 + NM - 1          # 5..54
N4 = 100         # 6R rows (91 unique items)
G1, GN = R0, R0 + N4 - 1            # 5..104
SLAST = 4 + len(STREAMS)            # last stream row on the Lists sheet (AUT widens it to 18)
NLOG = 40
NKF = 15
KF1, KFN = R0, R0 + NKF - 1         # 5..19


# ----------------------------------------------------------------- helpers
def font(bold=False, color="000000", size=10, italic=False):
    return Font(name=FONT, bold=bold, color=color, size=size, italic=italic)


def title(ws, text, sub, width_cols=8):
    ws["A1"] = text
    ws["A1"].font = Font(name=FONT, bold=True, size=15, color=NAVY)
    ws["A2"] = sub
    ws["A2"].font = font(italic=True, color=SLATE, size=9)
    ws.row_dimensions[1].height = 24
    for c in range(1, width_cols + 1):
        ws.cell(row=1, column=c).fill = F_WHITE
    ws.cell(row=1, column=1).border = Border(bottom=Side(style="medium", color=TEAL))


def header(ws, row, col, text, kind="input", width=None):
    c = ws.cell(row=row, column=col, value=text)
    c.fill = F_NAVY if kind == "input" else F_TEAL
    c.font = font(bold=True, color="FFFFFF")
    c.alignment = CENTER
    c.border = BORDER
    if width:
        ws.column_dimensions[CL(col)].width = width
    return c


def section(ws, row, text, ncols):
    c = ws.cell(row=row, column=1, value=text)
    c.font = font(bold=True, color=NAVY, size=11)
    for i in range(1, ncols + 1):
        ws.cell(row=row, column=i).fill = F_SEC
    ws.row_dimensions[row].height = 18


def cell(ws, ref, value=None, inp=False, bold=False, fmt=None, align=None, color="000000", italic=False):
    c = ws[ref]
    if value is not None:
        c.value = value
    c.font = font(bold=bold, color=color, italic=italic)
    c.border = BORDER
    c.fill = F_IN if inp else F_WHITE
    c.alignment = align or WRAP
    if fmt:
        c.number_format = fmt
    return c


def grid(ws, r1, r2, c1, c2, inp=True, align=None, fmt=None):
    for r in range(r1, r2 + 1):
        for c in range(c1, c2 + 1):
            x = ws.cell(row=r, column=c)
            x.border = BORDER
            x.fill = F_IN if inp else F_WHITE
            x.font = font()
            x.alignment = align or WRAP
            if fmt:
                x.number_format = fmt


def hint(ws, row, col, text):
    c = ws.cell(row=row, column=col, value=text)
    c.font = font(italic=True, color=SLATE, size=8)
    c.alignment = WRAP


def dv_list(ws, name, rng, prompt=None):
    dv = DataValidation(type="list", formula1="=" + name, allow_blank=True, showDropDown=False)
    dv.error = "Please choose a value from the list (see the Lists sheet)."
    dv.errorTitle = "360° MDL"
    if prompt:
        dv.prompt = prompt
        dv.showInputMessage = True
    ws.add_data_validation(dv)
    dv.add(rng)
    return dv


def page_setup(ws, header_rows=None):
    ws.page_setup.orientation = "landscape"
    ws.page_setup.paperSize = ws.PAPERSIZE_A4
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.print_options.horizontalCentered = True
    ws.page_margins.left = ws.page_margins.right = 0.4
    ws.page_margins.top = 0.5
    ws.page_margins.bottom = 0.6
    ws.oddFooter.left.text = "&A"
    ws.oddFooter.left.size = 8
    ws.oddFooter.center.text = FOOTER
    ws.oddFooter.center.size = 8
    ws.oddFooter.right.text = "Page &P of &N"
    ws.oddFooter.right.size = 8
    ws.sheet_view.showGridLines = False
    if header_rows:
        ws.print_title_rows = header_rows


def widths(ws, d):
    for k, v in d.items():
        ws.column_dimensions[k].width = v


def status_cf(ws, rng):
    ws.conditional_formatting.add(rng, CellIsRule(operator="equal", formula=['"PASS"'], fill=F_PASS,
                                                  font=Font(name=FONT, bold=True, color="1B6E3A")))
    ws.conditional_formatting.add(rng, CellIsRule(operator="equal", formula=['"CHECK"'], fill=F_CHECK,
                                                  font=Font(name=FONT, bold=True, color=CORAL)))
    ws.conditional_formatting.add(rng, CellIsRule(operator="equal", formula=['"REPORT"'], fill=F_SEC,
                                                  font=Font(name=FONT, bold=True, color=SLATE)))


def link(sheet, col, row):
    ref = f"{q(sheet)}!{col}{row}"
    return f'=IF({ref}="","",{ref})'


# ----------------------------------------------------------------- build
def build(path, example=False):
    wb = Workbook()
    wb.remove(wb.active)
    names = [S0, S1, S3, S4, S5, S6] + [SM[i] for i in range(1, 9)] + [S15, S16, S17, SL]
    ws_ = {n: wb.create_sheet(n) for n in names}
    tabcol = {S0: NAVY, S1: NAVY, S3: "1F4E79", S4: "1F4E79", S5: "1F4E79", S6: TEAL, S15: CORAL, S16: AMBER,
              S17: AMBER, SL: SLATE}
    for n, w in ws_.items():
        w.sheet_properties.tabColor = tabcol.get(n, "2A9D8F")
    D = EX if example else None

    # ================================================================ Lists
    L = ws_[SL]
    title(L, "Lists – lookup tables (referenced by drop-downs and formulas)",
          "Edit with care: codes are defined by the 360° MDL v2026 specification. Named ranges point here.", 10)
    lists = {}

    def put_table(col, hdrs, rows, name_cols):
        """Write table starting row 4 at column index col; name_cols = {offset: defined_name}"""
        for j, h in enumerate(hdrs):
            header(L, 4, col + j, h, "input")
        for i, r in enumerate(rows):
            for j, v in enumerate(r if isinstance(r, (list, tuple)) else [r]):
                cell(L, f"{CL(col + j)}{5 + i}", v)
        for off, nm in name_cols.items():
            ref = f"{q(SL)}!${CL(col + off)}$5:${CL(col + off)}${4 + len(rows)}"
            wb.defined_names[nm] = DefinedName(nm, attr_text=ref)
            lists[nm] = (CL(col + off), 5, 4 + len(rows))

    put_table(1, ["Stream code", "Stream", "Approach", "Family"], STREAMS, {0: "StreamCodes", 3: "StreamFamilyOfCode"})
    put_table(6, ["Slice code", "Meaning"], SLICES, {0: "SliceCodes"})
    put_table(9, ["Family", "Name", "Streams"], FAMILIES, {0: "FamilyCodes"})
    for i, f in enumerate(FAMILIES):
        L.cell(row=5 + i, column=9).fill = PatternFill("solid", fgColor=FAM_COL[f[0]])
        L.cell(row=5 + i, column=9).font = font(bold=True, color="FFFFFF")
    put_table(13, ["Method family (9)"], METHODS, {0: "MethodFamilies"})
    put_table(15, ["Contribution type (CT1–CT8)"], CTS, {0: "ContribTypes"})
    put_table(17, ["Exploitation mode"], EXPLOIT, {0: "ExploitModes"})
    put_table(19, ["RQ family"], RQFAM, {0: "RQFamilies"})
    put_table(21, ["Tier"], TIERS, {0: "Tiers"})
    put_table(22, ["Mode"], MODES, {0: "Modes"})
    put_table(23, ["Y/N/NA"], YNNA, {0: "YNNA"})
    put_table(24, ["Y/N"], YN, {0: "YesNo"})
    put_table(25, ["Impact locus"], LOCUS, {0: "ImpactLocus"})
    put_table(26, ["VBF layer"], VBF, {0: "VBFLayers"})
    put_table(27, ["Contribution ref."], CREF, {0: "ContribRef"})
    put_table(28, ["Perspective"], PERSP, {0: "Perspectives"})
    put_table(29, ["Priority"], PRIO, {0: "Priorities"})
    put_table(30, ["RQ type"], RQTYPE, {0: "RQTypes"})
    put_table(31, ["Review RQ"], RQIDS, {0: "ReviewRQs"})
    put_table(32, ["Cluster"], KIDS, {0: "ClusterCodes"})
    put_table(33, ["Mark"], XMARK, {0: "XMark"})
    # tier parameter table at row 22 (below), columns A..N
    TP_ROW = 22
    section(L, TP_ROW - 1, "Tier parameters (spec §3–§5, §7). “—” = no target defined by the spec for that tier.", 14)
    for j, h in enumerate(TIER_PARAMS_HDR):
        header(L, TP_ROW, 1 + j, h, "input")
    for i, r in enumerate(TIER_PARAMS):
        for j, v in enumerate(r):
            cell(L, f"{CL(1 + j)}{TP_ROW + 1 + i}", v,
                 fmt="0%" if j == 4 else ("0.00" if isinstance(v, float) else None), align=CENTER)
    tp_first, tp_last = TP_ROW + 1, TP_ROW + 3
    wb.defined_names["TierTable"] = DefinedName("TierTable", attr_text=f"{q(SL)}!$A${tp_first}:$N${tp_last}")
    wb.defined_names["TierNames"] = DefinedName("TierNames", attr_text=f"{q(SL)}!$A${tp_first}:$A${tp_last}")
    L.cell(row=TP_ROW + 5, column=1, value=(
        "Notes: Lite has no index targets in the spec (indices reported only). F5 quota: Gate 3 rule (≥10%) applied to "
        "Lite and Standard; Approach C quota ≥15% for Advanced. CCD coverage threshold: Lite ≥2, otherwise ≥3. "
        "Advanced core corpus = “50 core” (checked here as 40–50, ≤50 cap)."))
    L.cell(row=TP_ROW + 5, column=1).font = font(italic=True, color=SLATE, size=9)
    widths(L, {"A": 13, "B": 44, "C": 16, "D": 9, "E": 2, "F": 10, "G": 48, "H": 2, "I": 9, "J": 28, "K": 14,
               "L": 2, "M": 24, "N": 2, "O": 30, "P": 2, "Q": 20, "R": 2, "S": 20, "T": 2})
    for c in range(21, 34):
        L.column_dimensions[CL(c)].width = 12
    L.freeze_panes = "A5"
    page_setup(L)

    def tparam(colname):
        j = TIER_PARAMS_HDR.index(colname) + 1
        return f"INDEX(TierTable,MATCH(ActiveTier,TierNames,0),{j})"

    # ================================================================ Start Here
    S = ws_[S0]
    S["A1"] = "360° MDL v2026 — Operational Toolkit"
    S["A1"].font = Font(name=FONT, bold=True, size=22, color=NAVY)
    S["A2"] = "The Multidimensional Literature Review Model (Lytras) · “From volume to value.”"
    S["A2"].font = Font(name=FONT, size=12, color=TEAL, bold=True)
    S["A3"] = ("A multi-stream, multidimensional and resilient literature review methodology. Templates T1, T3–T17 of the "
               "360° MDL v2026 specification (§11).")
    S["A3"].font = font(italic=True, color=SLATE)
    r = 4
    if example:
        S["A4"] = D.BANNER
        S["A4"].font = Font(name=FONT, bold=True, size=11, color="FFFFFF")
        S["A4"].alignment = WRAP
        S.merge_cells("A4:E4")
        S.row_dimensions[4].height = 34
        for c in range(1, 6):
            S.cell(row=4, column=c).fill = PatternFill("solid", fgColor=CORAL)
        S["A5"] = D.BANNER_NOTE
        S["A5"].font = font(italic=True, color=CORAL)
        S["A5"].alignment = WRAP
        S.merge_cells("A5:E5")
        S.row_dimensions[5].height = 70
        r = 6
    r += 1
    section(S, r, "Active tier (drives all targets and portfolio rules)", 5)
    r += 1
    cell(S, f"A{r}", "Tier selector ►", bold=True)
    cell(S, f"B{r}", "Standard", inp=True, bold=True, align=CENTER)
    S[f"B{r}"].font = Font(name=FONT, bold=True, size=12, color=NAVY)
    dv_list(S, "Tiers", f"B{r}", "Choose Lite / Standard / Advanced")
    wb.defined_names["ActiveTier"] = DefinedName("ActiveTier", attr_text=f"{q(S0)}!$B${r}")
    tier_row = r
    cell(S, f"C{r}", "=\"Core corpus \"&" + tparam("Core min") + "&\"–\"&" + tparam("Core max") +
         "&\" · ≥\"&" + tparam("Min streams") + "&\" streams · ≥\"&" + tparam("Min matrices") + "&\" matrices\"",
         italic=True, color=SLATE)
    S.merge_cells(f"C{r}:E{r}")
    r += 2
    section(S, r, "How to use (the 7-phase 360° MDL cycle)", 5)
    steps = [
        ("P1 FRAME", S1, "Select the tier above, then complete the Review Canvas: purpose, RQs, scope, tier & mode, streams, "
                         "keyword clusters K1–K10, eligibility, matrices, team. Register the protocol (Standard: recommended; "
                         "Advanced: mandatory). The protocol text (T2) is a separate document template."),
        ("P2 SOURCE", S3, "Log every query per stream: date, string, filters, hits, exported. Family is looked up from the stream code."),
        ("P3 SELECT", S4, "Gate 1: deduplicate; enter # streams each item was found in (≥2 → Convergence Flag). Gate 2: score "
                          "R1–R6 (0–2). Decision is automatic: R1≥1 AND R2≥1 AND Total≥7 → Pass; Total 5–6 → Reserve; else Exclude."),
        ("P3 Gate 3 CCD", S5, "Copy the IDs of the Pass items you curate into the core corpus (≤50) to T6 Master Table; T5 checks "
                              "Complementarity/Coverage/Diversity rules live (PASS/CHECK)."),
        ("P4 CODIFY", S6, "Complete the Master Table (ID scheme [STREAM]-[SLICE]-[NN]). Stream family is pre-filled from the ID "
                          "and can be overridden from the drop-down. 6R results are linked automatically."),
        ("P5 ANALYSE", "M1–M6", "Matrices M1–M6 list the core items automatically; fill the light-grey cells. M4: put “x” for each "
                                "cluster (≤8 per item) — heatmap, gap maps and CovI update live."),
        ("P6 SYNTHESISE", "M7, M8, T15", "Interpret (M7), build the Value-Based Framework canvas (M8), and record which stream "
                                         "families support each key finding (T15): TS, class, RI and LOSO are computed."),
        ("P7 REPORT", "T16, T17", "Read the Indices Dashboard against the tier targets and complete the MDL-RC 2026 checklist. "
                                  "Publish matrices and Stream Log as open data (CC BY); include an AI-use statement."),
    ]
    r += 1
    for j, h in enumerate(["Phase", "Sheet(s)", "What to do"]):
        header(S, r, 1 + j, h)
    S.merge_cells(start_row=r, start_column=3, end_row=r, end_column=5)
    for ph, sh, tx in steps:
        r += 1
        cell(S, f"A{r}", ph, bold=True, color=NAVY)
        cell(S, f"B{r}", sh, color=TEAL, bold=True)
        cell(S, f"C{r}", tx)
        S.merge_cells(f"C{r}:E{r}")
        S.row_dimensions[r].height = 44
    r += 1
    cell(S, f"A{r}", "Responsible AI", bold=True, color=CORAL)
    cell(S, f"B{r}", "Two-Key Rule", bold=True, color=CORAL)
    cell(S, f"C{r}", "Every AI-produced cell is verified by a human against the source text; never cite an item not retrieved "
                     "and read by a human; log tools/versions/prompts; AI cannot assign 6R scores without human confirmation.")
    S.merge_cells(f"C{r}:E{r}")
    S.row_dimensions[r].height = 32
    r += 2
    section(S, r, "Sheet map", 5)
    r += 1
    for j, h in enumerate(["Sheet", "Template", "Phase / layer", "Purpose"]):
        header(S, r, 1 + j, h)
    S.merge_cells(start_row=r, start_column=4, end_row=r, end_column=5)
    smap = [
        (S1, "T1 360° Review Canvas", "P1 Frame", "Fill-in canvas & protocol essentials"),
        (S3, "T3 Stream Log", "P2 Source", "Auditable log of every query per stream"),
        (S4, "T4 Screening & 6R Quality Gate", "P3 Select (Gates 1–2)", "6R scoring, automatic decision, convergence flag, AACODS"),
        (S5, "T5 CCD Portfolio check", "P3 Select (Gate 3)", "Live counts per stream family, method, CT, cluster; portfolio rules"),
        (S6, "T6 Master Table", "P4 Codify", "One row per core item; all P4 fields; 6R linked"),
        (SM[1], "T7 M1 General Matrix", "P5 Descriptive", "Compact overview per item"),
        (SM[2], "T8 M2 Methodology Matrix", "P5 Descriptive", "Method family, data, sample, technique"),
        (SM[3], "T9 M3 Contribution & Impact", "P5 Evaluative", "CT1–CT8 taxonomy and impact locus"),
        (SM[4], "T10 M4 Keyword Coverage", "P5 Descriptive", "Papers × K1–K10 heatmap, gap maps, CovI"),
        (SM[5], "T11 M5 RQ Matrix", "P5 Prospective", "Explicit/implicit RQs grouped in RQ families"),
        (SM[6], "T12 M6 Open Issues Matrix", "P5 Prospective", "Future research & limitations → research agenda"),
        (SM[7], "T13 M7 Interpretation & Exploitation", "P6 Interpretive", "Key interpretation and exploitation mode"),
        (SM[8], "T14 M8 Value-Based Framework canvas", "P6 Generative", "Enablers → … → Measures × stakeholders"),
        (S15, "T15 Triangulation & Resilience", "P6 Synthesis", "KF × stream families; TS, RI, LOSO"),
        (S16, "T16 Indices Dashboard", "P7 Report", "SBI, CovI, MDI, RI, LOSO, Convergence Rate vs tier targets"),
        (S17, "T17 Reporting Checklist MDL-RC 2026", "P7 Report", "30 items with completion %"),
        (SL, "—", "Support", "Lookup lists, codes and tier parameters"),
    ] + ([(SP, "PRISMA 2020 checklist (Table S1)", "Reporting", "27 PRISMA 2020 items with manuscript location and status")]
         if example and getattr(D, "PRISMA", None) else [])
    for sh, tp, ph, pu in smap:
        r += 1
        c = cell(S, f"A{r}", sh, bold=True, color=TEAL)
        c.hyperlink = f"#'{sh}'!A1"
        cell(S, f"B{r}", tp)
        cell(S, f"C{r}", ph)
        cell(S, f"D{r}", pu)
        S.merge_cells(f"D{r}:E{r}")
    r += 1
    cell(S, f"A{r}", "Not in workbook", italic=True, color=SLATE)
    cell(S, f"B{r}", "T2 Protocol template; T18 Flow diagram", italic=True, color=SLATE)
    cell(S, f"C{r}", "P1 / P3", italic=True, color=SLATE)
    cell(S, f"D{r}", "Document/figure templates (gate counts for T18 are provided in T5 section A).", italic=True, color=SLATE)
    S.merge_cells(f"D{r}:E{r}")
    r += 2
    section(S, r, "Colour legend", 5)
    leg = [
        (F_NAVY, "Navy header", "Input column – you type or choose here", "FFFFFF"),
        (F_TEAL, "Teal header", "Automatic column – formula or link (do not overwrite)", "FFFFFF"),
        (F_IN, "Light-grey cell", "Input cell (drop-downs where available)", "000000"),
        (F_WHITE, "White cell", "Formula / linked value", "000000"),
        (F_PASS, "PASS / Pass", "Rule or target met; 6R decision Pass", "1B6E3A"),
        (F_AMB, "Reserve / warning", "Extended Evidence Pool; missing AACODS note; >8 clusters", "000000"),
        (F_CHECK, "CHECK / Exclude", "Rule or target not met; 6R decision Exclude", CORAL),
    ]
    for fill, a, b, fc in leg:
        r += 1
        c = cell(S, f"A{r}", a, bold=True)
        c.fill = fill
        c.font = font(bold=True, color=fc)
        cell(S, f"B{r}", b)
        S.merge_cells(f"B{r}:E{r}")
    r += 1
    cell(S, f"A{r}", "Stream families", bold=True)
    for i, f in enumerate(FAMILIES):
        c = S.cell(row=r, column=2 + i if i < 4 else 5)
    # family chips on separate rows for readability
    for f in FAMILIES:
        r += 1
        c = cell(S, f"A{r}", f[0], bold=True, align=CENTER)
        c.fill = PatternFill("solid", fgColor=FAM_COL[f[0]])
        c.font = font(bold=True, color="FFFFFF")
        cell(S, f"B{r}", f"{f[1]} ({f[2]})")
        S.merge_cells(f"B{r}:E{r}")
    r += 2
    section(S, r, "License & citation", 5)
    r += 1
    cell(S, f"A{r}", "License", bold=True)
    cell(S, f"B{r}", LICENSE)
    S.merge_cells(f"B{r}:E{r}")
    r += 1
    cell(S, f"A{r}", "Suggested citation", bold=True)
    cell(S, f"B{r}", CITATION)
    S.merge_cells(f"B{r}:E{r}")
    S.row_dimensions[r].height = 30
    r += 1
    cell(S, f"A{r}", "Originator", bold=True)
    cell(S, f"B{r}", "Prof. Miltiadis D. Lytras (The American College of Greece). “MDL” = MultiDimensional Literature review "
                     "model; it also echoes the originator's initials (M.D.L.).")
    S.merge_cells(f"B{r}:E{r}")
    widths(S, {"A": 22, "B": 34, "C": 30, "D": 40, "E": 40})
    page_setup(S)
    S.page_setup.orientation = "portrait"

    # ================================================================ T1 Review Canvas
    T1 = ws_[S1]
    title(T1, "T1 · 360° Review Canvas (P1 FRAME)",
          "Fill the light-grey cells. One canvas per review. Register the protocol (OSF Registries or Zenodo).", 6)
    widths(T1, {"A": 24, "B": 46, "C": 36, "D": 22, "E": 30, "F": 30})
    d1 = D.CANVAS if example else {}
    r = 4
    section(T1, r, "1. Purpose & knowledge problem", 6)
    for lab, key in [("Review title", "title"), ("Purpose", "purpose"), ("Rationale / knowledge problem", "rationale")]:
        r += 1
        cell(T1, f"A{r}", lab, bold=True)
        cell(T1, f"B{r}", d1.get(key), inp=True)
        T1.merge_cells(f"B{r}:F{r}")
        T1.row_dimensions[r].height = 30
    r += 2
    section(T1, r, "2. Review questions (RQ1–RQn)", 6)
    r += 1
    header(T1, r, 1, "RQ")
    header(T1, r, 2, "Review question")
    T1.merge_cells(start_row=r, start_column=2, end_row=r, end_column=4)
    header(T1, r, 5, "RQ family")
    header(T1, r, 6, "Matrices / clusters addressed")
    rq_first = r + 1
    for i in range(6):
        r += 1
        cell(T1, f"A{r}", f"RQ{i + 1}", bold=True, align=CENTER)
        rqd = d1.get("rqs", [])
        v = rqd[i] if i < len(rqd) else (None, None, None)
        cell(T1, f"B{r}", v[0], inp=True)
        T1.merge_cells(f"B{r}:D{r}")
        cell(T1, f"E{r}", v[1], inp=True)
        cell(T1, f"F{r}", v[2], inp=True)
    dv_list(T1, "RQFamilies", f"E{rq_first}:E{r}")
    r += 2
    section(T1, r, "3. Scope", 6)
    for lab, key in [("Time window", "window"), ("Languages", "languages"), ("Disciplines", "disciplines"),
                     ("Document types", "doctypes")]:
        r += 1
        cell(T1, f"A{r}", lab, bold=True)
        cell(T1, f"B{r}", d1.get(key), inp=True)
        T1.merge_cells(f"B{r}:F{r}")
    r += 2
    section(T1, r, "4. Configuration", 6)
    r += 1
    cell(T1, f"A{r}", "Tier", bold=True)
    cell(T1, f"B{r}", d1.get("tier", "Standard"), inp=True, bold=True)
    dv_list(T1, "Tiers", f"B{r}", "Lite / Standard / Advanced")
    cell(T1, f"C{r}", f'=IF(B{r}="","",IF(B{r}=ActiveTier,"✓ matches Start Here tier selector",'
                      f'"⚠ differs from Start Here tier selector ("&ActiveTier&")"))', italic=True, color=SLATE)
    T1.merge_cells(f"C{r}:F{r}")
    T1.conditional_formatting.add(f"C{r}", FormulaRule(formula=[f'LEFT(C{r},1)="⚠"'], fill=F_CHECK))
    r += 1
    cell(T1, f"A{r}", "Mode", bold=True)
    cell(T1, f"B{r}", d1.get("mode"), inp=True, bold=True)
    dv_list(T1, "Modes", f"B{r}", "H = A + C-minimum · I = B + C-minimum · 360 = A + B + C (required for Advanced)")
    cell(T1, f"C{r}", f'=IF(B{r}="H","Holistic: A + C-minimum",IF(B{r}="I","Influencer: B + C-minimum",'
                      f'IF(B{r}="360","Full: A + B + C","")))', italic=True, color=SLATE)
    T1.merge_cells(f"C{r}:F{r}")
    for lab, key in [("Protocol registry & ID", "registry"), ("Calibration plan (κ ≥ 0.70)", "calibration"),
                     ("Living-update plan", "update"), ("Adaptations & notes (documented)", "adaptation")]:
        r += 1
        cell(T1, f"A{r}", lab, bold=True)
        cell(T1, f"B{r}", d1.get(key), inp=True)
        T1.merge_cells(f"B{r}:F{r}")
        if key == "adaptation" and d1.get(key):
            T1.row_dimensions[r].height = 120
    r += 2
    section(T1, r, "5. Streams & slices chosen (≥3 streams; Standard ≥4 incl. ≥1 grey; Advanced A+B+C ≥6)", 6)
    r += 1
    for j, (h, k) in enumerate([("Code", "auto"), ("Stream", "auto"), ("Family", "auto"), ("Use? (Y/N)", "input"),
                                ("Slices planned", "input"), ("Rationale / planned quota", "input")]):
        header(T1, r, 1 + j, h, k)
    st_first = r + 1
    use = d1.get("streams", {})
    for i, s in enumerate(STREAMS):
        r += 1
        lr = 5 + i
        cell(T1, f"A{r}", f"={q(SL)}!A{lr}", bold=True, align=CENTER)
        cell(T1, f"B{r}", f"={q(SL)}!B{lr}")
        cell(T1, f"C{r}", f"={q(SL)}!D{lr}", align=CENTER)
        u = use.get(s[0], (None, None, None))
        cell(T1, f"D{r}", u[0], inp=True, align=CENTER)
        cell(T1, f"E{r}", u[1], inp=True)
        cell(T1, f"F{r}", u[2], inp=True)
    st_last = r
    dv_list(T1, "YesNo", f"D{st_first}:D{st_last}")
    r += 1
    cell(T1, f"A{r}", "Streams planned", bold=True)
    cell(T1, f"B{r}", f'=COUNTIF(D{st_first}:D{st_last},"Y")&" streams · "&SUMPRODUCT((D{st_first}:D{st_last}="Y")'
                      f'*(MATCH(C{st_first}:C{st_last},C{st_first}:C{st_last},0)=ROW(C{st_first}:C{st_last})-{st_first - 1}))'
                      f'&" families (distinct, among selected streams: see T5 for actual)"', italic=True)
    # simpler, robust family count for planned streams
    T1[f"B{r}"] = (f'=COUNTIF(D{st_first}:D{st_last},"Y")&" streams planned · families: "'
                   + "".join([f'&IF(COUNTIFS(C{st_first}:C{st_last},"{f[0]}",D{st_first}:D{st_last},"Y")>0,"{f[0]} ","")'
                              for f in FAMILIES]))
    T1.merge_cells(f"B{r}:F{r}")
    r += 2
    section(T1, r, "6. Keyword universe – clusters K1–K10 (≤10 clusters; unify synonyms)", 6)
    r += 1
    header(T1, r, 1, "Cluster")
    header(T1, r, 2, "Cluster name")
    header(T1, r, 3, "Unified keywords / synonyms")
    T1.merge_cells(start_row=r, start_column=3, end_row=r, end_column=6)
    k_first = r + 1
    kd = d1.get("clusters", [])
    for i in range(10):
        r += 1
        cell(T1, f"A{r}", f"K{i + 1}", bold=True, align=CENTER)
        v = kd[i] if i < len(kd) else (None, None)
        cell(T1, f"B{r}", v[0], inp=True, bold=True)
        cell(T1, f"C{r}", v[1], inp=True)
        T1.merge_cells(f"C{r}:F{r}")
    k_last = r
    wb.defined_names["ClusterNames"] = DefinedName("ClusterNames", attr_text=f"{q(S1)}!$B${k_first}:$B${k_last}")
    r += 2
    section(T1, r, "7. Eligibility criteria (Gate 1)", 6)
    r += 1
    header(T1, r, 1, "Code")
    header(T1, r, 2, "Inclusion criterion")
    header(T1, r, 3, "Code")
    header(T1, r, 4, "Exclusion criterion")
    T1.merge_cells(start_row=r, start_column=4, end_row=r, end_column=6)
    ic, ec = d1.get("inclusion", []), d1.get("exclusion", [])
    for i in range(5):
        r += 1
        cell(T1, f"A{r}", f"IC{i + 1}", bold=True, align=CENTER)
        cell(T1, f"B{r}", ic[i] if i < len(ic) else None, inp=True)
        cell(T1, f"C{r}", f"EC{i + 1}", bold=True, align=CENTER)
        cell(T1, f"D{r}", ec[i] if i < len(ec) else None, inp=True)
        T1.merge_cells(f"D{r}:F{r}")
    r += 2
    section(T1, r, "8. Analysis matrices (3×3 Rule: ≥3 streams × ≥3 matrices; Standard M1–M6; Advanced M1–M8)", 6)
    r += 1
    for j, (h, k) in enumerate([("Matrix", "auto"), ("Name", "auto"), ("Use? (Y/N)", "input"), ("Required for tier", "auto"),
                                ("Coding rules / notes", "input")]):
        header(T1, r, 1 + j, h, k)
    T1.merge_cells(start_row=r, start_column=5, end_row=r, end_column=6)
    m_first = r + 1
    mu = d1.get("matrices", {})
    for i, (mc, mn) in enumerate(MATRICES):
        r += 1
        cell(T1, f"A{r}", mc, bold=True, align=CENTER)
        cell(T1, f"B{r}", mn)
        cell(T1, f"C{r}", mu.get(mc, (None, None))[0], inp=True, align=CENTER)
        req = {"Lite": "M1, M4 + one of M2/M3/M6"}
        if mc in ("M1", "M4"):
            f = '="Yes (all tiers)"'
        elif mc in ("M2", "M3", "M6"):
            f = '=IF(ActiveTier="Lite","Lite: one of M2/M3/M6","Yes")'
        elif mc == "M5":
            f = '=IF(ActiveTier="Lite","Optional","Yes")'
        else:
            f = '=IF(ActiveTier="Advanced","Yes","Optional")'
        cell(T1, f"D{r}", f, align=CENTER, italic=True)
        cell(T1, f"E{r}", mu.get(mc, (None, None))[1], inp=True)
        T1.merge_cells(f"E{r}:F{r}")
    m_last = r
    dv_list(T1, "YesNo", f"C{m_first}:C{m_last}")
    r += 1
    cell(T1, f"A{r}", "Matrices used", bold=True)
    cell(T1, f"B{r}", f'=COUNTIF(C{m_first}:C{m_last},"Y")', bold=True, align=CENTER)
    mat_used_ref = f"{q(S1)}!$B${r}"
    r += 2
    section(T1, r, "9. Team & roles (Lite: researcher + supervisor; Standard: lead + second coder 20%; Advanced: ≥3, double coding)", 6)
    r += 1
    for j, h in enumerate(["Name", "Role", "Responsibilities", "Phases", "Contact / ORCID", "Calibration duty"]):
        header(T1, r, 1 + j, h)
    td = d1.get("team", [])
    for i in range(5):
        r += 1
        v = td[i] if i < len(td) else [None] * 6
        for j in range(6):
            cell(T1, f"{CL(1 + j)}{r}", v[j], inp=True)
    r += 2
    section(T1, r, "10. Responsible AI plan (Two-Key Rule)", 6)
    r += 1
    for j, h in enumerate(["Tool / version", "Task (permitted with disclosure)", "Human verification", "Prompt log location"]):
        header(T1, r, 1 + j, h)
    T1.merge_cells(start_row=r, start_column=4, end_row=r, end_column=6)
    ad = d1.get("ai", [])
    for i in range(4):
        r += 1
        v = ad[i] if i < len(ad) else [None] * 4
        for j in range(4):
            cell(T1, f"{CL(1 + j)}{r}", v[j], inp=True)
        T1.merge_cells(f"D{r}:F{r}")
    T1.freeze_panes = "A4"
    page_setup(T1)
    T1.page_setup.orientation = "portrait"

    # ================================================================ T3 Stream Log
    T3 = ws_[S3]
    title(T3, "T3 · Stream Log (P2 SOURCE)", "Log every query: stream, date, string, filters, hits, exported. "
                                             "Stream name and family are looked up from the stream code.", 12)
    cols3 = [("Log #", 7, "auto"), ("Stream code", 10, "input"), ("Stream", 30, "auto"), ("Family", 8, "auto"),
             ("Slice", 8, "input"), ("Database / source", 22, "input"), ("Date of search", 12, "input"),
             ("Search string", 50, "input"), ("Filters (years, type, language, field)", 30, "input"),
             ("Hits", 9, "input"), ("Exported", 9, "input"), ("Notes", 30, "input")]
    for j, (h, w, k) in enumerate(cols3):
        header(T3, HDR, 1 + j, h, k, w)
    for j, t in enumerate(["", "e.g. WOS", "", "", "IMP", "Web of Science Core Collection", "2026-03-02",
                           'TS=("smart cit*" AND governance)', "2010–2026; articles; English", "1240", "25", ""]):
        if t:
            hint(T3, 3, 1 + j, t)
    l1, ln = R0, R0 + NLOG - 1
    grid(T3, l1, ln, 1, 12, inp=True)
    logs = D.STREAMLOG if example else []
    for i in range(NLOG):
        rr = R0 + i
        cell(T3, f"A{rr}", f'=IF(B{rr}="","",ROW()-{R0 - 1})', align=CENTER)
        cell(T3, f"C{rr}", f'=IF(B{rr}="","",IFERROR(INDEX({q(SL)}!$B$5:$B${SLAST},MATCH(B{rr},StreamCodes,0)),"unknown code"))')
        cell(T3, f"D{rr}", f'=IF(B{rr}="","",IFERROR(INDEX(StreamFamilyOfCode,MATCH(B{rr},StreamCodes,0)),"?"))', align=CENTER)
        T3[f"G{rr}"].number_format = "yyyy-mm-dd"
        T3[f"J{rr}"].number_format = "#,##0"
        T3[f"K{rr}"].number_format = "#,##0"
        if i < len(logs):
            for col, v in zip("BEFGHIJKL", logs[i]):
                T3[f"{col}{rr}"].value = v
    dv_list(T3, "StreamCodes", f"B{l1}:B{ln}")
    dv_list(T3, "SliceCodes", f"E{l1}:E{ln}")
    rt = ln + 1
    cell(T3, f"H{rt}", "Totals", bold=True, align=Alignment(horizontal="right"))
    cell(T3, f"J{rt}", f"=SUM(J{l1}:J{ln})", bold=True, fmt="#,##0")
    cell(T3, f"K{rt}", f"=SUM(K{l1}:K{ln})", bold=True, fmt="#,##0")
    for f in FAMILIES:
        T3.conditional_formatting.add(f"D{l1}:D{ln}", CellIsRule(operator="equal", formula=[f'"{f[0]}"'],
                                      fill=PatternFill("solid", fgColor=FAM_COL[f[0]]), font=Font(color="FFFFFF", bold=True)))
    T3.freeze_panes = f"C{R0}"
    T3.auto_filter.ref = f"A{HDR}:L{ln}"
    page_setup(T3, f"{HDR}:{HDR}")

    # ================================================================ T4 6R Quality Gate
    T4 = ws_[S4]
    title(T4, "T4 · Screening & 6R Quality Gate (P3 SELECT – Gates 1–2)",
          "Score R1–R6 from 0 to 2. Decision: R1 ≥ 1 AND R2 ≥ 1 AND Total ≥ 7 → Pass; Total 5–6 → Reserve "
          "(Extended Evidence Pool); otherwise Exclude. Grey literature (F3/F4): rate R2 with AACODS (Tyndall, 2010).", 21)
    cols4 = [("#", 5, "auto"), ("ID [STREAM]-[SLICE]-[NN]", 15, "input"), ("Short title", 38, "input"),
             ("Stream code", 8, "auto"), ("Family", 7, "auto"), ("Slice", 7, "auto"), ("Grey lit.", 7, "auto"),
             ("R1 Relevance", 9, "input"), ("R2 Rigour", 9, "input"), ("R3 Reach", 9, "input"),
             ("R4 Recency", 9, "input"), ("R5 Richness", 9, "input"), ("R6 Represent-ativeness", 10, "input"),
             ("6R Total (0–12)", 9, "auto"), ("Decision", 11, "auto"), ("# streams found in", 9, "input"),
             ("Convergence flag (≥2)", 11, "auto"), ("Also found in (codes)", 14, "input"),
             ("AACODS note (grey literature)", 34, "input"), ("Corpus status", 13, "auto"), ("Reviewer / notes", 26, "input")]
    for j, (h, w, k) in enumerate(cols4):
        header(T4, HDR, 1 + j, h, k, w)
    T4.row_dimensions[HDR].height = 42
    for j, t in enumerate(["", "WOS-IMP-01", "Short title", "", "", "", "", "0–2", "0–2", "0–2", "0–2", "0–2", "0–2",
                           "", "", "1", "", "SCO; GSC", "Authority … Significance", "", ""]):
        if t:
            hint(T4, 3, 1 + j, t)
    grid(T4, G1, GN, 1, 21, inp=True)
    rows4 = D.GATE if example else []
    for i in range(N4):
        rr = R0 + i
        cell(T4, f"A{rr}", f'=IF(B{rr}="","",ROW()-{R0 - 1})', align=CENTER)
        cell(T4, f"D{rr}", f'=IF(B{rr}="","",LEFT(B{rr},3))', align=CENTER)
        cell(T4, f"E{rr}", f'=IF(B{rr}="","",IFERROR(INDEX(StreamFamilyOfCode,MATCH(D{rr},StreamCodes,0)),"?"))', align=CENTER)
        cell(T4, f"F{rr}", f'=IF(B{rr}="","",IFERROR(MID(B{rr},5,FIND("-",B{rr},5)-5),""))', align=CENTER)
        cell(T4, f"G{rr}", f'=IF(OR(E{rr}="F3",E{rr}="F4"),"Grey","")', align=CENTER)
        for c in "HIJKLMP":
            T4[f"{c}{rr}"].alignment = CENTER
        cell(T4, f"N{rr}", f'=IF(COUNT(H{rr}:M{rr})=0,"",SUM(H{rr}:M{rr}))', bold=True, align=CENTER)
        cell(T4, f"O{rr}", f'=IF(COUNT(H{rr}:M{rr})=0,"",IF(COUNT(H{rr}:M{rr})<6,"Incomplete",'
                           f'IF(AND(H{rr}>=1,I{rr}>=1,N{rr}>=7),"Pass",IF(AND(N{rr}>=5,N{rr}<=6),"Reserve","Exclude"))))',
             bold=True, align=CENTER)
        cell(T4, f"Q{rr}", f'=IF(P{rr}="","",IF(P{rr}>=2,"Yes","No"))', align=CENTER)
        cell(T4, f"T{rr}", f'=IF(B{rr}="","",IF(COUNTIF({q(S6)}!$B${MR1}:$B${MRN},B{rr})>0,"Core",'
                           f'IF(OR(O{rr}="Pass",O{rr}="Reserve"),"Extended pool","Out")))', align=CENTER)
        if i < len(rows4):
            g = rows4[i]
            T4[f"B{rr}"] = g["id"]
            T4[f"C{rr}"] = g["title"]
            for c, v in zip("HIJKLM", g["r"]):
                T4[f"{c}{rr}"] = v
            T4[f"P{rr}"] = g["found"]
            T4[f"R{rr}"] = g.get("also")
            T4[f"S{rr}"] = g.get("aacods")
            T4[f"U{rr}"] = g.get("note")
    dv = DataValidation(type="whole", operator="between", formula1="0", formula2="2", allow_blank=True)
    dv.error, dv.errorTitle = "6R scores must be 0, 1 or 2.", "360° MDL – 6R"
    dv.prompt, dv.showInputMessage = "0 = weak/absent · 1 = adequate · 2 = strong", True
    T4.add_data_validation(dv)
    dv.add(f"H{G1}:M{GN}")
    dvp = DataValidation(type="whole", operator="between", formula1="1", formula2="12", allow_blank=True)
    T4.add_data_validation(dvp)
    dvp.add(f"P{G1}:P{GN}")
    rngO = f"O{G1}:O{GN}"
    T4.conditional_formatting.add(rngO, CellIsRule(operator="equal", formula=['"Pass"'], fill=F_PASS, font=Font(bold=True, color="1B6E3A")))
    T4.conditional_formatting.add(rngO, CellIsRule(operator="equal", formula=['"Reserve"'], fill=F_AMB, font=Font(bold=True, color="8A5A12")))
    T4.conditional_formatting.add(rngO, CellIsRule(operator="equal", formula=['"Exclude"'], fill=F_CHECK, font=Font(bold=True, color=CORAL)))
    T4.conditional_formatting.add(f"N{G1}:N{GN}", ColorScaleRule(start_type="num", start_value=0, start_color="FBE3D6",
                                                                 mid_type="num", mid_value=6, mid_color="FFF4DC",
                                                                 end_type="num", end_value=12, end_color="9FD8C0"))
    T4.conditional_formatting.add(f"Q{G1}:Q{GN}", CellIsRule(operator="equal", formula=['"Yes"'],
                                                             fill=PatternFill("solid", fgColor="D6EEF1"), font=Font(bold=True, color=TEAL)))
    T4.conditional_formatting.add(f"S{G1}:S{GN}", FormulaRule(formula=[f'AND($G{G1}="Grey",$S{G1}="")'], fill=F_AMB))
    T4.conditional_formatting.add(f"B{G1}:B{GN}", FormulaRule(formula=[f'AND($B{G1}<>"",ISNA(MATCH(LEFT($B{G1},3),StreamCodes,0)))'],
                                                              fill=F_CHECK))
    T4.conditional_formatting.add(f"T{G1}:T{GN}", CellIsRule(operator="equal", formula=['"Core"'], fill=PatternFill("solid", fgColor="D6EEF1"),
                                                             font=Font(bold=True, color=NAVY)))
    for f in FAMILIES:
        T4.conditional_formatting.add(f"E{G1}:E{GN}", CellIsRule(operator="equal", formula=[f'"{f[0]}"'],
                                      fill=PatternFill("solid", fgColor=FAM_COL[f[0]]), font=Font(color="FFFFFF", bold=True)))
    T4.freeze_panes = f"D{R0}"
    T4.auto_filter.ref = f"A{HDR}:U{GN}"
    page_setup(T4, f"{HDR}:{HDR}")

    # ================================================================ T6 Master Table (before T5 since T5 refs it)
    T6 = ws_[S6]
    title(T6, "T6 · Master Table (P4 CODIFY)",
          "One row per core item (Standard ≤ 50; this adapted review: target 50–60, N = 56). Enter the ID exactly as in T4. Stream family is pre-filled from the ID "
          "(override via drop-down if needed); 6R results are linked from T4.", 28)
    cols6 = [("No", 5, "auto"), ("ID", 14, "input"), ("Short title", 34, "input"), ("Full citation", 44, "input"),
             ("Stream code", 8, "auto"), ("Slice", 7, "auto"), ("Stream family", 9, "auto"),
             ("Lead author / group", 16, "input"), ("Year", 7, "input"),
             ("Topics covered", 30, "input"), ("Focus / context", 18, "input"), ("Methodology", 28, "input"),
             ("Method family", 16, "input"), ("Key findings", 40, "input"), ("Analysis (themes)", 28, "input"),
             ("Type of contribution", 20, "input"), ("Contribution", 34, "input"), ("Significance", 12, "input"),
             ("Future research", 34, "input"), ("Limitations", 30, "input"), ("Research contribution", 30, "input"),
             ("Key interpretation", 34, "input"), ("Exploitation mode", 16, "input"),
             ("Value-Based Framework element", 14, "input"), ("6R scores R1-R2-R3-R4-R5-R6", 14, "auto"),
             ("6R Total", 7, "auto"), ("6R Decision", 10, "auto"), ("Convergence flag", 10, "auto")]
    for j, (h, w, k) in enumerate(cols6):
        header(T6, HDR, 1 + j, h, k, w)
    T6.row_dimensions[HDR].height = 42
    for j, t in enumerate(["", "WOS-IMP-01", "Short title", "Authors (Year). Title. Journal, vol, pages. DOI", "", "", "F1",
                           "Surname, I.", "2024", "codified themes; …", "context/region", "summary of method",
                           "drop-down (9)", "", "themes", "CT1–CT8", "", "High/Medium/Low", "", "", "", "",
                           "drop-down", "drop-down", "", "", "", ""]):
        if t:
            hint(T6, 3, 1 + j, t)
    grid(T6, MR1, MRN, 1, 28, inp=True)
    G4 = f"{q(S4)}!$B${G1}:$B${GN}"

    def g4(col, rr):
        return f"INDEX({q(S4)}!${col}${G1}:${col}${GN},MATCH($B{rr},{G4},0))"
    master = D.MASTER if example else []
    for i in range(NM):
        rr = R0 + i
        cell(T6, f"A{rr}", i + 1, align=CENTER)
        cell(T6, f"E{rr}", f'=IF(B{rr}="","",LEFT(B{rr},3))', align=CENTER)
        cell(T6, f"F{rr}", f'=IF(B{rr}="","",IFERROR(MID(B{rr},5,FIND("-",B{rr},5)-5),""))', align=CENTER)
        cell(T6, f"G{rr}", f'=IF(B{rr}="","",IFERROR(INDEX(StreamFamilyOfCode,MATCH(LEFT(B{rr},3),StreamCodes,0)),"?"))',
             align=CENTER)
        cell(T6, f"Y{rr}", f'=IF($B{rr}="","",IFERROR({g4("H", rr)}&"-"&{g4("I", rr)}&"-"&{g4("J", rr)}&"-"&{g4("K", rr)}'
                           f'&"-"&{g4("L", rr)}&"-"&{g4("M", rr)},"not in T4"))', align=CENTER)
        cell(T6, f"Z{rr}", f'=IF($B{rr}="","",IFERROR({g4("N", rr)},""))', align=CENTER, bold=True)
        cell(T6, f"AA{rr}", f'=IF($B{rr}="","",IFERROR({g4("O", rr)},"not in T4"))', align=CENTER, bold=True)
        cell(T6, f"AB{rr}", f'=IF($B{rr}="","",IFERROR(IF({g4("Q", rr)}="","",{g4("Q", rr)}),""))', align=CENTER)
        if i < len(master):
            m = master[i]
            for col, key in [("B", "id"), ("C", "title"), ("D", "citation"), ("H", "group"), ("I", "year"),
                             ("J", "topics"), ("K", "focus"), ("L", "methodology"), ("M", "method"), ("N", "findings"),
                             ("O", "analysis"), ("P", "ct"), ("Q", "contribution"), ("R", "significance"),
                             ("S", "future"), ("T", "limitations"), ("U", "rescontrib"), ("V", "interpretation"),
                             ("W", "exploit"), ("X", "vbf")]:
                v = m.get(key)
                if v not in (None, ""):
                    T6[f"{col}{rr}"] = v
    dv_list(T6, "FamilyCodes", f"G{MR1}:G{MRN}", "Pre-filled from the ID; override only if justified")
    dv_list(T6, "MethodFamilies", f"M{MR1}:M{MRN}")
    dv_list(T6, "ContribTypes", f"P{MR1}:P{MRN}")
    dv_list(T6, "ExploitModes", f"W{MR1}:W{MRN}")
    dv_list(T6, "VBFLayers", f"X{MR1}:X{MRN}")
    for c in "EFGIMPRWXYZ":
        for rr in range(MR1, MRN + 1):
            T6[f"{c}{rr}"].alignment = CENTER
    for f in FAMILIES:
        T6.conditional_formatting.add(f"G{MR1}:G{MRN}", CellIsRule(operator="equal", formula=[f'"{f[0]}"'],
                                      fill=PatternFill("solid", fgColor=FAM_COL[f[0]]), font=Font(color="FFFFFF", bold=True)))
    T6.conditional_formatting.add(f"AA{MR1}:AA{MRN}", CellIsRule(operator="equal", formula=['"Pass"'], fill=F_PASS))
    T6.conditional_formatting.add(f"AA{MR1}:AA{MRN}", FormulaRule(formula=[f'AND($B{MR1}<>"",$AA{MR1}<>"Pass")'], fill=F_CHECK))
    T6.conditional_formatting.add(f"B{MR1}:B{MRN}", FormulaRule(formula=[f'AND($B{MR1}<>"",COUNTIF({G4},$B{MR1})=0)'], fill=F_AMB))
    T6.conditional_formatting.add(f"B{MR1}:B{MRN}", FormulaRule(formula=[f'AND($B{MR1}<>"",COUNTIF($B${MR1}:$B${MRN},$B{MR1})>1)'], fill=F_CHECK))
    T6.freeze_panes = f"D{R0}"
    T6.auto_filter.ref = f"A{HDR}:AB{MRN}"
    page_setup(T6, f"{HDR}:{HDR}")
    MT = q(S6)

    def mrng(col):
        return f"{MT}!${col}${MR1}:${col}${MRN}"

    # ================================================================ M4 (needed by T5)
    M4 = ws_[SM[4]]
    title(M4, "M4 · Topics/Keywords Coverage Matrix (T10)",
          "Put “x” for every keyword cluster an item covers (≤ 8 clusters per item). Cluster names come from T1 §6. "
          "Heatmap, gap maps and the Coverage Index update live.", 15)
    for j, (h, w, k) in enumerate([("No", 5, "auto"), ("ID", 14, "auto"), ("Short title", 34, "auto")]):
        header(M4, HDR, 1 + j, h, k, w)
    for k in range(10):
        c = 4 + k
        hc = M4.cell(row=3, column=c, value=f"K{k + 1}")
        hc.font = font(bold=True, color=NAVY)
        hc.alignment = CENTER
        header(M4, HDR, c, f'=IF(INDEX(ClusterNames,{k + 1})="","(K{k + 1} unnamed)",INDEX(ClusterNames,{k + 1}))', "input", 11)
    header(M4, HDR, 14, "# clusters", "auto", 9)
    header(M4, HDR, 15, "Check (≤8)", "auto", 13)
    M4.row_dimensions[HDR].height = 54
    grid(M4, MR1, MRN, 4, 13, inp=True, align=CENTER)
    m4x = D.M4 if example else {}
    for i in range(NM):
        rr = R0 + i
        cell(M4, f"A{rr}", i + 1, align=CENTER)
        cell(M4, f"B{rr}", link(S6, "B", rr), bold=True)
        cell(M4, f"C{rr}", link(S6, "C", rr))
        cell(M4, f"N{rr}", f'=IF(B{rr}="","",COUNTIF(D{rr}:M{rr},"x"))', align=CENTER, bold=True)
        cell(M4, f"O{rr}", f'=IF(B{rr}="","",IF(N{rr}>8,"⚠ >8 clusters",IF(N{rr}=0,"no cluster","OK")))', align=CENTER)
        if i < len(master):
            for k in m4x.get(master[i]["id"], []):
                M4.cell(row=rr, column=3 + k, value="x")
    dv_list(M4, "XMark", f"D{MR1}:M{MRN}", "Type x if the item covers this cluster")
    TOT = MRN + 1  # 55
    cell(M4, f"C{TOT}", "Core items per cluster", bold=True, align=Alignment(horizontal="right"))
    for k in range(10):
        c = CL(4 + k)
        cell(M4, f"{c}{TOT}", f'=COUNTIF({c}{MR1}:{c}{MRN},"x")', bold=True, align=CENTER)
        cell(M4, f"{c}{TOT + 1}", f'=IF({c}{HDR}="(K{k + 1} unnamed)",IF({c}{TOT}>0,"unnamed","—"),'
                                  f'IF({c}{TOT}>=3,"≥3 ✓","<3 ✗"))', align=CENTER, italic=True)
    cell(M4, f"C{TOT + 1}", "Coverage (≥3 core items)", italic=True, align=Alignment(horizontal="right"))
    cell(M4, f"N{TOT}", f"=SUM(N{MR1}:N{MRN})", bold=True, align=CENTER)
    cell(M4, f"C{TOT + 3}", "Named clusters", bold=True, align=Alignment(horizontal="right"))
    cell(M4, f"D{TOT + 3}", f'=SUMPRODUCT(--(ClusterNames<>""))', bold=True, align=CENTER)
    cell(M4, f"C{TOT + 4}", "Clusters with ≥3 core items", bold=True, align=Alignment(horizontal="right"))
    cell(M4, f"D{TOT + 4}", f'=SUMPRODUCT((ClusterNames<>"")*(TRANSPOSE(D{TOT}:M{TOT})>=3))', bold=True, align=CENTER)
    # TRANSPOSE inside SUMPRODUCT can be fragile -> use row-wise alternative
    M4[f"D{TOT + 4}"] = f'=SUMPRODUCT((D{HDR}:M{HDR}<>"")*(LEFT(D{HDR}:M{HDR},1)<>"(")*(D{TOT}:M{TOT}>=3))'
    M4[f"D{TOT + 3}"] = f'=SUMPRODUCT((D{HDR}:M{HDR}<>"")*(LEFT(D{HDR}:M{HDR},1)<>"("))'
    cell(M4, f"C{TOT + 5}", "Coverage Index CovI", bold=True, align=Alignment(horizontal="right"))
    cell(M4, f"D{TOT + 5}", f"=IF(D{TOT + 3}=0,0,D{TOT + 4}/D{TOT + 3})", bold=True, fmt="0.00", align=CENTER)
    M4[f"D{TOT + 5}"].font = Font(name=FONT, bold=True, size=12, color=TEAL)
    cell(M4, f"E{TOT + 5}", "CovI = (# clusters with ≥3 core items) / (# clusters)", italic=True, color=SLATE,
         align=Alignment(horizontal="left"))
    M4.merge_cells(f"E{TOT + 5}:J{TOT + 5}")
    covi_ref = f"{q(SM[4])}!$D${TOT + 5}"
    M4.conditional_formatting.add(f"D{MR1}:M{MRN}", CellIsRule(operator="equal", formula=['"x"'],
                                                               fill=PatternFill("solid", fgColor=TEAL), font=Font(bold=True, color="FFFFFF")))
    M4.conditional_formatting.add(f"D{TOT}:M{TOT}", ColorScaleRule(start_type="num", start_value=0, start_color="FFFFFF",
                                                                   mid_type="num", mid_value=3, mid_color="BFE3E7",
                                                                   end_type="max", end_color=TEAL))
    M4.conditional_formatting.add(f"O{MR1}:O{MRN}", FormulaRule(formula=[f'LEFT($O{MR1},1)="⚠"'], fill=F_CHECK))
    M4.conditional_formatting.add(f"O{MR1}:O{MRN}", CellIsRule(operator="equal", formula=['"no cluster"'], fill=F_AMB))
    M4.conditional_formatting.add(f"D{TOT + 1}:M{TOT + 1}", FormulaRule(formula=[f'RIGHT(D{TOT + 1},1)="✗"'], fill=F_CHECK))
    # gap maps
    gm = TOT + 8
    section(M4, gm, "Cross-matrix synthesis (P6): cluster × stream family (academic–practice–policy comparison)", 15)
    header(M4, gm + 1, 3, "Stream family", "auto")
    for k in range(10):
        header(M4, gm + 1, 4 + k, f"=D{HDR}", "auto")
    for i, f in enumerate(FAMILIES):
        rr = gm + 2 + i
        cell(M4, f"C{rr}", f"{f[0]} {f[1]}", bold=True)
        for k in range(10):
            c = CL(4 + k)
            cell(M4, f"{c}{rr}", f'=COUNTIFS({c}${MR1}:{c}${MRN},"x",{mrng("G")},"{f[0]}")', align=CENTER)
    M4.conditional_formatting.add(f"D{gm + 2}:M{gm + 6}", ColorScaleRule(start_type="num", start_value=0, start_color="FFFFFF",
                                                                         end_type="max", end_color=TEAL))
    gm2 = gm + 9
    section(M4, gm2, "Cluster × method family gap map (white spots = 0)", 15)
    header(M4, gm2 + 1, 3, "Method family", "auto")
    for k in range(10):
        header(M4, gm2 + 1, 4 + k, f"=D{HDR}", "auto")
    for i, mth in enumerate(METHODS):
        rr = gm2 + 2 + i
        cell(M4, f"C{rr}", mth, bold=True)
        for k in range(10):
            c = CL(4 + k)
            cell(M4, f"{c}{rr}", f'=COUNTIFS({c}${MR1}:{c}${MRN},"x",{mrng("M")},"{mth}")', align=CENTER)
    M4.conditional_formatting.add(f"D{gm2 + 2}:M{gm2 + 10}", CellIsRule(operator="equal", formula=["0"], fill=PatternFill("solid", fgColor="FFFFFF"),
                                                                        font=Font(color="BBBBBB")))
    M4.conditional_formatting.add(f"D{gm2 + 2}:M{gm2 + 10}", ColorScaleRule(start_type="num", start_value=0, start_color="FFFFFF",
                                                                            end_type="max", end_color=AMBER))
    gm3 = gm2 + 12
    section(M4, gm3, "Cluster × contribution type map", 15)
    header(M4, gm3 + 1, 3, "Contribution type", "auto")
    for k in range(10):
        header(M4, gm3 + 1, 4 + k, f"=D{HDR}", "auto")
    for i, ct in enumerate(CTS):
        rr = gm3 + 2 + i
        cell(M4, f"C{rr}", ct, bold=True)
        for k in range(10):
            c = CL(4 + k)
            cell(M4, f"{c}{rr}", f'=COUNTIFS({c}${MR1}:{c}${MRN},"x",{mrng("P")},"{ct}")', align=CENTER)
    M4.conditional_formatting.add(f"D{gm3 + 2}:M{gm3 + 9}", ColorScaleRule(start_type="num", start_value=0, start_color="FFFFFF",
                                                                           end_type="max", end_color="7B3F99"))
    M4.freeze_panes = f"D{R0}"
    page_setup(M4, f"{HDR}:{HDR}")
    M4T = q(SM[4])

    # ================================================================ T15 Triangulation (needed by T16)
    T15 = ws_[S15]
    title(T15, "T15 · Triangulation & Resilience Matrix (P6)",
          "Mark “x” for each stream family that supports a key finding. TS = # distinct families (1–5). "
          "Robust TS ≥ 3 · Supported TS = 2 · Tentative TS = 1. LOSO removes one family at a time.", 16)
    cols15 = [("KF", 6, "auto"), ("Key finding (statement)", 54, "input"), ("Related RQ / cluster", 14, "input")] + \
             [(f"{f[0]} {f[1]}", 11, "input") for f in FAMILIES] + \
             [("Supporting source IDs", 30, "input"), ("TS", 6, "auto"), ("Class", 11, "auto")] + \
             [(f"TS without {f[0]}", 8, "auto") for f in FAMILIES]
    for j, (h, w, k) in enumerate(cols15):
        c = header(T15, HDR, 1 + j, h, k, w)
        if 4 <= 1 + j <= 8:
            c.fill = PatternFill("solid", fgColor=FAM_COL[FAMILIES[j - 3][0]])
    T15.row_dimensions[HDR].height = 46
    grid(T15, KF1, KFN, 2, 9, inp=True)
    kfs = D.KF if example else []
    for i in range(NKF):
        rr = R0 + i
        cell(T15, f"A{rr}", f"KF{i + 1}", bold=True, align=CENTER)
        for c in "DEFGH":
            T15[f"{c}{rr}"].alignment = CENTER
        cell(T15, f"J{rr}", f'=IF(B{rr}="","",COUNTIF(D{rr}:H{rr},"x"))', bold=True, align=CENTER)
        cell(T15, f"K{rr}", f'=IF(J{rr}="","",IF(J{rr}>=3,"Robust",IF(J{rr}=2,"Supported",IF(J{rr}=1,"Tentative","No support"))))',
             bold=True, align=CENTER)
        for j, fc in enumerate("DEFGH"):
            cell(T15, f"{CL(12 + j)}{rr}", f'=IF($B{rr}="","",$J{rr}-IF({fc}{rr}="x",1,0))', align=CENTER)
        if i < len(kfs):
            k = kfs[i]
            T15[f"B{rr}"] = k["text"]
            T15[f"C{rr}"] = k["rq"]
            for fam in k["fams"]:
                T15[f"{'DEFGH'[int(fam[1]) - 1]}{rr}"] = "x"
            T15[f"I{rr}"] = k["ids"]
    dv_list(T15, "XMark", f"D{KF1}:H{KFN}", "Type x if this stream family supports the finding")
    rngK = f"K{KF1}:K{KFN}"
    T15.conditional_formatting.add(rngK, CellIsRule(operator="equal", formula=['"Robust"'], fill=F_PASS, font=Font(bold=True, color="1B6E3A")))
    T15.conditional_formatting.add(rngK, CellIsRule(operator="equal", formula=['"Supported"'], fill=F_AMB, font=Font(bold=True, color="8A5A12")))
    T15.conditional_formatting.add(rngK, CellIsRule(operator="equal", formula=['"Tentative"'], fill=F_CHECK, font=Font(bold=True, color=CORAL)))
    for j, f in enumerate(FAMILIES):
        c = "DEFGH"[j]
        T15.conditional_formatting.add(f"{c}{KF1}:{c}{KFN}", CellIsRule(operator="equal", formula=['"x"'],
                                       fill=PatternFill("solid", fgColor=FAM_COL[f[0]]), font=Font(bold=True, color="FFFFFF")))
    T15.conditional_formatting.add(f"L{KF1}:P{KFN}", CellIsRule(operator="lessThan", formula=["2"], fill=F_CHECK))
    sr = KFN + 2  # summary
    section(T15, sr, "Resilience summary", 16)
    lab = [("Key findings (n)", f'=COUNTIF(B{KF1}:B{KFN},"?*")', "0"),
           ("Robust (TS ≥ 3)", f'=COUNTIF({rngK},"Robust")', "0"),
           ("Supported (TS = 2)", f'=COUNTIF({rngK},"Supported")', "0"),
           ("Tentative (TS = 1)", f'=COUNTIF({rngK},"Tentative")', "0"),
           ("Resilience Index RI = (#Robust + 0.5·#Supported) / #KF", f"=IF(B{sr + 1}=0,0,(B{sr + 2}+0.5*B{sr + 3})/B{sr + 1})", "0.00")]
    for i, (a, f, fmt) in enumerate(lab):
        cell(T15, f"A{sr + 1 + i}", None)
        cell(T15, f"B{sr + 1 + i}", f, bold=True, fmt=fmt, align=CENTER)
        T15[f"A{sr + 1 + i}"] = None
        c = T15.cell(row=sr + 1 + i, column=3, value=a)
        c.font = font(bold=True)
        c.border = BORDER
        T15.merge_cells(start_row=sr + 1 + i, start_column=3, end_row=sr + 1 + i, end_column=8)
    # put labels left of values instead: use column B label? keep: value in B, label in C:H
    ri_ref = f"{q(S15)}!$B${sr + 5}"
    T15[f"B{sr + 5}"].font = Font(name=FONT, bold=True, size=12, color=TEAL)
    lr = sr + 7
    section(T15, lr, "Leave-One-Stream-Out (LOSO): share of key findings still at TS ≥ 2 after removing each family", 16)
    header(T15, lr + 1, 2, "Family removed", "auto")
    header(T15, lr + 1, 3, "Share TS ≥ 2", "auto")
    for j, f in enumerate(FAMILIES):
        rr = lr + 2 + j
        cell(T15, f"B{rr}", f"{f[0]} {f[1]}", bold=True)
        col = CL(12 + j)
        cell(T15, f"C{rr}", f'=IF($B${sr + 1}=0,0,COUNTIF({col}{KF1}:{col}{KFN},">=2")/$B${sr + 1})', fmt="0%", align=CENTER, bold=True)
    wr = lr + 7
    cell(T15, f"B{wr}", "LOSO stability (worst case)", bold=True)
    cell(T15, f"C{wr}", f"=MIN(C{lr + 2}:C{lr + 6})", bold=True, fmt="0.00", align=CENTER)
    T15[f"C{wr}"].font = Font(name=FONT, bold=True, size=12, color=TEAL)
    cell(T15, f"B{wr + 1}", "Most influential family (worst case)", bold=True)
    cell(T15, f"C{wr + 1}", f'=IF($B${sr + 1}=0,"—",INDEX(B{lr + 2}:B{lr + 6},MATCH(C{wr},C{lr + 2}:C{lr + 6},0)))', align=CENTER)
    cell(T15, f"B{wr + 2}", "Findings at TS ≥ 2 with all families", bold=True)
    cell(T15, f"C{wr + 2}", f'=IF($B${sr + 1}=0,0,COUNTIF(J{KF1}:J{KFN},">=2")/$B${sr + 1})', fmt="0%", align=CENTER)
    loso_ref = f"{q(S15)}!$C${wr}"
    T15.conditional_formatting.add(f"C{lr + 2}:C{lr + 6}", ColorScaleRule(start_type="num", start_value=0, start_color="FBE3D6",
                                                                          mid_type="num", mid_value=0.7, mid_color="FFF4DC",
                                                                          end_type="num", end_value=1, end_color="9FD8C0"))
    T15.freeze_panes = f"C{R0}"
    page_setup(T15, f"{HDR}:{HDR}")

    # ================================================================ T5 CCD Portfolio
    T5 = ws_[S5]
    title(T5, "T5 · CCD Portfolio Check (P3 Gate 3 – Complementarity · Coverage · Diversity)",
          "All values are live formulas from T4, T6 Master Table, M4 and the active tier. Status PASS / CHECK.", 7)
    widths(T5, {"A": 40, "B": 30, "C": 14, "D": 14, "E": 16, "F": 14, "G": 14})
    cell(T5, "A3", "Active tier", bold=True)
    cell(T5, "B3", "=ActiveTier", bold=True, color=TEAL)
    r = 4
    section(T5, r, "A. Gate summary (numbers for the 360° MDL Flow Diagram, T18)", 7)
    gsum = [("Items screened (T4)", f'=COUNTIF({q(S4)}!B{G1}:B{GN},"?*")'),
            ("Gate 2 – Pass", f'=COUNTIF({q(S4)}!O{G1}:O{GN},"Pass")'),
            ("Gate 2 – Reserve", f'=COUNTIF({q(S4)}!O{G1}:O{GN},"Reserve")'),
            ("Gate 2 – Exclude", f'=COUNTIF({q(S4)}!O{G1}:O{GN},"Exclude")'),
            ("Gate 2 – Incomplete scoring", f'=COUNTIF({q(S4)}!O{G1}:O{GN},"Incomplete")'),
            ("Gate 3 – Core corpus N (T6)", f'=COUNTIF({mrng("B")},"?*")'),
            ("Extended Evidence Pool (Pass not core + Reserve)", f'=COUNTIF({q(S4)}!T{G1}:T{GN},"Extended pool")'),
            ("Core items found in ≥ 2 streams (Convergence Flag)", f'=COUNTIF({mrng("AB")},"Yes")'),
            ("Convergence Rate", None)]
    pos = {}
    for lab_, f in gsum:
        r += 1
        cell(T5, f"A{r}", lab_, bold=True)
        pos[lab_] = r
        if f:
            cell(T5, f"B{r}", f, align=CENTER, bold=True)
    NREF = f"$B${pos['Gate 3 – Core corpus N (T6)']}"
    cr = pos["Convergence Rate"]
    cell(T5, f"B{cr}", f"=IF({NREF}=0,0,B{cr - 1}/{NREF})", fmt="0%", align=CENTER, bold=True)
    conv_ref = f"{q(S5)}!$B${cr}"
    ext_ref = f"{q(S5)}!$B${pos['Extended Evidence Pool (Pass not core + Reserve)']}"
    n_ref = f"{q(S5)}!{NREF}"
    r += 2
    section(T5, r, "B. Stream-family balance (Diversity; SBI)", 7)
    r += 1
    for j, (h, k) in enumerate([("Family", "auto"), ("Name", "auto"), ("Core items", "auto"), ("Share", "auto"),
                                ("≤ 40% rule", "auto"), ("p·ln(p)", "auto")]):
        header(T5, r, 1 + j, h, k)
    fam_first = r + 1
    for f in FAMILIES:
        r += 1
        c = cell(T5, f"A{r}", f[0], bold=True, align=CENTER)
        c.fill = PatternFill("solid", fgColor=FAM_COL[f[0]])
        c.font = font(bold=True, color="FFFFFF")
        cell(T5, f"B{r}", f[1])
        cell(T5, f"C{r}", f'=COUNTIF({mrng("G")},A{r})', align=CENTER)
        cell(T5, f"D{r}", f"=IF({NREF}=0,0,C{r}/{NREF})", fmt="0.0%", align=CENTER)
        cell(T5, f"E{r}", f'=IF({NREF}=0,"—",IF(D{r}<=0.4,"PASS","CHECK"))', align=CENTER)
        cell(T5, f"F{r}", f"=IF(D{r}>0,D{r}*LN(D{r}),0)", fmt="0.0000", align=CENTER)
    fam_last = r
    status_cf(T5, f"E{fam_first}:E{fam_last}")
    r += 1
    cell(T5, f"A{r}", "Total", bold=True)
    cell(T5, f"C{r}", f"=SUM(C{fam_first}:C{fam_last})", bold=True, align=CENTER)
    cell(T5, f"D{r}", f"=SUM(D{fam_first}:D{fam_last})", bold=True, fmt="0.0%", align=CENTER)
    r += 1
    cell(T5, f"A{r}", "H_stream = −Σ p·ln(p)", bold=True)
    cell(T5, f"B{r}", f"=-SUM(F{fam_first}:F{fam_last})", fmt="0.0000", align=CENTER)
    h_row = r
    r += 1
    cell(T5, f"A{r}", "k = stream families used", bold=True)
    cell(T5, f"B{r}", f'=COUNTIF(C{fam_first}:C{fam_last},">0")', align=CENTER)
    k_row = r
    r += 1
    cell(T5, f"A{r}", "Stream Balance Index SBI = H / ln(k)", bold=True)
    cell(T5, f"B{r}", f"=IF(B{k_row}<=1,0,B{h_row}/LN(B{k_row}))", fmt="0.00", align=CENTER, bold=True)
    T5[f"B{r}"].font = Font(name=FONT, bold=True, size=12, color=TEAL)
    sbi_ref = f"{q(S5)}!$B${r}"
    kfam_ref = f"{q(S5)}!$B${k_row}"
    r += 1
    cell(T5, f"A{r}", "Grey literature share (F3 + F4)", bold=True)
    cell(T5, f"B{r}", f"=IF({NREF}=0,0,(C{fam_first + 2}+C{fam_first + 3})/{NREF})", fmt="0.0%", align=CENTER)
    grey_row = r
    r += 1
    cell(T5, f"A{r}", "Emerging & diverse voices share (F5)", bold=True)
    cell(T5, f"B{r}", f"=D{fam_first + 4}", fmt="0.0%", align=CENTER)
    f5_row = r
    r += 1
    cell(T5, f"A{r}", "Largest single-family share", bold=True)
    cell(T5, f"B{r}", f"=MAX(D{fam_first}:D{fam_last})", fmt="0.0%", align=CENTER)
    maxfam_row = r
    r += 2
    section(T5, r, "C. Streams used in the core corpus", 7)
    r += 1
    for j, h in enumerate(["Stream code", "Stream", "Family", "Core items", "Used"]):
        header(T5, r, 1 + j, h, "auto")
    s_first = r + 1
    for i, s in enumerate(STREAMS):
        r += 1
        cell(T5, f"A{r}", f"={q(SL)}!A{5 + i}", bold=True, align=CENTER)
        cell(T5, f"B{r}", f"={q(SL)}!B{5 + i}")
        cell(T5, f"C{r}", f"={q(SL)}!D{5 + i}", align=CENTER)
        cell(T5, f"D{r}", f'=COUNTIF({mrng("E")},A{r})', align=CENTER)
        cell(T5, f"E{r}", f'=IF(D{r}>0,"Yes","")', align=CENTER)
    s_last = r
    r += 1
    cell(T5, f"A{r}", "Streams used (≥3; Standard ≥4; Advanced ≥6)", bold=True)
    cell(T5, f"B{r}", f'=COUNTIF(E{s_first}:E{s_last},"Yes")', bold=True, align=CENTER)
    streams_ref = f"{q(S5)}!$B${r}"
    r += 1
    cell(T5, f"A{r}", "Approach coverage (A / B / C)", bold=True)
    cell(T5, f"B{r}", f'=IF(SUMPRODUCT((LEFT({q(SL)}!$C$5:$C${SLAST},1)="A")*(D{s_first}:D{s_last}>0))>0,"A ","")'
                      f'&IF(SUMPRODUCT((LEFT({q(SL)}!$C$5:$C${SLAST},1)="B")*(D{s_first}:D{s_last}>0))>0,"B ","")'
                      f'&IF(SUMPRODUCT((LEFT({q(SL)}!$C$5:$C${SLAST},1)="C")*(D{s_first}:D{s_last}>0))>0,"C","")', align=CENTER)
    abc_ref = f"{q(S5)}!$B${r}"
    r += 2
    section(T5, r, "D. Method families (M2) – Method Diversity Index", 7)
    r += 1
    for j, h in enumerate(["Method family", "", "Core items", "Share", "", "p·ln(p)"]):
        if h:
            header(T5, r, 1 + j, h, "auto")
    mf_first = r + 1
    for mth in METHODS:
        r += 1
        cell(T5, f"A{r}", mth, bold=True)
        cell(T5, f"C{r}", f'=COUNTIF({mrng("M")},A{r})', align=CENTER)
        cell(T5, f"D{r}", f"=IF($C${mf_first + 9}=0,0,C{r}/$C${mf_first + 9})", fmt="0.0%", align=CENTER)
        cell(T5, f"F{r}", f"=IF(D{r}>0,D{r}*LN(D{r}),0)", fmt="0.0000", align=CENTER)
    mf_last = r
    r += 1
    cell(T5, f"A{r}", "Core items with method family coded", bold=True)
    cell(T5, f"C{r}", f"=SUM(C{mf_first}:C{mf_last})", bold=True, align=CENTER)
    r += 1
    cell(T5, f"A{r}", "Method families represented", bold=True)
    cell(T5, f"B{r}", f'=COUNTIF(C{mf_first}:C{mf_last},">0")', align=CENTER, bold=True)
    nmeth_row = r
    r += 1
    cell(T5, f"A{r}", "H_method = −Σ p·ln(p)", bold=True)
    cell(T5, f"B{r}", f"=-SUM(F{mf_first}:F{mf_last})", fmt="0.0000", align=CENTER)
    r += 1
    cell(T5, f"A{r}", "Method Diversity Index MDI = H / ln(9)", bold=True)
    cell(T5, f"B{r}", f"=IF(C{mf_last + 1}=0,0,B{r - 1}/LN(9))", fmt="0.00", align=CENTER, bold=True)
    T5[f"B{r}"].font = Font(name=FONT, bold=True, size=12, color=TEAL)
    mdi_ref = f"{q(S5)}!$B${r}"
    r += 2
    section(T5, r, "E. Contribution types (M3 – Contribution Taxonomy)", 7)
    r += 1
    for j, h in enumerate(["Contribution type", "", "Core items", "Share"]):
        if h:
            header(T5, r, 1 + j, h, "auto")
    ct_first = r + 1
    for ct in CTS:
        r += 1
        cell(T5, f"A{r}", ct, bold=True)
        cell(T5, f"C{r}", f'=COUNTIF({mrng("P")},A{r})', align=CENTER)
        cell(T5, f"D{r}", f"=IF(SUM($C${ct_first}:$C${ct_first + 7})=0,0,C{r}/SUM($C${ct_first}:$C${ct_first + 7}))",
             fmt="0.0%", align=CENTER)
    r += 1
    cell(T5, f"A{r}", "Contribution types represented", bold=True)
    cell(T5, f"B{r}", f'=COUNTIF(C{ct_first}:C{ct_first + 7},">0")', align=CENTER, bold=True)
    r += 2
    section(T5, r, "F. Keyword-cluster coverage (Coverage; from M4)", 7)
    r += 1
    for j, h in enumerate(["Cluster", "Name", "Core items", "Threshold (tier)", "Status"]):
        header(T5, r, 1 + j, h, "auto")
    kc_first = r + 1
    for k in range(10):
        r += 1
        cell(T5, f"A{r}", f"K{k + 1}", bold=True, align=CENTER)
        cell(T5, f"B{r}", f'=IF(INDEX(ClusterNames,{k + 1})="","(unnamed)",INDEX(ClusterNames,{k + 1}))')
        cell(T5, f"C{r}", f"={M4T}!{CL(4 + k)}{TOT}", align=CENTER)
        cell(T5, f"D{r}", "=" + tparam("CCD coverage threshold"), align=CENTER)
        cell(T5, f"E{r}", f'=IF(B{r}="(unnamed)","—",IF(C{r}>=D{r},"PASS","CHECK"))', align=CENTER)
    kc_last = r
    status_cf(T5, f"E{kc_first}:E{kc_last}")
    r += 2
    section(T5, r, "G. Portfolio rules check (Gate 3)", 7)
    r += 1
    for j, h in enumerate(["Rule", "Value", "Requirement", "Status"]):
        header(T5, r, 1 + j, h, "auto")
    rules_first = r + 1
    rules = [
        ("No single stream family > 40% of core", f"=B{maxfam_row}", '="≤ 40%"', f'IF({NREF}=0,"—",IF(B{{r}}<=0.4,"PASS","CHECK"))', "0.0%"),
        ("Grey literature (F3 + F4) 10–30%", f"=B{grey_row}", '="10–30%"', f'IF({NREF}=0,"—",IF(AND(B{{r}}>=0.1,B{{r}}<=0.3),"PASS","CHECK"))', "0.0%"),
        ("F5 Emerging & diverse voices ≥ quota", f"=B{f5_row}", '="≥ "&TEXT(' + tparam("F5 quota") + ',"0%")',
         f'IF({NREF}=0,"—",IF(B{{r}}>={tparam("F5 quota")},"PASS","CHECK"))', "0.0%"),
        ("≥ 3 method families represented", f"=B{nmeth_row}", '="≥ 3"', f'IF({NREF}=0,"—",IF(B{{r}}>=3,"PASS","CHECK"))', "0"),
        ("Every keyword cluster covered (tier threshold)", f'=COUNTIF(E{kc_first}:E{kc_last},"CHECK")', '="0 clusters below threshold"',
         f'IF({NREF}=0,"—",IF(AND(B{{r}}=0,COUNTIF(E{kc_first}:E{kc_last},"PASS")>0),"PASS","CHECK"))', "0"),
        ("No single author/group > 3 items", f'=SUMPRODUCT(MAX(({mrng("H")}<>"")*COUNTIF({mrng("H")},{mrng("H")}&"")))', '="≤ 3"',
         f'IF({NREF}=0,"—",IF(B{{r}}<=3,"PASS","CHECK"))', "0"),
        ("All core items passed the 6R gate", f'=COUNTIF({mrng("B")},"?*")-COUNTIF({mrng("AA")},"Pass")', '="0 non-Pass items"',
         f'IF({NREF}=0,"—",IF(B{{r}}=0,"PASS","CHECK"))', "0"),
        ("Core corpus ≤ 50 and within tier range", f"={NREF}", '=' + tparam("Core min") + '&"–"&' + tparam("Core max"),
         f'IF({NREF}=0,"—",IF(AND(B{{r}}>={tparam("Core min")},B{{r}}<={tparam("Core max")},B{{r}}<=50),"PASS","CHECK"))', "0"),
    ]
    for lab_, v, req, st, fmt in rules:
        r += 1
        cell(T5, f"A{r}", lab_, bold=True)
        cell(T5, f"B{r}", v, fmt=fmt, align=CENTER, bold=True)
        cell(T5, f"C{r}", req, align=CENTER)
        cell(T5, f"D{r}", "=" + st.format(r=r), align=CENTER)
    rules_last = r
    status_cf(T5, f"D{rules_first}:D{rules_last}")
    r += 1
    cell(T5, f"A{r}", "Portfolio rules passed", bold=True)
    cell(T5, f"B{r}", f'=COUNTIF(D{rules_first}:D{rules_last},"PASS")&" / {rules_last - rules_first + 1}"', bold=True, align=CENTER)
    rules_pass_ref = f"{q(S5)}!$B${r}"
    T5.merge_cells(f"C{3}:D{3}") if False else None
    T5.freeze_panes = "A4"
    page_setup(T5)
    T5.page_setup.orientation = "portrait"

    # ================================================================ M1, M2, M3, M5, M6, M7
    def matrix_sheet(key, ttl, sub, cols, dvs=None, fill_fn=None):
        ws = ws_[SM[key]]
        title(ws, ttl, sub, len(cols) + 3)
        base = [("No", 5, "auto", None), ("ID", 14, "auto", "B"), ("Short title", 32, "auto", "C")]
        allc = base + cols
        for j, (h, w, k, _) in enumerate(allc):
            header(ws, HDR, 1 + j, h, k, w)
        ws.row_dimensions[HDR].height = 36
        grid(ws, MR1, MRN, 4, len(allc), inp=True)
        for i in range(NM):
            rr = R0 + i
            cell(ws, f"A{rr}", i + 1, align=CENTER)
            for j, (h, w, k, src) in enumerate(allc[1:], start=2):
                if src:
                    cell(ws, f"{CL(j)}{rr}", link(S6, src, rr), bold=(j == 2))
            if fill_fn and i < len(master):
                for colidx, v in fill_fn(master[i]).items():
                    if v not in (None, ""):
                        ws.cell(row=rr, column=colidx, value=v)
        for nm_, colidx in (dvs or []):
            dv_list(ws, nm_, f"{CL(colidx)}{MR1}:{CL(colidx)}{MRN}")
        ws.freeze_panes = f"D{R0}"
        ws.auto_filter.ref = f"A{HDR}:{CL(len(allc))}{MRN}"
        page_setup(ws, f"{HDR}:{HDR}")
        return ws

    ex = D.matrix_fill if example else (lambda k: None)
    matrix_sheet(1, "M1 · General Matrix (T7)", "Compact overview per core item. Teal columns are linked from the Master Table; "
                 "fill Approach and Contribution reference.",
                 [("Topics covered (codified themes)", 30, "auto", "J"), ("Approach (summary of scientific approach)", 34, "input", None),
                  ("Methodology", 28, "auto", "L"), ("Key findings", 40, "auto", "N"),
                  ("Contribution reference (Theory / Practice / Industry)", 16, "input", None), ("Significance (codified)", 12, "auto", "R")],
                 dvs=[("ContribRef", 8)], fill_fn=ex(1) if example else None)
    matrix_sheet(2, "M2 · Methodology Matrix (T8)", "Method family is selected in the Master Table (drop-down) and linked here; "
                 "record data source, sample and analysis technique. Goal: diversity of methods (MDI in T5/T16).",
                 [("Method family", 18, "auto", "M"), ("Methodology (summary)", 30, "auto", "L"), ("Data source", 24, "input", None),
                  ("Sample", 18, "input", None), ("Analysis technique", 26, "input", None), ("Notes", 24, "input", None)],
                 fill_fn=ex(2) if example else None)
    matrix_sheet(3, "M3 · Contribution & Impact Matrix (T9)", "Contribution type (CT1–CT8) is selected in the Master Table and linked; "
                 "choose the impact locus here.",
                 [("Type of contribution (CT1–CT8)", 22, "auto", "P"), ("Contribution", 34, "auto", "Q"),
                  ("Impact locus", 13, "input", None), ("Research contribution", 30, "auto", "U"),
                  ("Significance", 12, "auto", "R"), ("Evidence / notes on impact", 30, "input", None)],
                 dvs=[("ImpactLocus", 6)], fill_fn=ex(3) if example else None)
    m5 = matrix_sheet(5, "M5 · Research Questions Matrix (T11)", "Map explicit/implicit RQs of each item; group into RQ families "
                      "(What · Why · How · What-if · Should); select complementary questions.",
                      [("Research question(s) of the item", 44, "input", None), ("RQ type", 10, "input", None),
                       ("RQ family", 18, "input", None), ("Maps to review RQ", 10, "input", None),
                       ("Complementary? (Y/N)", 12, "input", None), ("Notes", 26, "input", None)],
                      dvs=[("RQTypes", 5), ("RQFamilies", 6), ("ReviewRQs", 7), ("YesNo", 8)], fill_fn=ex(5) if example else None)
    # RQ family summary
    sr5 = MRN + 2
    section(m5, sr5, "RQ family distribution", 9)
    header(m5, sr5 + 1, 3, "RQ family", "auto")
    header(m5, sr5 + 1, 4, "Items", "auto")
    header(m5, sr5 + 1, 5, "Selected (Y)", "auto")
    for i, fam in enumerate(RQFAM):
        rr = sr5 + 2 + i
        cell(m5, f"C{rr}", fam, bold=True)
        cell(m5, f"D{rr}", f'=COUNTIF(F{MR1}:F{MRN},C{rr})', align=CENTER)
        cell(m5, f"E{rr}", f'=COUNTIFS(F{MR1}:F{MRN},C{rr},H{MR1}:H{MRN},"Y")', align=CENTER)
    header(m5, sr5 + 1, 7, "Review RQ", "auto")
    header(m5, sr5 + 1, 8, "Items mapped", "auto")
    for i, rq in enumerate(RQIDS):
        rr = sr5 + 2 + i
        cell(m5, f"G{rr}", rq, bold=True, align=CENTER)
        cell(m5, f"H{rr}", f'=COUNTIF(G{MR1}:G{MRN},G{rr})', align=CENTER)
    m6 = matrix_sheet(6, "M6 · Open Research Issues Matrix (T12)", "Future research and limitations are linked from the Master Table; "
                      "synthesise the open issue, assign an agenda cluster and perspective, and select complementary items.",
                      [("Future research", 32, "auto", "S"), ("Limitations", 28, "auto", "T"),
                       ("Open issue (synthesised)", 36, "input", None), ("Agenda cluster", 10, "input", None),
                       ("Perspective", 12, "input", None), ("Priority", 10, "input", None), ("Selected for agenda (Y/N)", 12, "input", None)],
                      dvs=[("ClusterCodes", 7), ("Perspectives", 8), ("Priorities", 9), ("YesNo", 10)], fill_fn=ex(6) if example else None)
    sr6 = MRN + 2
    section(m6, sr6, "Research agenda by cluster (selected items)", 10)
    header(m6, sr6 + 1, 3, "Cluster", "auto")
    header(m6, sr6 + 1, 4, "Name", "auto")
    header(m6, sr6 + 1, 5, "Open issues", "auto")
    header(m6, sr6 + 1, 6, "Selected", "auto")
    header(m6, sr6 + 1, 7, "High priority", "auto")
    for k in range(10):
        rr = sr6 + 2 + k
        cell(m6, f"C{rr}", f"K{k + 1}", bold=True, align=CENTER)
        cell(m6, f"D{rr}", f'=IF(INDEX(ClusterNames,{k + 1})="","",INDEX(ClusterNames,{k + 1}))')
        cell(m6, f"E{rr}", f'=COUNTIF(G{MR1}:G{MRN},C{rr})', align=CENTER)
        cell(m6, f"F{rr}", f'=COUNTIFS(G{MR1}:G{MRN},C{rr},J{MR1}:J{MRN},"Y")', align=CENTER)
        cell(m6, f"G{rr}", f'=COUNTIFS(G{MR1}:G{MRN},C{rr},I{MR1}:I{MRN},"High")', align=CENTER)
    m7 = matrix_sheet(7, "M7 · Interpretation & Exploitation Matrix (T13)", "Key interpretation, exploitation mode and VBF element "
                      "are linked from the Master Table; add the target stakeholder and actionable implication.",
                      [("Key interpretation (what it means)", 38, "auto", "V"), ("Exploitation mode", 16, "auto", "W"),
                       ("Target stakeholder", 18, "input", None), ("Actionable implication", 36, "input", None),
                       ("Value-Based Framework element", 14, "auto", "X"), ("Supports key finding(s)", 12, "input", None)],
                      fill_fn=ex(7) if example else None)
    sr7 = MRN + 2
    section(m7, sr7, "Exploitation modes in the core corpus", 9)
    header(m7, sr7 + 1, 3, "Exploitation mode", "auto")
    header(m7, sr7 + 1, 4, "Items", "auto")
    for i, e in enumerate(EXPLOIT):
        rr = sr7 + 2 + i
        cell(m7, f"C{rr}", e, bold=True)
        cell(m7, f"D{rr}", f'=COUNTIF({mrng("W")},C{rr})', align=CENTER)

    # ================================================================ M8 Value Framework canvas
    M8 = ws_[SM[8]]
    title(M8, "M8 · Value-Based Framework Canvas (T14)",
          "Map interpretations into an original framework: Enablers → Capabilities → Processes → Outcomes → Value (for "
          "stakeholders) → Measures, with a stakeholder lens. Cite source IDs for every cell (derivation from the evidence).", 10)
    widths(M8, {"A": 15, "B": 30, "C": 28, "D": 28, "E": 28, "F": 28, "G": 28, "H": 26, "I": 11, "J": 22})
    cell(M8, "A3", "Framework name:", bold=True)
    cell(M8, "B3", D.M8["name"] if example else None, inp=True, bold=True)
    M8.merge_cells("B3:G3")
    header(M8, HDR, 1, "Layer", "auto")
    header(M8, HDR, 2, "Guiding question", "auto")
    stake = D.M8["stakeholders"] if example else ["Stakeholder 1", "Stakeholder 2", "Stakeholder 3", "Stakeholder 4", "Stakeholder 5"]
    for j, s in enumerate(stake):
        header(M8, HDR, 3 + j, s, "input")
    header(M8, HDR, 8, "Source IDs (evidence)", "input")
    header(M8, HDR, 9, "Core items tagged (T6)", "auto")
    header(M8, HDR, 10, "Key findings linked (KF)", "input")
    M8.row_dimensions[HDR].height = 36
    guide = ["What must be in place? (resources, infrastructure, leadership, data, skills)",
             "Which organisational/technical capabilities do the enablers create?",
             "Which processes/practices turn capabilities into results?",
             "What measurable outcomes result (outputs, performance, adoption)?",
             "What value is created, and for which stakeholders?",
             "How is it measured? (KPIs, indices, evaluation instruments)"]
    for i, lay in enumerate(VBF):
        rr = R0 + i
        c = cell(M8, f"A{rr}", lay, bold=True, align=CENTER)
        c.fill = PatternFill("solid", fgColor=[NAVY, "1F4E79", TEAL, "2A9D8F", AMBER, CORAL][i])
        c.font = font(bold=True, color="FFFFFF", size=11)
        cell(M8, f"B{rr}", guide[i], italic=True, color=SLATE)
        for j in range(5):
            cell(M8, f"{CL(3 + j)}{rr}", D.M8["cells"][i][j] if example else None, inp=True)
        cell(M8, f"H{rr}", D.M8["ids"][i] if example else None, inp=True)
        cell(M8, f"I{rr}", f'=COUNTIF({mrng("X")},A{rr})', align=CENTER, bold=True)
        cell(M8, f"J{rr}", D.M8["kf"][i] if example else None, inp=True)
        M8.row_dimensions[rr].height = 78
    rr = R0 + 7
    cell(M8, f"A{rr}", "Flow", bold=True)
    cell(M8, f"B{rr}", "Enablers → Capabilities → Processes → Outcomes → Value → Measures  (Input–Process–Output logic with "
                       "well-defined outcomes)", italic=True, color=TEAL)
    M8.merge_cells(f"B{rr}:H{rr}")
    M8.conditional_formatting.add(f"I{R0}:I{R0 + 5}", ColorScaleRule(start_type="num", start_value=0, start_color="FFFFFF",
                                                                     end_type="max", end_color=TEAL))
    M8.freeze_panes = f"C{R0}"
    page_setup(M8, f"{HDR}:{HDR}")

    # ================================================================ T16 Dashboard
    T16 = ws_[S16]
    title(T16, "T16 · 360° MDL Indices Dashboard", "All indices are live formulas. Targets follow the active tier "
                                                    "(Start Here). Status: PASS / CHECK / REPORT (no target for this tier).", 7)
    widths(T16, {"A": 34, "B": 12, "C": 50, "D": 14, "E": 11, "F": 22, "G": 3})
    cell(T16, "A3", "Active tier", bold=True)
    cell(T16, "B3", "=ActiveTier", bold=True, color=TEAL, align=CENTER)
    cell(T16, "C3", f'="Core corpus N = "&{n_ref}&" · Mode "&IF({q(S1)}!B{0}="","—",{q(S1)}!B{0})', italic=True)
    # find mode cell row in T1
    mode_row = None
    for row in T1.iter_rows(min_col=1, max_col=1):
        if row[0].value == "Mode":
            mode_row = row[0].row
    T16["C3"] = f'="Core corpus N = "&{n_ref}&" · Mode: "&IF({q(S1)}!B{mode_row}="","—",{q(S1)}!B{mode_row})'
    r = 5
    for j, h in enumerate(["Index", "Value", "Definition (spec §7)", "Target", "Status", "Source"]):
        header(T16, r, 1 + j, h, "auto")
    idx = [
        ("Stream Balance Index (SBI)", f"={sbi_ref}", "H_stream / ln(k); H = −Σ p_i ln p_i over the k stream families used. Range 0–1.",
         "SBI target", S5, "0.00"),
        ("Coverage Index (CovI)", f"={covi_ref}", "(# keyword clusters with ≥ 3 core items) / (# clusters).", "CovI target", SM[4], "0.00"),
        ("Method Diversity Index (MDI)", f"={mdi_ref}", "Normalised Shannon entropy over method families; divided by ln(9).",
         "MDI target", S5, "0.00"),
        ("Resilience Index (RI)", f"={ri_ref}", "(#Robust + 0.5 × #Supported) / #Key findings.", "RI target", S15, "0.00"),
        ("Leave-One-Stream-Out (LOSO) stability", f"={loso_ref}", "Share of key findings still at TS ≥ 2 after removing any single "
         "stream family (worst case).", "LOSO target", S15, "0.00"),
        ("Convergence Rate", f"={conv_ref}", "Share of core items found in ≥ 2 streams (descriptive; reported, no target).", None, S5, "0%"),
    ]
    idx_first = r + 1
    for name, f, dfn, tcol, src, fmt in idx:
        r += 1
        cell(T16, f"A{r}", name, bold=True)
        c = cell(T16, f"B{r}", f, bold=True, fmt=fmt, align=CENTER)
        c.font = Font(name=FONT, bold=True, size=12, color=NAVY)
        cell(T16, f"C{r}", dfn, italic=True, color=SLATE)
        if tcol:
            cell(T16, f"D{r}", "=" + tparam(tcol), fmt='"≥ "0.00', align=CENTER)
            cell(T16, f"E{r}", f'=IF(ISNUMBER(D{r}),IF(B{r}>=D{r},"PASS","CHECK"),"REPORT")', align=CENTER, bold=True)
        else:
            cell(T16, f"D{r}", "—", align=CENTER)
            cell(T16, f"E{r}", "REPORT", align=CENTER, bold=True)
        c = cell(T16, f"F{r}", src, color=TEAL)
        c.hyperlink = f"#'{src}'!A1"
        T16.row_dimensions[r].height = 30
    idx_last = r
    status_cf(T16, f"E{idx_first}:E{idx_last}")
    T16.conditional_formatting.add(f"B{idx_first}:B{idx_last - 1}", ColorScaleRule(start_type="num", start_value=0, start_color="FBE3D6",
                                                                                   mid_type="num", mid_value=0.6, mid_color="FFF4DC",
                                                                                   end_type="num", end_value=1, end_color="9FD8C0"))
    r += 2
    for j, h in enumerate(["Structural check", "Value", "Rule", "Requirement", "Status", "Source"]):
        header(T16, r, 1 + j, h, "auto")
    st_first = r + 1
    checks = [
        ("Core corpus size", f"={n_ref}", "Core ≤ 50; tier range (Lite 20–30; Standard 40–50; Advanced 50 core)",
         "=" + tparam("Core min") + '&"–"&' + tparam("Core max"),
         "IF(AND(B{r}>=" + tparam("Core min") + ",B{r}<=" + tparam("Core max") + ',B{r}<=50),"PASS","CHECK")', S5, "0"),
        ("Streams used (core corpus)", f"={streams_ref}", "≥ 3 streams (Standard ≥ 4; Advanced A+B+C ≥ 6)",
         '="≥ "&' + tparam("Min streams"), 'IF(B{r}>=' + tparam("Min streams") + ',"PASS","CHECK")', S5, "0"),
        ("Stream families used (k)", f"={kfam_ref}", "Triangulation needs several independent families", '="≥ 3"',
         'IF(B{r}>=3,"PASS","CHECK")', S5, "0"),
        ("Grey literature stream present (F3/F4)", f'=IF(COUNTIF({mrng("G")},"F3")+COUNTIF({mrng("G")},"F4")>0,"Yes","No")',
         "Standard & Advanced: ≥ 1 grey (industry or policy) stream", '=IF(' + tparam("Grey stream required") + '="Y","Required","Recommended")',
         'IF(B{r}="Yes","PASS",IF(D{r}="Required","CHECK","REPORT"))', S5, None),
        ("Approaches covered (A/B/C)", f"={abc_ref}", "Mode 360 = A + B + C (required for Advanced)",
         '=IF(ActiveTier="Advanced","A B C","—")', 'IF(ActiveTier<>"Advanced","REPORT",IF(LEN(SUBSTITUTE(B{r}," ",""))=3,"PASS","CHECK"))', S5, None),
        ("F5 Emerging & diverse voices share", f"={q(S5)}!$B${f5_row}", "Approach C quota: ≥ 10% (Standard), ≥ 15% (Advanced)",
         '="≥ "&TEXT(' + tparam("F5 quota") + ',"0%")', 'IF(B{r}>=' + tparam("F5 quota") + ',"PASS","CHECK")', S5, "0.0%"),
        ("Analysis matrices used (T1)", f"={mat_used_ref}", "3×3 Rule ≥ 3; Standard M1–M6; Advanced M1–M8",
         '="≥ "&' + tparam("Min matrices"), 'IF(B{r}>=' + tparam("Min matrices") + ',"PASS","CHECK")', S1, "0"),
        ("3×3 Rule (≥3 streams × ≥3 matrices)", f'=IF(AND({streams_ref}>=3,{mat_used_ref}>=3),"Met","Not met")',
         "Qualifies as a 360° MDL review", '="Met"', 'IF(B{r}="Met","PASS","CHECK")', S0, None),
        ("Extended Evidence Pool size", f"={ext_ref}", "Advanced: ≤ 30 items", '=IF(ISNUMBER(' + tparam("Extended pool max") +
         '),"≤ "&' + tparam("Extended pool max") + ',"—")',
         'IF(ISNUMBER(' + tparam("Extended pool max") + '),IF(B{r}<=' + tparam("Extended pool max") + ',"PASS","CHECK"),"REPORT")', S4, "0"),
        ("CCD portfolio rules passed", f"={rules_pass_ref}", "All Gate 3 rules (T5 section G)", '="8 / 8"',
         'IF(B{r}="8 / 8","PASS","CHECK")', S5, None),
        ("Reporting checklist completion (MDL-RC 2026)", None, "Share of applicable items reported (Y)", '="100%"',
         'IF(B{r}>=1,"PASS","CHECK")', S17, "0%"),
    ]
    for name, v, rule, req, st, src, fmt in checks:
        r += 1
        cell(T16, f"A{r}", name, bold=True)
        cell(T16, f"B{r}", v, bold=True, align=CENTER, fmt=fmt)
        cell(T16, f"C{r}", rule, italic=True, color=SLATE)
        cell(T16, f"D{r}", req, align=CENTER)
        cell(T16, f"E{r}", "=" + st.format(r=r), align=CENTER, bold=True)
        c = cell(T16, f"F{r}", src, color=TEAL)
        c.hyperlink = f"#'{src}'!A1"
    st_last = r
    checklist_row = r
    status_cf(T16, f"E{st_first}:E{st_last}")
    r += 2
    cell(T16, f"A{r}", "Quality badge", bold=True)
    cell(T16, f"B{r}", f'=IF(AND(COUNTIF(E{idx_first}:E{st_last},"CHECK")=0,{n_ref}>0),"Eligible: “Conducted and reported according to '
                       f'360° MDL v2026 (Tier "&ActiveTier&")”","Not yet eligible – "&COUNTIF(E{idx_first}:E{st_last},"CHECK")&" item(s) to CHECK")',
         bold=True, color=NAVY)
    T16.merge_cells(f"B{r}:F{r}")
    badge_row = r
    T16.conditional_formatting.add(f"B{badge_row}", FormulaRule(formula=[f'LEFT(B{badge_row},8)="Eligible"'], fill=F_PASS))
    T16.conditional_formatting.add(f"B{badge_row}", FormulaRule(formula=[f'LEFT(B{badge_row},3)="Not"'], fill=F_CHECK))
    # chart data helpers (hidden-ish block)
    r += 2
    section(T16, r, "Chart data (linked)", 7)
    r += 1
    header(T16, r, 1, "Index", "auto")
    header(T16, r, 2, "Value", "auto")
    header(T16, r, 3, "Target (0 if none)", "auto")
    cd_first = r + 1
    for i, nm_ in enumerate(["SBI", "CovI", "MDI", "RI", "LOSO"]):
        r += 1
        cell(T16, f"A{r}", nm_, bold=True)
        cell(T16, f"B{r}", f"=B{idx_first + i}", fmt="0.00", align=CENTER)
        cell(T16, f"C{r}", f"=IF(ISNUMBER(D{idx_first + i}),D{idx_first + i},0)", fmt="0.00", align=CENTER)
    cd_last = r
    r += 2
    header(T16, r, 1, "Stream family", "auto")
    header(T16, r, 2, "Share", "auto")
    fs_first = r + 1
    for i, f in enumerate(FAMILIES):
        r += 1
        cell(T16, f"A{r}", f"{f[0]} {f[1]}", bold=True)
        cell(T16, f"B{r}", f"={q(S5)}!D{fam_first + i}", fmt="0%", align=CENTER)
    fs_last = r
    r += 2
    header(T16, r, 1, "Cluster", "auto")
    header(T16, r, 2, "Core items", "auto")
    cc_first = r + 1
    for k in range(10):
        r += 1
        cell(T16, f"A{r}", f'="K{k + 1} "&{q(S5)}!B{kc_first + k}')
        cell(T16, f"B{r}", f"={q(S5)}!C{kc_first + k}", align=CENTER)
    cc_last = r
    # charts
    ch = BarChart()
    ch.type = "col"
    ch.title = "Indices vs tier targets"
    ch.y_axis.scaling.min = 0
    ch.y_axis.scaling.max = 1
    ch.y_axis.majorGridlines = None
    ch.add_data(Reference(T16, min_col=2, max_col=3, min_row=cd_first - 1, max_row=cd_last), titles_from_data=True)
    ch.set_categories(Reference(T16, min_col=1, min_row=cd_first, max_row=cd_last))
    ch.series[0].graphicalProperties.solidFill = TEAL
    ch.series[1].graphicalProperties.solidFill = "D5DBE1"
    ch.height, ch.width = 7, 13
    T16.add_chart(ch, "H5")
    ch2 = BarChart()
    ch2.type = "bar"
    ch2.title = "Core corpus by stream family"
    ch2.legend = None
    ch2.add_data(Reference(T16, min_col=2, min_row=fs_first - 1, max_row=fs_last), titles_from_data=True)
    ch2.set_categories(Reference(T16, min_col=1, min_row=fs_first, max_row=fs_last))
    ch2.series[0].graphicalProperties.solidFill = NAVY
    ch2.y_axis.numFmt = "0%"
    ch2.y_axis.majorGridlines = None
    ch2.height, ch2.width = 7, 13
    T16.add_chart(ch2, "H20")
    ch3 = BarChart()
    ch3.type = "bar"
    ch3.title = "Keyword-cluster coverage (core items)"
    ch3.legend = None
    ch3.add_data(Reference(T16, min_col=2, min_row=cc_first - 1, max_row=cc_last), titles_from_data=True)
    ch3.set_categories(Reference(T16, min_col=1, min_row=cc_first, max_row=cc_last))
    ch3.series[0].graphicalProperties.solidFill = TEAL
    ch3.y_axis.majorGridlines = None
    ch3.height, ch3.width = 9, 13
    T16.add_chart(ch3, "H35")
    T16.freeze_panes = "A5"
    page_setup(T16)

    # ================================================================ T17 Checklist
    T17 = ws_[S17]
    title(T17, "T17 · 360° MDL Reporting Checklist (MDL-RC 2026)", "30 items. Mark Y (reported), N (not reported) or NA "
                                                                   "(not applicable, e.g., item 10 without Approach B). "
                                                                   "Completion = Y / (30 − NA).", 6)
    for j, (h, w, k) in enumerate([("Section", 24, "auto"), ("#", 5, "auto"), ("Checklist item", 62, "auto"),
                                   ("Reported (Y/N/NA)", 11, "input"), ("Page / section", 14, "input"), ("Notes", 36, "input")]):
        header(T17, HDR, 1 + j, h, k, w)
    cl = D.CHECK if example else {}
    for i, (sec, n, txt) in enumerate(CHECKLIST):
        rr = R0 + i
        cell(T17, f"A{rr}", sec, bold=True, color=NAVY)
        cell(T17, f"B{rr}", n, align=CENTER)
        cell(T17, f"C{rr}", txt)
        v = cl.get(n, (None, None, None))
        cell(T17, f"D{rr}", v[0], inp=True, align=CENTER)
        cell(T17, f"E{rr}", v[1], inp=True)
        cell(T17, f"F{rr}", v[2], inp=True)
    c1, cN = R0, R0 + 29
    dv_list(T17, "YNNA", f"D{c1}:D{cN}")
    T17.conditional_formatting.add(f"D{c1}:D{cN}", CellIsRule(operator="equal", formula=['"Y"'], fill=F_PASS))
    T17.conditional_formatting.add(f"D{c1}:D{cN}", CellIsRule(operator="equal", formula=['"N"'], fill=F_CHECK))
    T17.conditional_formatting.add(f"D{c1}:D{cN}", CellIsRule(operator="equal", formula=['"NA"'], fill=F_SEC))
    r = cN + 2
    cell(T17, f"C{r}", "Items reported (Y)", bold=True, align=Alignment(horizontal="right"))
    cell(T17, f"D{r}", f'=COUNTIF(D{c1}:D{cN},"Y")', bold=True, align=CENTER)
    cell(T17, f"C{r + 1}", "Not applicable (NA)", bold=True, align=Alignment(horizontal="right"))
    cell(T17, f"D{r + 1}", f'=COUNTIF(D{c1}:D{cN},"NA")', bold=True, align=CENTER)
    cell(T17, f"C{r + 2}", "Not yet reported (N or blank)", bold=True, align=Alignment(horizontal="right"))
    cell(T17, f"D{r + 2}", f"=30-D{r}-D{r + 1}", bold=True, align=CENTER)
    cell(T17, f"C{r + 3}", "Completion %", bold=True, align=Alignment(horizontal="right"))
    cell(T17, f"D{r + 3}", f"=IF(30-D{r + 1}=0,0,D{r}/(30-D{r + 1}))", bold=True, fmt="0%", align=CENTER)
    T17[f"D{r + 3}"].font = Font(name=FONT, bold=True, size=12, color=TEAL)
    comp_ref = f"{q(S17)}!$D${r + 3}"
    # section completion
    r2 = r + 5
    section(T17, r2, "Completion by section", 6)
    header(T17, r2 + 1, 1, "Section", "auto")
    header(T17, r2 + 1, 2, "Items", "auto")
    header(T17, r2 + 1, 3, "Completion % (Y / applicable)", "auto")
    secs = []
    for s_, _, _ in CHECKLIST:
        if s_ not in secs:
            secs.append(s_)
    for i, s_ in enumerate(secs):
        rr = r2 + 2 + i
        cell(T17, f"A{rr}", s_, bold=True)
        cell(T17, f"B{rr}", f"=COUNTIF($A${c1}:$A${cN},A{rr})", align=CENTER)
        cell(T17, f"C{rr}", f'=IF(B{rr}-COUNTIFS($A${c1}:$A${cN},A{rr},$D${c1}:$D${cN},"NA")=0,0,'
                            f'COUNTIFS($A${c1}:$A${cN},A{rr},$D${c1}:$D${cN},"Y")/(B{rr}-COUNTIFS($A${c1}:$A${cN},A{rr},$D${c1}:$D${cN},"NA")))',
             fmt="0%", align=CENTER)
    T17.conditional_formatting.add(f"C{r2 + 2}:C{r2 + 1 + len(secs)}", ColorScaleRule(start_type="num", start_value=0, start_color="FBE3D6",
                                                                                     end_type="num", end_value=1, end_color="9FD8C0"))
    T17.freeze_panes = f"A{R0}"
    page_setup(T17, f"{HDR}:{HDR}")
    T16[f"B{checklist_row}"] = f"={comp_ref}"

    # ================================================================ PRISMA 2020 checklist (applied review only)
    if example and getattr(D, "PRISMA", None):
        P = wb.create_sheet(SP, index=wb.sheetnames.index(S17) + 1)
        P.sheet_properties.tabColor = AMBER
        title(P, "PRISMA 2020 Checklist (Supplementary Table S1)",
              "Item texts: Page MJ et al. BMJ 2021;372:n71. Location = section of the manuscript where the item is reported. "
              "Items not done or not applicable are marked honestly; 360° MDL substitutes are noted.", 6)
        for j, (h, w) in enumerate([("Section", 16), ("Topic", 22), ("Item #", 7), ("Checklist item", 70),
                                    ("Location where item is reported", 36), ("Status", 18), ("Notes", 50)]):
            header(P, HDR, 1 + j, h, "auto" if j < 4 else "input", w)
        P.row_dimensions[HDR].height = 30
        for i, (sec, topic, item, txt) in enumerate(PRISMA_ITEMS):
            rr = R0 + i
            loc, st, note = D.PRISMA[item]
            cell(P, f"A{rr}", sec, bold=True, color=NAVY)
            cell(P, f"B{rr}", topic, bold=True)
            cell(P, f"C{rr}", item, align=CENTER, bold=True)
            cell(P, f"D{rr}", txt)
            cell(P, f"E{rr}", loc, inp=True)
            cell(P, f"F{rr}", st, inp=True, align=CENTER)
            cell(P, f"G{rr}", note or None, inp=True)
        p1, pN = R0, R0 + len(PRISMA_ITEMS) - 1
        rngS = f"F{p1}:F{pN}"
        P.conditional_formatting.add(rngS, FormulaRule(formula=[f'LEFT(F{p1},8)="Reported"'], fill=F_PASS))
        P.conditional_formatting.add(rngS, FormulaRule(formula=[f'LEFT(F{p1},9)="Partially"'], fill=F_AMB))
        P.conditional_formatting.add(rngS, FormulaRule(formula=[f'LEFT(F{p1},3)="Not"'], fill=F_SEC))
        P.conditional_formatting.add(rngS, CellIsRule(operator="equal", formula=['"Not reported"'], fill=F_CHECK))
        r = pN + 2
        section(P, r, "Summary (live counts)", 7)
        for lab_, crit in [("Items and sub-items", None), ("Reported (incl. adapted / not registered)", "Reported*"),
                           ("Partially reported", "Partially*"), ("Not applicable", "Not applicable"),
                           ("Not reported", "Not reported")]:
            r += 1
            cell(P, f"D{r}", lab_, bold=True, align=Alignment(horizontal="right"))
            cell(P, f"E{r}", f"=COUNTA(C{p1}:C{pN})" if crit is None else f'=COUNTIF({rngS},"{crit}")', bold=True, align=CENTER)
        P.freeze_panes = f"D{R0}"
        P.auto_filter.ref = f"A{HDR}:G{pN}"
        page_setup(P, f"{HDR}:{HDR}")

    # final: set active tier for example
    if example:
        S[f"B{tier_row}"] = D.CANVAS["tier"]
    wb.calculation.fullCalcOnLoad = True
    wb.active = 0
    wb.save(path)
    print("saved", path)


if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else "360MDL_Toolkit_v2026_filled.xlsx"
    build(out, example=True)

# -*- coding: utf-8 -*-
"""Knowledge Distillate — validation and rendering (spec Section 12).

distillate.json (drafted by the Navigator from CONFIRMED rows only):
{
 "phenomenon": "one-page text … [SCO-IMP-01; GOV-PP-03]",
 "dimensions": [{"name": "…", "definition": "…", "clusters": [1,7], "ids": [...], "claims": ["… [IDs]", …]}],
 "established": [{"text": "…", "kf": "KF1", "ids": [...]}],
 "contested": [{"text": "…", "ids": [...], "note": "F3 vs F1 disagreement"}],
 "open_issues": [{"text": "…", "dimension": "…", "ids": [...]}],
 "future_axes": [{"title": "…", "gap": "…", "dimension": "…", "methods_underused": ["Delphi/Expert"], "streams_needed": ["F4"], "ids": [...]}],
 "limitations": "text (from the gaps report)",
 "framework": {optional}
}
Every claim-bearing entry must cite ≥ 1 existing core item ID; prose paragraphs must contain [ID] citations.
"""
import json
import os
import re

from state import FAMILIES as FAMILIES_, SLICES as SLICES_

ID_RE = re.compile(r"\b[A-Z]{3}-[A-Z]{2,3}-\d{2,3}\b")


def validate(st, d):
    core = {r["id"] for r in st["records"] if r["core"]}
    allids = {r["id"] for r in st["records"]}
    problems = []

    def check_ids(ids, where):
        for i in ids or []:
            if i not in allids:
                problems.append(f"{where}: unknown ID {i}")
            elif i not in core:
                problems.append(f"{where}: {i} is not a core item")
        if not ids:
            problems.append(f"{where}: cites no item IDs")

    if not d.get("phenomenon") or not ID_RE.search(d["phenomenon"]):
        problems.append("phenomenon: missing or carries no [ID] citation")
    if not d.get("dimensions"):
        problems.append("dimensions: none")
    for i, dim in enumerate(d.get("dimensions", [])):
        w = f"dimension {i + 1} '{dim.get('name', '?')}'"
        if not dim.get("name") or not dim.get("definition"):
            problems.append(f"{w}: needs name and definition")
        check_ids(dim.get("ids"), w)
        for j, c in enumerate(dim.get("claims", [])):
            if not ID_RE.search(c):
                problems.append(f"{w} claim {j + 1}: no [ID] citation")
    for key in ("established", "contested", "open_issues", "future_axes"):
        for i, e in enumerate(d.get(key, [])):
            check_ids(e.get("ids"), f"{key} {i + 1}")
            if key == "established" and e.get("kf") and e["kf"] not in {k["id"] for k in st["key_findings"]}:
                problems.append(f"established {i + 1}: unknown key finding {e['kf']}")
    if not d.get("limitations"):
        problems.append("limitations: missing (copy the gaps report, written for a reader)")
    return problems


def _ts_of(st, ids):
    fams = sorted({r["family"] for r in st["records"] if r["id"] in set(ids)})
    ts = len(fams)
    cls = "Robust" if ts >= 3 else "Supported" if ts == 2 else "Tentative" if ts == 1 else "None"
    return ts, cls, fams


def _cites(ids, recs, style):
    import cite
    if style == "ids":
        return "[" + "; ".join(ids) + "]"
    return "(" + "; ".join(cite.intext(recs[i], style) if i in recs else i for i in ids) + ")"


def appendix(st, R, style):
    """Evidence appendix: stream profile, most-cited items, most influential researchers, grey literature."""
    import cite
    recs = [r for r in st["records"] if not r["duplicate_of"]]
    core = [r for r in recs if r["core"]]
    L = ["## Appendix A. Evidence profile of the Core Knowledge", ""]
    L += ["### A1. Streams and families", "", "| Family | Streams used | Harvested | Unique | Core | Share of core |", "|----------|--------|-----|-----|-----|-----|"]
    N = len(core) or 1
    for f, name in FAMILIES_.items():
        used = sorted({r["stream"] for r in recs if r["family"] == f})
        h = sum(1 for r in st["records"] if r["family"] == f)
        u = sum(1 for r in recs if r["family"] == f)
        c = sum(1 for r in core if r["family"] == f)
        L.append(f"| {f} {name} | {', '.join(used) or '—'} | {h} | {u} | {c} | {c / N * 100:.0f}% |")
    f2 = lambda v: "—" if v is None else f"{v:.2f}"  # noqa: E731
    L += ["", f"Indices: SBI {f2(R['sbi'])} · CovI {f2(R['covi'])} · MDI {f2(R['mdi'])} · RI {f2(R['ri'])} · LOSO {f2(R['losoMin'])} · "
          f"Convergence {'—' if R['conv'] is None else format(R['conv'] * 100, '.0f') + '%'}", ""]
    # A2 most cited
    cited = [r for r in core if r.get("_cited_by") not in (None, "")]
    L += ["### A2. Most cited core items", ""]
    if cited:
        cited.sort(key=lambda r: -float(r["_cited_by"]))
        L += ["| # | ID | Item | Year | Citations | Family |", "|--|--------|------------------------|----|-----|----|"]
        for i, r in enumerate(cited[:15], 1):
            L.append(f"| {i} | {r['id']} | {cite.intext(r, 'apa')}: {r['title'][:90]} | {r.get('year') or ''} | {int(float(r['_cited_by']))} | {r['family']} |")
        L.append("")
        L.append("Citation counts as recorded at harvest (OpenAlex / Scopus / WoS field of the export); they are discovery signals, not quality verdicts (R3 uses citations per year, field-normalised).")
    else:
        L.append("No citation counts are stored for this corpus (records were added without a citations field). The 6R Reach scores (R3) in T4 are the recorded impact signal. Highest 6R totals:")
        top = sorted([r for r in core if r.get("sixR")], key=lambda r: -sum(v[0] for v in r["sixR"].values()))[:15]
        L += ["", "| # | ID | Item | Year | 6R total | R3 Reach | Family |", "|--|--------|------------------------|----|----|----|----|"]
        for i, r in enumerate(top, 1):
            L.append(f"| {i} | {r['id']} | {cite.intext(r, 'apa')}: {r['title'][:90]} | {r.get('year') or ''} | {sum(v[0] for v in r['sixR'].values())} | {r['sixR']['R3'][0]} | {r['family']} |")
    L.append("")
    # A3 researchers
    L += ["### A3. Most influential researchers and groups in the corpus", ""]
    groups = {}
    for r in core:
        if r["family"] in ("F3", "F4") and not r.get("authors"):
            continue
        for fam, ini in cite.surnames(r)[:1]:
            key = fam
            g = groups.setdefault(key, {"items": [], "fams": set(), "orcid": r.get("orcid"), "ini": ini})
            g["items"].append(r["id"])
            g["fams"].add(r["family"])
    allauth = {}
    for r in core:
        if r.get("authors"):
            for fam, ini in cite.surnames(r):
                allauth.setdefault(fam, {"n": 0, "ids": []})
                allauth[fam]["n"] += 1
                allauth[fam]["ids"].append(r["id"])
    ranked = sorted(allauth.items(), key=lambda kv: (-kv[1]["n"], kv[0]))[:10]
    L += ["| Researcher (surname) | Core items (any author position) | Lead author on | Families | ORCID |", "|--------|------------------|------|------|--------|"]
    for fam, v in ranked:
        lead = groups.get(fam, {"items": [], "fams": set(), "orcid": None})
        L.append(f"| {fam} | {v['n']} ({', '.join(v['ids'])}) | {len(lead['items'])} | {', '.join(sorted(lead['fams'])) or '—'} | {lead.get('orcid') or 'not in records'} |")
    L += ["", "ORCIDs appear when the harvest source supplied them (OpenAlex authorships); otherwise the researcher adds them. Ranking by number of core items is a descriptive signal within this corpus only.", ""]
    # A4 grey literature
    grey = [r for r in core if r["family"] in ("F3", "F4")]
    L += ["### A4. Grey literature in the core (industry and policy)", "", "| ID | Issuing body | Title | Year | Type | Link |", "|--------|-----------|----------------------|----|------|------|"]
    for r in grey:
        who = r.get("organisation") or cite.intext(r, "apa").rsplit(",", 1)[0]
        link = f"https://doi.org/{r['doi']}" if r.get("doi") else (r.get("url") or "")
        short = ("doi:" + r["doi"]) if r.get("doi") else re.sub(r"^https?://(www\.)?", "", link).split("/")[0]
        L.append(f"| {r['id']} | {who} | {r['title'][:90]} | {r.get('year') or ''} | {'Industry (F3)' if r['family'] == 'F3' else 'Policy (F4)'} | [{short}]({link}) |")
    L += ["", f"Grey literature is {len(grey) / N * 100:.0f}% of the core (rule 10–30%). Rigour of grey items was scored with AACODS (Authority, Accuracy, Coverage, Objectivity, Date, Significance).", ""]
    # A5 emerging voices
    emv = [r for r in core if r["family"] == "F5"]
    if emv:
        L += ["### A5. Emerging and diverse voices in the core (F5)", "", "| ID | Slice | Item | Year | What it adds |", "|--------|--------|----------------------|----|---------------|"]
        for r in emv:
            L.append(f"| {r['id']} | {SLICES_.get(r['slice'], r['slice'])} | {cite.intext(r, 'apa')}: {r['title'][:70]} | {r.get('year') or ''} | {(r.get('sixR') or {}).get('R6', ['', ''])[1][:90]} |")
        L.append("")
    return "\n".join(L)


def about_section(st):
    au = st["meta"].get("researcher") or {}
    L = ["## About the method, the Navigator and the tools", "",
         "This document was produced with the **360° MDL — Multidimensional Literature Review Model, Version 2026** (Lytras, 2026), a multi-stream, "
         "multidimensional and resilient review methodology: evidence is harvested from five stream families (academic databases, influencer scholarship, "
         "industry practice, policy and global organisations, emerging and diverse voices), passed through three gates (eligibility, the 6R quality scorecard, "
         "CCD portfolio curation), coded in standard analysis matrices, and synthesised into key findings whose triangulation strength and resilience are measured.", "",
         "The **360° MDL Navigator** is the Claude-based agent that executes the method under the Two-Key Rule: it proposes the Review Canvas, the search strings, "
         "the 6R scores, the coding, the key findings and this Distillate, and the researcher confirms each at four keys; every record carries its provenance and "
         "every action is logged. The **Core Knowledge** it delivers (toolkit, indices, gaps report) is the auditable first cycle of the review.", "",
         "| Resource | What it is | Where |", "|----------|-------------------|-------------|",
         "| Methodology, Version 2026 | Specification, Researcher Handbook, Quick Start, Excel toolkit T1–T17, MDL-RC 2026 checklist | https://doi.org/10.5281/zenodo.23724393 |",
         "| 360° MDL Navigator | The agent (Claude Skill), its scripts and this Distillate format | https://doi.org/10.5281/zenodo.24041176 · https://github.com/mlytras/360mdl |",
         "| 360° MDL Index Calculator and User Guide | Browser tool for the indices, checks, flow diagram and figures; User Guide with the Claude protocol | https://doi.org/10.5281/zenodo.24033376 · https://mlytras.github.io/360mdl/calculator.html |",
         "| The PhD Literature Review Playbook | Step-by-step guide for doctoral researchers (English; Greek edition) | https://doi.org/10.5281/zenodo.23777000 · https://doi.org/10.5281/zenodo.23807964 |",
         "| Applied reviews and open data | Full demonstrations with record-level data | https://doi.org/10.5281/zenodo.23772941 |",
         "| Community and site | Deposit your 360° MDL review; all resources in one place | https://zenodo.org/communities/360mdl · https://mlytras.github.io/360mdl/ |", "",
         "How to cite the method: Lytras, M. D. (2026). *360° MDL: The Multidimensional Literature Review Model — Version 2026*. Zenodo. https://doi.org/10.5281/zenodo.23724393", ""]
    if au.get("profiles"):
        L += [f"### About {au.get('name', 'the researcher')}", ""]
        if au.get("bio"):
            L += [au["bio"], ""]
        L += ["| Profile | Link |", "|------------|--------------|"]
        for p in au["profiles"]:
            L.append(f"| {p['label']} | [{re.sub(r'^https?://(www[.])?', '', p['url'])}]({p['url']}) |")
        L.append("")
    return "\n".join(L)


def render(st, d, style="ids", figs=None, R=None):
    """style: 'ids' (toolkit IDs), 'apa' or 'harvard'. figs: dict from figures.all_figures (paths) or None."""
    import cite
    recs = {r["id"]: r for r in st["records"]}
    conv = lambda t: cite.convert_text(t, recs, style)  # noqa: E731
    figs = figs or {}

    def fig(key, caption, path=None):
        p = path or figs.get(key)
        if not p:
            return []
        return [f"![]({os.path.basename(p)})", "", f"*{caption}*", ""]

    au = st["meta"].get("researcher") or {}
    import datetime as _dt
    stname = {"ids": "toolkit identifiers", "apa": "APA 7th", "harvard": "Harvard"}[style]
    q = lambda t: str(t).replace('"', "'")  # noqa: E731
    L = ["---", 'title: "Knowledge Distillate"', f'subtitle: "{q(st["meta"]["title"])}"',
         f'author: "{q(au.get("name", "The researcher"))}{(" — " + q(au["affiliation"])) if au.get("affiliation") else ""}"',
         f'date: "{_dt.date.today().strftime("%d %B %Y")} · 360° MDL {st["meta"]["tier"]} tier · status: {d.get("status", "proposed")} · citations: {stname}"',
         "---", "",
         "*A Knowledge Distillate is the final deliverable of a 360° MDL review: the organised discussion of the literature, drafted by the 360° MDL Navigator "
         "from the confirmed Core Knowledge and reviewed by the researcher (Key 4). Every claim is traced to items of the Master Table; "
         "TS is the number of stream families supporting a dimension or finding (Robust ≥ 3, Supported = 2, Tentative = 1).*", ""]
    L += ["## 1. The phenomenon", "", conv(d["phenomenon"]), ""]
    L += fig("phenomenon", "Figure 1. Knowledge map of the Core Knowledge: core items by stream family for each dimension; TS = number of families represented.")
    L += ["## 2. Key dimensions", ""]
    for i, dim in enumerate(d["dimensions"], 1):
        ts, cls, fams = _ts_of(st, dim.get("ids", []))
        L.append(f"### 2.{i} {dim['name']}  —  {cls} (TS {ts}: {', '.join(fams)})")
        L.append("")
        L.append(conv(dim["definition"]) + f" Clusters: {', '.join('K' + str(k) for k in dim.get('clusters', []))}. "
                 + (f"Items: {', '.join(dim.get('ids', []))}." if style == "ids" else f"{len(dim.get('ids', []))} core items."))
        L.append("")
        for c in dim.get("claims", []):
            L.append(f"- {conv(c)}")
        L.append("")
        dl = figs.get("dims") or []
        if figs.get("dimension_figures") and i - 1 < len(dl) and dl[i - 1]:
            L += fig(None, f"Figure 2.{i}. {dim['name']}: items by year and family, and method families.", dl[i - 1])
    L += ["## 3. Established knowledge", ""]
    for e in d.get("established", []):
        L.append(f"- {conv(e['text'])} {_cites(e['ids'], recs, style)}" + (f" (→ {e['kf']})" if e.get("kf") else ""))
    L.append("")
    L += fig("findings", "Figure 2. Triangulation Strength of the key findings (coloured segments = supporting stream families; dashed line = Robust threshold).")
    L += ["## 4. Contested and emerging knowledge", ""]
    for e in d.get("contested", []):
        L.append(f"- {conv(e['text'])} {_cites(e['ids'], recs, style)}" + (f" — *{e['note']}*" if e.get("note") else ""))
    L.append("")
    L += ["## 5. Open research issues", ""]
    for e in d.get("open_issues", []):
        L.append(f"- **{e.get('dimension', '')}**: {conv(e['text'])} {_cites(e['ids'], recs, style)}")
    L.append("")
    L += ["## 6. Future research axes", ""]
    for i, e in enumerate(d.get("future_axes", []), 1):
        L.append(f"### 6.{i} {e['title']}")
        L.append(f"{conv(e.get('gap', ''))} Dimension: {e.get('dimension', '')}. Under-used methods: {', '.join(e.get('methods_underused', [])) or '—'}. "
                 f"Streams to consult: {', '.join(e.get('streams_needed', [])) or '—'}. Evidence: {_cites(e['ids'], recs, style)}")
        L.append("")
    L += fig("axes", "Figure 3. Future research axes: the stream families to consult (left) and the method families under-used in the corpus (right).")
    L += ["## 7. Limitations of this review", "", conv(d["limitations"]), ""]
    L += fig("limits", "Figure 4. Index profile of this Core Knowledge against the tier targets (bars = value, lines = target).")
    if d.get("framework"):
        L += ["## 8. Value-based framework (draft)", "", "```json", json.dumps(d["framework"], ensure_ascii=False, indent=1), "```", ""]
    # references
    cited_ids = sorted(set(ID_RE.findall(json.dumps(d, ensure_ascii=False))))
    cited = [recs[i] for i in cited_ids if i in recs]
    L += ["## References", ""]
    if style == "ids":
        for r in cited:
            L.append(f"- **{r['id']}** {cite.reference(r, 'apa')}")
    else:
        for r in sorted(cited, key=cite.sort_key):
            L.append(f"- {cite.reference(r, style)}" + (f" [{r['id']}]" ))
    L.append("")
    if R is not None:
        L.append(appendix(st, R, style))
    L.append(about_section(st))
    return "\n".join(L) + "\n"


def map_json(st, d):
    return {"dimensions": [{"name": x["name"], "clusters": x.get("clusters", []), "ids": x.get("ids", []),
                            "families": _ts_of(st, x.get("ids", []))[2], "ts": _ts_of(st, x.get("ids", []))[0]} for x in d["dimensions"]],
            "future_axes": [{"title": x["title"], "dimension": x.get("dimension"), "ids": x.get("ids", [])} for x in d.get("future_axes", [])]}

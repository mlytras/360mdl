# -*- coding: utf-8 -*-
"""Builds the pandoc reference.docx that gives the Distillate a sober scientific layout (360° MDL identity):
serif body, navy headings, small italic captions, bordered tables. Run once; build.py calls make() when needed."""
import os
import subprocess

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Pt, RGBColor, Cm

NAVY, TEAL, MUTED = RGBColor(0x14, 0x21, 0x3D), RGBColor(0x0F, 0x7C, 0x8C), RGBColor(0x5B, 0x6B, 0x7F)
HERE = os.path.dirname(os.path.abspath(__file__))
REF = os.path.join(HERE, "..", "templates", "reference_distillate.docx")


def _font(style, name, size, bold=None, italic=None, color=None):
    style.font.name = name
    style.element.rPr.rFonts.set(qn("w:eastAsia"), name)
    style.font.size = Pt(size)
    if bold is not None:
        style.font.bold = bold
    if italic is not None:
        style.font.italic = italic
    if color is not None:
        style.font.color.rgb = color


def _borders(style_el, color="D5DBE1", sz="4"):
    tblPr = style_el.find(qn("w:tblPr"))
    if tblPr is None:
        tblPr = OxmlElement("w:tblPr")
        style_el.append(tblPr)
    b = OxmlElement("w:tblBorders")
    for edge in ("top", "bottom", "insideH"):
        e = OxmlElement(f"w:{edge}")
        e.set(qn("w:val"), "single"); e.set(qn("w:sz"), sz); e.set(qn("w:color"), color); e.set(qn("w:space"), "0")
        b.append(e)
    for edge in ("left", "right", "insideV"):
        e = OxmlElement(f"w:{edge}")
        e.set(qn("w:val"), "nil")
        b.append(e)
    tblPr.append(b)


def make(path=REF):
    tmp = path + ".base.docx"
    subprocess.run(["pandoc", "-o", tmp, "--print-default-data-file", "reference.docx"], check=True)
    d = Document(tmp)

    class _S:
        def __init__(self, styles):
            self.m = {x.name.lower(): x for x in styles}

        def __getitem__(self, k):
            return self.m[k.lower()]

        def __contains__(self, k):
            return k.lower() in self.m
    st = _S(d.styles)
    _font(st["Normal"], "Cambria", 11)
    st["Normal"].paragraph_format.space_after = Pt(6)
    st["Normal"].paragraph_format.line_spacing = 1.15
    for n in ("Body Text", "First Paragraph", "Compact"):
        _font(st[n], "Cambria", 11)
    _font(st["Title"], "Calibri", 24, bold=True, color=NAVY)
    _font(st["Subtitle"], "Calibri", 13, italic=False, color=TEAL)
    _font(st["Author"], "Calibri", 12, color=NAVY)
    _font(st["Date"], "Calibri", 10, color=MUTED)
    _font(st["Heading 1"], "Calibri", 16, bold=True, color=NAVY)
    st["Heading 1"].paragraph_format.space_before = Pt(22)
    st["Heading 1"].paragraph_format.space_after = Pt(6)
    _font(st["Heading 2"], "Calibri", 13, bold=True, color=NAVY)
    st["Heading 2"].paragraph_format.space_before = Pt(14)
    _font(st["Heading 3"], "Calibri", 11.5, bold=True, color=TEAL)
    for n in ("Caption", "Image Caption", "Table Caption"):
        _font(st[n], "Calibri", 9, italic=True, color=MUTED)
        st[n].paragraph_format.space_after = Pt(12)
    _font(st["Bibliography"], "Cambria", 10)
    st["Bibliography"].paragraph_format.left_indent = Cm(0.8)
    st["Bibliography"].paragraph_format.first_line_indent = Cm(-0.8)
    # tables
    t = st["Table"] if "Table" in st else None
    if t is not None:
        _borders(t.element)
        t.font.size = Pt(9)
        t.font.name = "Calibri"
    sec = d.sections[0]
    sec.left_margin = sec.right_margin = Cm(2.3)
    sec.top_margin = sec.bottom_margin = Cm(2.2)
    d.save(path)
    os.remove(tmp)
    return path


if __name__ == "__main__":
    print(make())

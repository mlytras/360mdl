#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""arXiv API search -> Navigator records (stream EMV, slice PRE: frontier preprints, family F5).
  arxiv.py "smart city energy transition" --out recs.json --n 30 --from 2024
Docs: https://info.arxiv.org/help/api/ . Only arXiv's documented Atom API is used."""
import argparse
import os
import sys
import xml.etree.ElementTree as ET
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import get_text, record, write, fail  # noqa: E402

NS = {"a": "http://www.w3.org/2005/Atom", "ar": "http://arxiv.org/schemas/atom"}


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("query"); p.add_argument("--out", required=True); p.add_argument("--stream", default="EMV"); p.add_argument("--slice", default="PRE")
    p.add_argument("--n", type=int, default=30); p.add_argument("--from", dest="y0", type=int); p.add_argument("--log", type=int)
    a = p.parse_args()
    q = " AND ".join(f"all:{w}" for w in a.query.split()) if " AND " not in a.query else a.query
    try:
        xml = get_text("https://export.arxiv.org/api/query", {"search_query": q, "start": 0, "max_results": min(a.n, 200), "sortBy": "submittedDate", "sortOrder": "descending"})
        root = ET.fromstring(xml)
        recs = []
        for e in root.findall("a:entry", NS):
            year = int((e.findtext("a:published", default="", namespaces=NS) or "0000")[:4] or 0) or None
            if a.y0 and year and year < a.y0:
                continue
            doi = e.findtext("ar:doi", default=None, namespaces=NS)
            url = e.findtext("a:id", default=None, namespaces=NS)
            recs.append(record(a.stream, a.slice, " ".join((e.findtext("a:title", default="", namespaces=NS)).split()), "arXiv API", a.log,
                               authors="; ".join(x.findtext("a:name", default="", namespaces=NS) for x in e.findall("a:author", NS)) or None,
                               year=year, venue="arXiv preprint", doi=doi, url=url,
                               abstract=" ".join((e.findtext("a:summary", default="", namespaces=NS)).split()) or None, open_access="green (arXiv)", _doctype="preprint"))
        hits = root.findtext("{http://a9.com/-/spec/opensearch/1.1/}totalResults")
    except Exception as ex:  # noqa: BLE001
        fail(str(ex))
    log = {"code": a.stream, "slice": a.slice, "source": "arXiv (export.arxiv.org/api)", "date": recs[0]["provenance"]["retrieved"] if recs else None,
           "query": q, "filters": f"from {a.y0 or ''}; newest first", "hits": int(hits) if hits and hits.isdigit() else None, "exported": len(recs),
           "notes": "Atom API", "status": "run"}
    write(recs, a.out, log, a.out.replace(".json", "_log.json"))


if __name__ == "__main__":
    main()

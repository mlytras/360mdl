# -*- coding: utf-8 -*-
"""Shared helpers for the search scripts: HTTP with retries, output in the Navigator records format, query logging.
Only documented public APIs are called; nothing is scraped. A failed source is reported, never filled from memory."""
import datetime as dt
import json
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

UA = "360MDL-Navigator/0.1 (research tool; https://mlytras.github.io/360mdl/)"


def get_json(url, params=None, headers=None, retries=3, timeout=60):
    if params:
        url = url + ("&" if "?" in url else "?") + urllib.parse.urlencode(params, doseq=True)
    h = {"User-Agent": UA, "Accept": "application/json"}
    h.update(headers or {})
    last = None
    for i in range(retries):
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers=h), timeout=timeout) as r:
                return json.load(r)
        except urllib.error.HTTPError as e:
            last = e
            if e.code == 429 or e.code >= 500:
                time.sleep(2 * (i + 1))
                continue
            raise
        except (urllib.error.URLError, TimeoutError) as e:
            last = e
            time.sleep(2 * (i + 1))
    raise RuntimeError(f"source unreachable after {retries} attempts: {last}")


def get_text(url, params=None, timeout=60):
    if params:
        url = url + ("&" if "?" in url else "?") + urllib.parse.urlencode(params, doseq=True)
    with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": UA}), timeout=timeout) as r:
        return r.read().decode("utf-8", "replace")


def record(stream, slice_, title, source, query_log=None, **f):
    r = {"stream": stream, "slice": slice_, "title": title, "authors": None, "organisation": None, "year": None, "venue": None,
         "doi": None, "url": None, "pmid": None, "openalex": None, "abstract": None, "open_access": None,
         "provenance": {"source": source, "retrieved": dt.date.today().isoformat(), "query_log": query_log}}
    r.update({k: v for k, v in f.items() if v not in (None, "", [])})
    return r


def write(records, out, log_entry=None, log_out=None):
    json.dump(records, open(out, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(f"{len(records)} records -> {out}")
    if log_entry and log_out:
        json.dump([log_entry], open(log_out, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        print(f"stream-log entry -> {log_out}  (apply with: mdl.py log STATE {log_out})")


def fail(msg):
    print("SOURCE UNAVAILABLE:", msg, file=sys.stderr)
    print("Record this in the Stream Log notes (status 'failed') so it reaches the gaps report; do not fill from memory.", file=sys.stderr)
    sys.exit(3)

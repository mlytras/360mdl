#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""OpenAlex search -> Navigator records (stream F1 by default, DOM; or EMV for preprints/Global South).

  openalex.py "smart cities energy transition Gulf" --out recs.json --stream DOM --slice IMP --sort cited_by_count:desc --n 50 --from 2015 --to 2026
  openalex.py "…" --type preprint --stream EMV --slice PRE            # F5 preprints
  openalex.py "…" --country SA,AE,EG --stream EMV --slice GLS          # F5 Global South by author institution country
  openalex.py --author "Elshurafa" --topic "solar" --stream INS --slice MC  # influencer: most-cited on-topic paper of an author
Optional --mailto EMAIL puts the researcher in OpenAlex's polite pool (ask them first). Docs: https://docs.openalex.org
"""
import argparse
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import get_json, record, write, fail  # noqa: E402

API = "https://api.openalex.org"


def inv_abstract(inv):
    if not inv:
        return None
    pos = {i: w for w, idxs in inv.items() for i in idxs}
    return " ".join(pos[i] for i in sorted(pos))


def to_record(w, a):
    loc = (w.get("primary_location") or {})
    src = (loc.get("source") or {})
    auths = "; ".join(x["author"]["display_name"] for x in w.get("authorships", []) if x.get("author"))
    orcid = next((x["author"].get("orcid") for x in w.get("authorships", []) if x.get("author") and x["author"].get("orcid")), None)
    return record(a.stream, a.slice, w.get("display_name") or w.get("title"), "OpenAlex API", a.log,
                  authors=auths or None, orcid=orcid, year=w.get("publication_year"), venue=src.get("display_name"),
                  doi=(w.get("doi") or "").replace("https://doi.org/", "") or None, openalex=w.get("id"),
                  url=loc.get("landing_page_url") or w.get("id"), abstract=inv_abstract(w.get("abstract_inverted_index")),
                  open_access=(w.get("open_access") or {}).get("oa_status"), _cited_by=w.get("cited_by_count"),
                  _doctype=w.get("type"), _language=w.get("language"), _cites_per_year=round(w.get("cited_by_count", 0) / max(1, 2027 - (w.get("publication_year") or 2026)), 2))


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("query", nargs="?"); p.add_argument("--out", required=True); p.add_argument("--stream", default="DOM"); p.add_argument("--slice", default="IMP")
    p.add_argument("--n", type=int, default=50); p.add_argument("--from", dest="y0", type=int); p.add_argument("--to", dest="y1", type=int)
    p.add_argument("--sort", default="cited_by_count:desc"); p.add_argument("--type", help="article, review, preprint, dissertation, report…")
    p.add_argument("--country", help="comma-separated ISO codes of author institutions (F5 GLS)"); p.add_argument("--language")
    p.add_argument("--author", help="author name (influencer mode)"); p.add_argument("--topic", help="topic filter for influencer mode")
    p.add_argument("--mailto"); p.add_argument("--log", type=int, help="stream-log number this query belongs to")
    a = p.parse_args()
    params = {"per-page": min(a.n, 200), "sort": a.sort}
    if a.mailto:
        params["mailto"] = a.mailto
    filters = []
    if a.y0 or a.y1:
        filters.append(f"publication_year:{a.y0 or 1900}-{a.y1 or 2100}")
    if a.type:
        filters.append(f"type:{a.type}")
    if a.country:
        filters.append("authorships.institutions.country_code:" + "|".join(a.country.split(",")))
    if a.language:
        filters.append(f"language:{a.language}")
    try:
        if a.author:
            au = get_json(f"{API}/authors", {"search": a.author, "per-page": 5, **({"mailto": a.mailto} if a.mailto else {})})
            if not au.get("results"):
                fail(f"no OpenAlex author matches '{a.author}'")
            print("author candidates:", "; ".join(f"{x['display_name']} ({x.get('works_count')} works, {x.get('cited_by_count')} cit.) {x['id']}" for x in au["results"]))
            filters.append("authorships.author.id:" + au["results"][0]["id"].rsplit("/", 1)[-1])
            if a.topic:
                params["search"] = a.topic
        else:
            params["search"] = a.query
        if filters:
            params["filter"] = ",".join(filters)
        d = get_json(f"{API}/works", params)
    except Exception as e:  # noqa: BLE001
        fail(str(e))
    recs = [to_record(w, a) for w in d.get("results", [])]
    recs = [r for r in recs if r.get("title") and (r.get("doi") or r.get("url"))]
    log = {"code": a.stream, "slice": a.slice, "source": "OpenAlex (api.openalex.org)", "date": recs[0]["provenance"]["retrieved"] if recs else None,
           "query": params.get("search") or f"author:{a.author}", "filters": params.get("filter", "") + f"; sort {a.sort}",
           "hits": (d.get("meta") or {}).get("count"), "exported": len(recs), "notes": "OpenAlex works endpoint", "status": "run"}
    write(recs, a.out, log, a.out.replace(".json", "_log.json"))


if __name__ == "__main__":
    main()

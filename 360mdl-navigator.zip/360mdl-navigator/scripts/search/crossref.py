#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Crossref: (a) search works -> Navigator records; (b) verify / complete a list of DOIs or titles.
  crossref.py search "query" --out recs.json --stream DOM --slice REC --n 50 --from 2024
  crossref.py verify titles.txt --out recs.json --stream GSC --slice TOP      # one title (or DOI) per line, e.g. copied from Google Scholar
Docs: https://api.crossref.org/swagger-ui/index.html
"""
import argparse
import os
import re
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import get_json, record, write, fail  # noqa: E402

API = "https://api.crossref.org/works"


def to_record(w, a, note=None):
    t = w.get("title") or [None]
    cont = w.get("container-title") or [None]
    auths = "; ".join(f"{x.get('family', '')}, {x.get('given', '')}".strip(", ") for x in w.get("author", []))
    yr = ((w.get("issued") or {}).get("date-parts") or [[None]])[0][0]
    abstract = re.sub(r"<[^>]+>", "", w.get("abstract") or "") or None
    return record(a.stream, a.slice, t[0], "Crossref API", a.log, authors=auths or None, year=yr, venue=cont[0],
                  doi=w.get("DOI"), url=w.get("URL"), abstract=abstract, _doctype=w.get("type"),
                  _cited_by=w.get("is-referenced-by-count"), _note=note)


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("mode", choices=["search", "verify"]); p.add_argument("arg"); p.add_argument("--out", required=True)
    p.add_argument("--stream", default="DOM"); p.add_argument("--slice", default="IMP"); p.add_argument("--n", type=int, default=50)
    p.add_argument("--from", dest="y0", type=int); p.add_argument("--to", dest="y1", type=int); p.add_argument("--mailto"); p.add_argument("--log", type=int)
    a = p.parse_args()
    recs, hits = [], None
    try:
        if a.mode == "search":
            params = {"query": a.arg, "rows": min(a.n, 1000), "sort": "is-referenced-by-count", "order": "desc"}
            f = []
            if a.y0: f.append(f"from-pub-date:{a.y0}")
            if a.y1: f.append(f"until-pub-date:{a.y1}")
            if f: params["filter"] = ",".join(f)
            if a.mailto: params["mailto"] = a.mailto
            d = get_json(API, params)
            hits = d["message"].get("total-results")
            recs = [to_record(w, a) for w in d["message"]["items"]]
        else:
            lines = [x.strip() for x in open(a.arg, encoding="utf-8") if x.strip()]
            for line in lines:
                if re.match(r"^(10\.\d{4,}/\S+)$", line):
                    d = get_json(f"{API}/{line}")
                    recs.append(to_record(d["message"], a, note="DOI verified"))
                else:
                    d = get_json(API, {"query.bibliographic": line, "rows": 1})
                    items = d["message"]["items"]
                    if items:
                        r = to_record(items[0], a, note=f"matched from title line: {line[:80]}")
                        r["_match_check"] = "CONFIRM that the Crossref title equals the intended title before adding"
                        recs.append(r)
                    else:
                        print("no match:", line[:80])
    except Exception as e:  # noqa: BLE001
        fail(str(e))
    log = {"code": a.stream, "slice": a.slice, "source": "Crossref (api.crossref.org)", "date": recs[0]["provenance"]["retrieved"] if recs else None,
           "query": a.arg if a.mode == "search" else f"verify {a.arg}", "filters": f"{a.y0 or ''}–{a.y1 or ''}", "hits": hits, "exported": len(recs),
           "notes": "sorted by citation count" if a.mode == "search" else "title/DOI verification", "status": "run"}
    write(recs, a.out, log, a.out.replace(".json", "_log.json"))


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""PubMed (NCBI E-utilities) search -> Navigator records (stream DOM, family F1).
  pubmed.py "smart city AND (energy OR heat) AND health" --out recs.json --slice REC --n 50 --from 2020
Docs: https://www.ncbi.nlm.nih.gov/books/NBK25499/ . Rate limit without key: 3 requests/s (we sleep)."""
import argparse
import os
import sys
import time
import xml.etree.ElementTree as ET
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import get_json, get_text, record, write, fail  # noqa: E402

BASE = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils"


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("query"); p.add_argument("--out", required=True); p.add_argument("--stream", default="DOM"); p.add_argument("--slice", default="IMP")
    p.add_argument("--n", type=int, default=50); p.add_argument("--from", dest="y0", type=int); p.add_argument("--to", dest="y1", type=int); p.add_argument("--log", type=int)
    a = p.parse_args()
    q = a.query
    if a.y0 or a.y1:
        q += f" AND {a.y0 or 1900}:{a.y1 or 3000}[dp]"
    try:
        s = get_json(f"{BASE}/esearch.fcgi", {"db": "pubmed", "term": q, "retmax": min(a.n, 500), "retmode": "json", "sort": "relevance"})
        ids = s["esearchresult"]["idlist"]
        hits = int(s["esearchresult"]["count"])
        recs = []
        for i in range(0, len(ids), 100):
            time.sleep(0.4)
            xml = get_text(f"{BASE}/efetch.fcgi", {"db": "pubmed", "id": ",".join(ids[i:i + 100]), "retmode": "xml"})
            root = ET.fromstring(xml)
            for art in root.findall(".//PubmedArticle"):
                pmid = art.findtext(".//PMID")
                title = " ".join((art.findtext(".//ArticleTitle") or "").split())
                abstract = " ".join(" ".join(x.itertext()) for x in art.findall(".//AbstractText")) or None
                year = art.findtext(".//PubDate/Year") or art.findtext(".//PubDate/MedlineDate")
                venue = art.findtext(".//Journal/Title")
                doi = None
                for aid in art.findall(".//ArticleId"):
                    if aid.get("IdType") == "doi":
                        doi = aid.text
                auths = "; ".join(f"{x.findtext('LastName') or ''} {x.findtext('Initials') or ''}".strip() for x in art.findall(".//Author"))
                lang = art.findtext(".//Language")
                recs.append(record(a.stream, a.slice, title, "PubMed E-utilities", a.log, authors=auths or None,
                                   year=int(year[:4]) if year and year[:4].isdigit() else None, venue=venue, doi=doi, pmid=pmid,
                                   url=f"https://pubmed.ncbi.nlm.nih.gov/{pmid}/", abstract=abstract, _language=lang))
    except Exception as e:  # noqa: BLE001
        fail(str(e))
    log = {"code": a.stream, "slice": a.slice, "source": "PubMed (NCBI E-utilities)", "date": recs[0]["provenance"]["retrieved"] if recs else None,
           "query": q, "filters": "relevance sort", "hits": hits, "exported": len(recs), "notes": "esearch + efetch", "status": "run"}
    write(recs, a.out, log, a.out.replace(".json", "_log.json"))


if __name__ == "__main__":
    main()
